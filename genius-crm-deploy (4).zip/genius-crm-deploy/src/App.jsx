import React, { useState, useEffect, useCallback, useRef } from "react";

// ─── SUPABASE CONFIG ─────────────────────────────────────────────────────────
const SUPABASE_URL = "https://rmqpevnruootzvqnsagv.supabase.co";
const SUPABASE_KEY = "sb_publishable_7IL_e0Z8qZr1i0cH7m5QIg_gHXPPjO5";

async function supabaseRequest(method, table, body = null, query = "") {
  const url = SUPABASE_URL + "/rest/v1/" + table + query;
  const headers = {
    "apikey": SUPABASE_KEY,
    "Authorization": "Bearer " + SUPABASE_KEY,
    "Content-Type": "application/json",
    "Prefer": method === "POST" ? "return=representation" : "return=minimal"
  };
  const res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : null });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err);
  }
  if (method === "GET" || (method === "POST" && headers.Prefer.includes("representation"))) {
    const text = await res.text();
    return text ? JSON.parse(text) : [];
  }
  return null;
}

async function dbLoad() {
  try {
    const [teachers, students, lessons, payments, salaries, advances, requests] = await Promise.all([
      supabaseRequest("GET", "teachers", null, "?order=id"),
      supabaseRequest("GET", "students", null, "?order=id"),
      supabaseRequest("GET", "lessons", null, "?order=id"),
      supabaseRequest("GET", "payments", null, "?order=id"),
      supabaseRequest("GET", "salaries", null, "?order=id"),
      supabaseRequest("GET", "advances", null, "?order=id"),
      supabaseRequest("GET", "requests", null, "?order=id"),
    ]);
    return { teachers, students, lessons, payments, salaries, advances, requests, broadcasts: [], prices: [], rules: [] };
  } catch(e) {
    console.warn("Supabase load failed, using localStorage:", e.message);
    return null;
  }
}

async function dbSave(table, data) {
  try {
    // Upsert all records
    await supabaseRequest("POST", table + "?on_conflict=id", data);
  } catch(e) {
    console.warn("Supabase save failed:", e.message);
  }
}

// ─── FONTS ───────────────────────────────────────────────────────────────────
const FONT_LINK = document.createElement("link");
FONT_LINK.rel = "stylesheet";
FONT_LINK.href = "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&family=JetBrains+Mono:wght@400;600&display=swap";
document.head.appendChild(FONT_LINK);

// ─── GLOBAL STYLES ───────────────────────────────────────────────────────────
const GLOBAL_STYLE = document.createElement("style");
GLOBAL_STYLE.textContent = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #f0f7ff;
    --bg2: #ffffff;
    --bg3: #e8f4fd;
    --bg4: #d0e8f7;
    --border: #c5dff0;
    --border2: #a0c8e4;
    --text: #1a3a4a;
    --text2: #4a7a94;
    --text3: #7aaabb;
    --accent: #1da0d4;
    --accent2: #3ab5e5;
    --accent3: #0d8ab8;
    --green: #4caf50;
    --red: #e53935;
    --yellow: #f5a623;
    --cyan: #00bcd4;
    --pink: #ec4899;
    --orange: #ff7043;
    --genius-blue: #1da0d4;
    --genius-green: #5cb85c;
    --genius-yellow: #f5a623;
    --shadow: 0 2px 16px rgba(29,160,212,0.1);
    --shadow-lg: 0 8px 32px rgba(29,160,212,0.15);
    --radius: 14px;
    --radius-sm: 8px;
    --radius-lg: 20px;
  }
  body.dark-mode {
    --bg: #0f1520;
    --bg2: #1a2233;
    --bg3: #1e2a3d;
    --bg4: #243044;
    --border: #2a3a55;
    --border2: #344560;
    --text: #e0eeff;
    --text2: #8aabcc;
    --text3: #4a6a8a;
    --accent: #3ab5e5;
    --accent2: #55c8f5;
    --accent3: #1da0d4;
    --shadow: 0 2px 12px rgba(0,0,0,0.3);
  }
  html, body { background: var(--bg); color: var(--text); font-family: 'Plus Jakarta Sans', sans-serif; font-size: 14px; line-height: 1.5; height: 100%; overflow: hidden; }
  body.dark-mode .sidebar-pattern { background: linear-gradient(180deg, #0b2d42 0%, #081e2e 60%, #050f1a 100%) !important; }
  body.dark-mode .corner-tl, body.dark-mode .corner-tr, body.dark-mode .corner-br, body.dark-mode .corner-bl { opacity: 0.06 !important; }
  #root { height: 100vh; display: flex; overflow: hidden; }
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: var(--bg2); }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 3px; }
  ::-webkit-scrollbar-thumb:hover { background: var(--accent); }
  button { cursor: pointer; border: none; font-family: 'Plus Jakarta Sans', sans-serif; transition: all 0.15s; }
  input, select, textarea { font-family: 'Plus Jakarta Sans', sans-serif; outline: none; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes slideIn { from { opacity: 0; transform: translateX(-12px); } to { opacity: 1; transform: translateX(0); } }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
  .fade-in { animation: fadeIn 0.2s ease; }
  .genius-pattern {
    background-image: 
      linear-gradient(135deg, #1da0d422 25%, transparent 25%),
      linear-gradient(225deg, #5cb85c22 25%, transparent 25%),
      linear-gradient(45deg, #f5a62322 25%, transparent 25%),
      linear-gradient(315deg, #1da0d422 25%, transparent 25%);
    background-size: 20px 20px;
    background-position: 0 0, 10px 0, 10px -10px, 0 10px;
  }
  .sidebar-pattern {
    background: linear-gradient(180deg, #1da0d4 0%, #0d8ab8 60%, #0a7aa6 100%);
    position: relative;
    overflow: hidden;
  }
  .sidebar-pattern::before {
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background-image:
      radial-gradient(ellipse at 10% 10%, rgba(255,255,255,0.22) 60px, transparent 60px),
      radial-gradient(ellipse at 90% 20%, rgba(92,184,92,0.4) 70px, transparent 70px),
      radial-gradient(ellipse at 15% 65%, rgba(245,166,35,0.35) 55px, transparent 55px),
      radial-gradient(ellipse at 80% 75%, rgba(255,255,255,0.1) 50px, transparent 50px),
      radial-gradient(ellipse at 50% 95%, rgba(92,184,92,0.25) 40px, transparent 40px);
    pointer-events: none;
  }
  .sidebar-pattern::after {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, rgba(255,255,255,0.05) 0%, transparent 40%, rgba(0,0,0,0.1) 100%);
    pointer-events: none;
  }
  .genius-deco {
    position: absolute;
    border-radius: 50%;
    opacity: 0.07;
    pointer-events: none;
  }
  @media print {
    body { background: white !important; color: black !important; }
    .no-print { display: none !important; }
    .print-only { display: block !important; }
  }
  .corner-tl { position: fixed; top: 0; left: 220px; width: 250px; height: 250px; pointer-events: none; z-index: 0; opacity: 0.14; background: radial-gradient(circle at 0% 0%, #1da0d4 0%, transparent 65%); }
  .corner-tr { position: fixed; top: 0; right: 0; width: 280px; height: 280px; pointer-events: none; z-index: 0; opacity: 0.1; background: radial-gradient(circle at 100% 0%, #5cb85c 0%, transparent 65%); }
  .corner-br { position: fixed; bottom: 0; right: 0; width: 300px; height: 300px; pointer-events: none; z-index: 0; opacity: 0.1; background: radial-gradient(circle at 100% 100%, #f5a623 0%, transparent 65%); }
  .corner-bl { position: fixed; bottom: 0; left: 220px; width: 180px; height: 180px; pointer-events: none; z-index: 0; opacity: 0.08; background: radial-gradient(circle at 0% 100%, #1da0d4 0%, transparent 70%); }
  .geo-pattern { position: fixed; top: 0; left: 220px; right: 0; bottom: 0; pointer-events: none; z-index: 0; opacity: 0.025;
    background-image: linear-gradient(135deg, #1da0d4 25%, transparent 25%), linear-gradient(225deg, #5cb85c 25%, transparent 25%), linear-gradient(315deg, #1da0d4 25%, transparent 25%), linear-gradient(45deg, #f5a623 25%, transparent 25%);
    background-size: 40px 40px; background-position: 0 0, 20px 0, 20px -20px, 0 20px; }
`;
document.head.appendChild(GLOBAL_STYLE);


// ─── LOGO ────────────────────────────────────────────────────────────────────
const LOGO_IMG = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAIcAhwDASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAECAwUGBwQI/8QAUBAAAgEDAQUDBQoLBgMJAQEAAAECAwQRBQYSITFBB1FxE1JhgaEUIjI2QnORscHRFRYjMzVVcnSSk7I0RVTC4fBDYoMXJCZTY4Kio/ElZP/EABsBAQACAwEBAAAAAAAAAAAAAAABBQIEBgMH/8QALBEBAAIBBAIABQQDAQEBAAAAAAECAwQFESESMRMyM0FRFSJScRQ0YSMkQv/aAAwDAQACEQMRAD8A7vvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g333ewgATvvu9g3/QvoIIAq333L6Bv+H0FOG+SK1Sb58AI333ewb77l9BcVKKKlFLkkBaW+/k+wlRlj/QukgW919/sJwu72FZAFOF3ewnC7vYTgYAeoZ8SSMAM+JHqJwMARhdy+gjC7vYVYGAKN1d3sIcX0fsLgwBa3Zron6inekuax6j0EAWN/w+gb/h9BdcE+hS6S6AUb/oX0Dffd7A6cl0KeQFW++72Dffd7CkkCd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EACd993sG++72EAAAAAAAAAAAAAAAAAAAAAAAAgdQHIcyqNNv0F2MEugFpQky5Gkl6SvHEARjBIwMAMAkAAAAAAAAAAAAAAAAAAAAIwSAIHMkgBjoQ4p80VEYAtSpdxQ01zPQMLuA82SS5KmnyeC24uPMACCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQBJAWW8IuRp44viwKYwcvQi5GCiVEgAAAAAAAAAAAAAAAgCQRkZ9IEggjkQjlUCnK7yfWBIIyMkpSCMjIEgAAAAAAAAAAQ0sEgC3Kl3FvDXBnoKZJPmBY4gqlBrwKQJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAExg5eBVGDfPkXEsARGKj0KgTgAAAAAAAAAAAAAAAEASQRkhyRHKFWfSQ2urLVStTpRcpyUYri23wRrGq7faLp2YU6ruandR4r6eRnTHe88Vh45NTjxRzeeG1OSMfqOu6ZpNLfvbqnRXRSlxfgubOW6tt9q+oOVO3lGzot8FT+F65fdg1SrOdaq6lacqk3zlKTbN/Dtt7d3lUZ96pHWKOXeNN2k0jVo5srynN9YN7sl6nhmVjJNdx84w95LehJxmuTi2sGy6TtvrGmOMJVldUc8Y13l49EuhOXbLR3SUYN6rPWSOHa00+oz6TTtK7RNHvN2FxvWlVrj5TjH6TaqF1RuaaqUZxqRa4Si8lffFenVoW+LU4ssc0nl6MjJQmVHny9+U5JKUVExJAACUgAAAAAAAAwABBblTzxXMu4GAPM8rKYyXpRUl6S04uPMACCQAAAAAAAAAAAAAAAAAAAAAAAAABHtAFyEMcWIQxxZcwAJGAAwAAAAAAAAARkhCQCGwJIyRngW6taFJOU2lFLi2x7Ra0V7lcTIcsI1bVNvdF07MY1XcVV8mjx4+PI0XV9vtX1DfhbuFnSl0p++k/GT+xGzh0eXJ9mhn3LBi+/Mupajrmm6VTc726p0UukpcX4LqaTq3aZS99DS7Zz7qlbgvHHM5xWqVK83OtOdSb5ynJtlG76Cyw7dSO7T2pc+8ZL9U6hktU17UtYk/dt1OdN8fJJ4gv8A2rh9JjcJ9MhgsqYq0jiIVV8l7zzaUjIwDN5pyQAOBGF3Hu07Vb7Sp79jd1KPHLipe9fiuXsPEMIwvjrfqYZ0yWpPNZ4dE0rtNnHdhqltvLrUo816mbtpm0mlatFOzu4Tk8Zg3uyXinxOC47iY71KSnCUoSXJxeCuzbbS/wAvS10+75MfV+4fR8ZZ6YJycT0jbjWtNcYyqq6or5FZ8fVLob3pXaFpF9uwuW7Sq+lTjHP7SK3Los2P7dLrT7ngy9c8S3HJKZ56FzSuIKdKcZwfJxllMvKXA1ZiY9t+totHMKwU7xIZJBBIAAEpAAAAADBS1lFQwB55R3OhBffHgyzOLi+HIACCQAAAAAAAAAAAAAAAAAAAEEkAC5CHViEOrLgAkgkAAAAACAEAghJAzgpclnmORUQ2W6lanTi5Tkkksttms6rt3ounb0I1fdFVfIpcePjyRlTFe8/th5ZdRjxR++eG0t8DH6lrenaVTdS9uqVGK86XF+C6nLtW7QNVv1KnbOFnSfSHGWPS/uNTrzqXFV1K1WdWb5ynJtlhi2y9u7yqM+9Ur1jjmXSNV7TaS3qel2rm+lStwXjjmaPquv6prE37supyg/8Ahxe7BepGLSXcTnBZ4tJjxx1Clz6/NmnuTdS8QEDaiOGnzMmWMsAlAACQAAAAABgABxAAAjdXcSCOOU88PbpurahpVRTsrqpT45cVL3r8VyN30rtNnFKGp2u+uTqUeD+h/ec7xn0EOJq5dJjye4beDW5sM/tl3vS9o9K1empWd3TqPrBvEl6nxMqnnp0PnGnmlNTpycJripReGjZ9J251jTcRqVY3dJP4NZ8f4isy7ZaO6SudPvVZ6yw7SnlEmm6V2haPfbsLiTtar6VH73PokbXQuaNxTU6c4zg+Ti8or7Yr06tC3xanHkj9sr4yUqS7yUzB7qgQSDkAASAAkQQ0mVADzyjh56EF9pPoWZLdYAEdCQAAAAAAAAAAAAAAAQAK4Ry8sphHeZeSwBJOAAAAAAAAU5Ki1UqRpxcpNKKWW2yGM9KhvJI1bVtu9F0xSiq3umsuVOj77j48jR9W7QNUv24Wu7Z0u6LzJ+L+42cOjy5fXpo59xw4fc8y6lqOs6dplLyl7dUqMf8AnlxfguppOr9plCO9T0u2dR8vKVeC+jqc3r1atzN1K9SdWb+VOTb9pb3F1XAs8O21r3ftS6jeL36x9Qymqa/qesTzeXc5w6U48Ifwrg/WYrdS5LgVcO4ZLCmKtY4rCqvlvknm08g4gHo8kEgEiBgkAAAAAAADwHEx5AAePAnkAAAAwCQAAAAAMkNZJBAjcie/TdXv9Jqqdld1KT6xzmL8VyPDkcDzvjrf3DOmS9J5rLouk9pm7inqtq308rR+43bS9otK1env2V3TqPrFyxKPinxOB7pXTk6VSNSDlCcfgyi2mivzbbS/delrp93yY+r9w+jlJMKWc4OL6Tt1rGmuMZzjd0lw3az4+qRvOk9oWj36jC4lKzqv5NV+9z6JFbl0eXH/ANhd6fc8GbrniW4ZJLFCvTuKcalKcZwlxUovKZfRqfdYRPMJABkkAADBTKOY4KiALDTTwC7OOV6SyBIAAAAAAAAAAAAAQlngC5Tj8p82BVFbqK8EYJAAAAAAAAAFmrTjUi4yipRaw01lMvEYIRMctF1zs6sL7fr2L9yVnxxH4Dfh09RzzWNmtU0Wo1d0JeT+TVhxg/X09Z318SzWpQrU3CpFSi+DTWUzcwa7Ji6nuFXqtrxZe46l86N9AdZ13s9sL6Mqti/cdZ8UoxzB+rp6jnOr7N6to0n7rt5Knn87Bb0H6/vLfDrceT/kuf1G3ZsM9xzDFkEtY4kce43ImOGjwkAExKAAEgAAAAAgkLmZbZzRK2v6pC1j72lH31Wfmx+/ovHPQ88mSMdZtL1xY5yWitVOjbPalrlVws6WYJ++qz4Rj/v0G52nZfDyad5f1HPqqcEl7TfrCwt9Otadta01TpwWEkj2IoM2vyXn9vUOn0204qV5v3Lm932X0/Jv3Jf1FPp5SCaNL1rZzUdCqpXlLNKTxGrDjF/cd8Z5L6yoX1tO3uacalKaw4tDDr8lJ/d3BqNpxWrzTqXzy1iTRJl9p9CqaBq87Z5lRmt6jLvjn60YjqXuLLF6+UOYzYrYreNkAkg9YeQACQAAAALiQIJHqHMiZSnIfHie7TND1PV6u5Y28qqzxnjEV4tnQdC7OLe3Uauq1PdFXn5KHCC8erNXNrceP+25p9BmzT1HTn2l6JqOsVvJ2NvOePhTfCMfF/YdA0Ps1tqChW1WbuKi4+Si2oevvN6t7ajbUo0qFKFOEeUYxwkejiU+fXXydR1DoNLtWPF+63crFvb0ralGlRpxpwjwjGCSS+g9CISJNJbRHEcJABKQAABgACGWqkeOVyLpDWUBYJDjutkASAAAAAAAAAQBMI7zL6KIRwitASAAAAAAAAAAAAAgeokEIQ+JZq0Y1YuFSCnF800nkvkD16RMRMcS0bXuz2yvnKtYP3JWfRLMG/Dp6jnWsbOato0/++UJeTT4VYLei/X09Z33iWq1GFWLhUhGcXzTWUzcw66+L32rNTteLL3XqXzmuXInk+PA6vrfZ/Yagp1dPn7lrNvlxg36V0Odats5quizavLeSprlUgswfr//AAtsGtxZfU9uf1G3ZsM9x0xgGM8QbvLR4AASgABINY5HU+y+zUNIuLtr39Wru+pL/U5a+SOvdm1WNTZiEUknCpJP/frKzcpmMXS22esTn5luKeSopjyKygh1kIDJKWSlo/aZZRraHC6S/KUKiafXD4NfUcoOy9oFaFLZa5T4ubil9JxnnzL3bJmcTlN5rEZ+kAAs4U4ACQAJSyRyIY4o92maLqWr1PJ2NtOrx4yxiMfF9DoOidnNtaqNbVqvl6i4unHhBePeaefW4sUdz23tPoM2f1HTn+maLqWsVvJ2FvOph4lPGIx8X9h0HQ+zehQ3a2q1HcTS/NR4Q9fV/UbxaWtG2oxp29KFOmlwjFYSPSuRU5tffJ1XqF/ptpx4u79ysW9vStqSp0aUacIrCjGKSRfWRgk0Z79rWKxEcQY9AJAZGAASAAAAAAAAAwABROO8iyehlmosMCAQiQAAAAAATCOZFJehHEQKkASAAAAAAAAAAAAAACMgtynFL3zS8WQhW5LGScmEq6pFanGKeaK942ZeNWnL4Mk/BjiURK4UzzhlXHBTLkzC3pMuafh270jWLzyUt+l5eeacnw59O43HTtb0/XKLprdc2vf0Zrj/AKo51q/6Vvfn5fWeWlOdCpGpSk4Ti8qUXxRymLc8mny2iZ5jlqfE7mLdtw13s8sb1yrafL3JWfyUswfq6HO9X2c1TRamLug1Tb4VY8Yv1950vQdsY1XG21HdjPlGr0l49zNslClc03GcY1KclhprKaOy0G8edeazy1NRtuHP+6nUvnV8+HElY6nV9c7O7G+36mny9yVn8nGYN+HQ53q2zmq6POSvbeSguVSC3ov1l/g1uPL/AMlQ6nbs2Ge45hiwM9FkG5EtHjgZvvZnrFO2u62mVZpKu/KU8vnLHFfQaHz4FVKpOhUhUpycJwe9GS5p+g8NRi+NSatjSZ/gZYu+jItYKsmi7L7eWt9ShbalONC6SwpyeI1PSu5+g3WnXpzgpQcZJ8mnwOayYb454tDssGqx5a+VZXs4KZSSKJ14QjmTSXfk0zafbqz0+lO3sJwuLqSxlPMYel9/gMeK2SeKwnPqceKvlaWG7TdahWrUdKotPyb8pW8ccF7Tnxcr1Z3FadatNzqVJb0pN82UI6TTYfhY4q43V6ic+WbowAQbPPDWhPgMNeJ7tN0XUdWqKnY286j87lFeL6HQdC7OKNGMK2r1fdFRcfJQ4QXr5s1M2sx4vctzT6DNnn9sdOf6Xouo6vW8nY28qvnT5Rj4s6BoXZxb0N2tq1X3RNcfJR+AvHqzeLa2t7SlGlQpQpU48oxjhGA17a2lY71vZuNW46vPvYf6+goddvHhXmZ4hfafbMWH91+5ZK6v9N2ftFlU6UEsQpwWG/BGi63tNd6opU4t0bfzIvi/FmJubmteV5Vrio6k5dW+RZklus4vVbrkz5Iivpu+f2r6dpov8nHwLqLVH83HwLi5HU4vlhtRPSckb30FE6sIJ70ksd7MPS1VS1SUW8UX7xP0956cScs4mSW41IyXBp+DyVphKQASkAAAAAAAAAAAokk0ysgDz9cEk1FiWUQAAAAAjoBMVll8oprEclYEgAAAAAAAAAAAAAAAgwms6epU3cweJRXvk+TXoM5g8moUJ3NrKjCSjvNJt9xEImGofYZrRtPU4q4qveSb3I/aX1olv5Jxbk5+cevTbWdnRlSlLeW82n6DKZ5YRV7FyIlyZUUyMJ9M/s5Dq/DV77j/AMef1njMhr9N0tcvovrVcvpwzH9TgNTHGW39tG3uUYNh2f2mraY40Ljeq2z4Ljxh4eg18jAwai+G3lWSLTX07JZ3lC9t41qFSM6cuTRXVpQrQcKkIyi+aazk5Xo2tXGj106T3qUvhU2+D+46Vpmq2uqWyrW88rrF84vuZ12g3GmeOPVmzW8ZI4lqmu9nlle71bT5e5Kr47qWYN+HT1HO9X2d1TRKjje0GqeeFWKzCXrO+9C1WowrQdOpCM4Pg4yWUy+wa7Jj6ntX6na8WXuvUvnTDzjr3EtY+EdX1zs6srzeq6fL3JVfHdSzB+rp6jnerbPato83G8t5KC5VI8Yv1lvh1uPL/wAlQajbs2Ge45hisI9dvqd/aJq2vrikueIVWsnkw/EnHoZszWt/fbUi16T1PD1XOp394sXN7cVY906smvoyeXGW31GCFnwEVrT1CJva3ueU9eRL4+g9umaLqWq1VTsbadVvnLGIrxb/AN+J0DQuzilQ3K2r1PdFTn5KHCC9fNnhm1mPH7nttafQZs89R05/pmi6jrFbydhbzq4eJT5Rj4tnQNC7N6NFxq6tU90TXHyUOEPB9Wb1a2lG0pKlb0o04R4JRjhI9CeCoz6++TqvUL/TbTjx8TfuXnt7ajaUo0qFKFOEVhRhHCRcq14UKcqk5KMIrLb4JFq+vaFjbyr15qEI822c417aGvq9R04Zp2yfvY5+F6X9xRa7X009e55lZTaMccQyG0G1srvetbCThR5Sqrg5eHcjVMZGAchqNVfPbytLWtabSZD5PARct6Tr3FKkvlzUfpZ5Yo5vCI9uyUuFOPgV80yIfBRWfQMcfthvQ1/WNPUFK5pywsreTf8Avjkwy6LibZqNrO8oxpQkopyTk33Hleh2zo7ic1LrLn7D1izGYW9GsEqcbmpLelJe9XReJmkeXT7epbW0aU2pOOUmu49aMWUJABLIAAAAAAAAAAAAAUTjmL7yyegsTWJYAAAAQkSTTWWBdSwsFRBIAAAAAAAAAAAAAAAAAjmSMAQEAEBS89CcBoxkcz20oOlrkp4wqtNS+z7jAG77fWjdC2ukuMZOD8Hx+w0dHE7nhnHqLNPLHFgAFewD2aZqFxpd1GvbTa86DfCS7meMGePJbHbyrJE8dw6zo2sW2r2qrUmlJcJwfOL7mZJM49p1/W0y6jcW7xJcGnyku5nUNG1e31ezjXovEvlwfOL7mddt24Vz18bfNDbx5PJkuJaq0o1U41IKUXzTWUy6n9YLWPzDOYiepaxqOw+h38nN2vkZ+dQe77OXsMHW7LrSUn5HUbmC7pxUvuOh4Ywz3rqMteos1L6HBeeZq53T7LrZP8rqNeS7oQSf2mYsNgdDs5Kbt5XEl/58t5fRyNsQwTbU5bf/AKRTQYK9xVYt7elbwUKVONOK6RSSL6zgYGUa88z3LciIrHERwN8DxalqNrpttKvcTUYrl3t+gnUNQt9PtZ3FeWIx+ls5hrGrVtYuXUq+9pp/k4J8Ir7yt1+vpp68R7YZMniq1vWK+sXO9N7tKPCFNPgvS+9mM6AHH5ctstvK0tSZ59gfIA8xPTJktnKDuNcs4L5NTffguJjc8Gjadg7R1L+tcy4qnDdT9LNzQY5yZ6x/1lSObOgpcCohLgSd3EcN2EkcRkZCQkAkAAAAAAAAAAAAAAAAC1VXBMulM1mLAsEkEgQy7TWI5LXPgX0sRSAkkjoiQAAAAAAAAAAAAAAAABDeAWLq4hbUvKVN7dXcskIXnLgee2vKVzOrGHOnLDMZca3SlSmqMJKbWE5GLsbp2dyqnGSaxJZ5k8SxmW37yGcmMoa1b1pqG7UjJ8ve5+oyUXlZMeExLG67YPUNMuKCScnH3me9cjk+648JLDXB+J2qXI5jtbpsrDVZTgsUq+Zxx39V/vvOf3vTzaIyw8c1euWDIGWDmWuAACeZ7dJ1KtpN5GvQfDlOGeEl3HhHM9MWS2O0WqRzE8uwabqNDUrOFxQkpRkvofcexM5Xs7rMtHu0pN+56jSqLu9J1ChVp1qUakJKUZLKa6nZbfra6in/AGG3jv5QvApyVFi9EAkgAee6uaVrQqVqslGEFlyfcXpVIwTbeEu85xtXrv4QuZWlvLNvTl75r5b+40ddq66fHzPthe/jHLw69rNXWLqTbcaEX+Th9r9Jilhf6EY6A4vNmtlt5WaczNu5AAeQDIHICeh0vZGwdjo9OUo4nW/KS+xfRg0TQtOlqmp0qGMwT3pv/lTOsU4KEIxisJLCOi2TTTzOWXvgr91xEZSHFdTH3Or29tUdOcajmuij9p0jYei7u6dpTU5vg3gvxkpJNcmarqV8r6rFqLjCKwk+eT12OswoW8aVaMpOPKUe4z8UeUNgb4Enks7yleQcqe9hedHB60Yp5SACUgAAAAAAAAAAAAAQySO8CxJYYK6i5MtgTHjIvvkWqS4l2XIB0RJHREgAAAAAAAAAAAAAAAAQUTjGa3ZJNPoysiSyiENU1W1p2tzu0m91rO6+h4vrNhudLrXl7KrVluUkkopc2iqtolCcEqblCS5POc+JnFnnMTKNFsqVO3jcfCnNZy+hlo8jx6Zb1rW28jVxmLeGuTR7TGWcQMw20WlLVdNqUkvykffU33MzJTJHjmpGSk0n7kxzHDi1SnKlOUJpxlF4afRlJue2WgyWdStY8vz0Yr/5GmLKOI1mltp8k1lp3rNZAAaaAAEoODNy2M1vEvwdcTynxpN+2P3GnYJpTlRnGpTe7KLTi10aNvR6mdPki0emVLeMu0rDKjEaBqkNV02nW4b697UXdJGWO4xZIyUi0fduRPMJyQwzxanfUtPsqtzVeI0458X0ROS8UrNpJniGA2x1tWlD3HQlitVXvmvkx+9nP13F+9ual9dVbis8znLPPl3IspHE6/VzqMnP2aeS3lKAAaLEABCQA2bZDQp3tdXtxFuhTeYpr4cl9iNnTae2e8VqVr5Tw2LZLR3p1h5WrHFxW4yz0XRGyJERWEkio7jT4Yw0ilW7WPGOENHg1OypXNCUpe9lBOSkZE8t7Tq1bapTpJb044WT39EtPXL0l+xt43N1ClOTUXzx1MzbaFTpx/L71R+jgl9pC0ipbXVKtbyzGMsuMuaM5sx4ZWjRhRpqFOKjFLgi6giTD2zgABKQAAAAAAAAAAAAAAIAoqLMS1hnoazFnn4oC5RXMuPkU0vgsqfIB0RJHREgAAAAAAAAAAAAAAAACCQEIJGAQBBJTkJMpDOeR49RvFZW/lMZk3iK7y/b1o16MKkfgyWURwx5VVIeUi4yWYtYafU51tPs3UsKsrq1jm2k8yil8D/Q6Q2UVKcasXGcVKLXFNGnrNJXU04n2xvWLdOL+gG1bQ7JVbZyudPi50c5lSXFx8DVWmu847U6XJp7eNoalqzWe0AZBrISQCSBntkNS9w6oqM5Yp3GIvu3ujOlweUji0cwkpReGuKx0wdY0LUFqWl0Lh433HE8ecuZ1GyanyicUtjDbmOGSbwjQNuNS8tcwsIP3lP31T0vovo+s3e/uoWlnVrz4RpxcjkNxXnd3FW4qvM6knJs9N51PhSKR7lOa3EcLXUAHKNWAABKR6gbBoGy1xqco1rnep2vPisOf3eJ74NNfPbxrCa1m08Q8+z+gVtXrqU0420X76XnehHTbe3hbUY0qUFCEVhJdCLa2pWtGNKjBQhFYSSL6Ow0Ohrpq/8AW1SkVEMopnOMIuTeEuLPFp2oRvXUTwnGXBd66Fg9OWQJKU1gkJSAAIJACAAEpAAAAAAAAAAAAAAh8iSHyAdCw1hsvrkWKnCbAu01iKKpcmRT+CiZcmA6IkjoiQAAAAAAAAAAAAAAAAAAAAACic1CLk+S5+Bj561Zx+DKUvCJkWsmA1fS4xjO5opJc5x+0QwmXj1O8V7WTimoRWIp8C/pmqQtKTp1t5xzmOOhi8BLLSS58F6TPhhEtpo6xZ1pRiptSk8JNM96+gxmmaZC1iqk/fVWu7kZNHlL0hDWfSa3ruylDUc1rd+QuOeUvey8V9pszRB4ZtPTNXxvBMRMcS4/qGk3umzcbmlKMek1xi/WeRHZq1CnXpuFSEZxlzUllGs6jsVaXGZ2snby6JcY/R0Of1Oy3r3j9Ne2H8OfYJSM1fbJ6vaZcaSrwS50nx+hmGqUK1GW7VhOD7pRa+tFRk0uXH80PKa2j2h5N12AusxubST4RanHw5P7DSeOOZm9kK/ufXqPHhVTpv6M/YjY23JOLURKcc8Whs+3N55DS4UFJp15pepc/sOfLkbPt5c+U1OjQz72lT3vXJvP1I1fPHmem65JvqJj8MsvdgnHcTCnUqS3acZSb6RRlLLZjWL34Ns6UfOre9X0c/YaVNNlv8sMIraWK4F+z0+71CqqdtSlUl1wuC8Wbpp2w9Ck4zva8qsusY8F95s9raULOlGnQowpwXJRWMFtptlyWnnJ1D0rhme5a1omx1O1lGvfNVqq4qC+DH7zbIx3UlFYS6IrXIcDodPpseCvjSGzWsR6QlwPFcapa205QqTe+ua3Wz3GP1DT4XtPlu1FykjZglj9Q1enXt3SoKXvucn3GOsbr3FcRq84/KXfks1aTo1J05cJReGUdPUenEcMOWzU9bs3wbnF9zR76FeNempw4xfJ4xk17SdLVy/L1ceTi+C7zZIxUUkkkvQYT0ziVRJBIZAAAAAAAAAAAAAAAAAAAEPkSQ+QDoWpxzLJd6FMksgTDhFeBMuTIjyXgTLkwHREkdESAAAAAAAAAAAAAAAAAAAAAAMGM1qp5PT5/wDO1H2mTLNWjCru78VLDysohDVrXS7q5WVHdh50+pRcWdzaSXlINJcpLimbgljguRTOClFxklJPmmZeTHxUW0t+hTn50Uy8UU4RpwUIrEUuCLhiygIGTz3dxG2t51HyigcvRzB5LC8jd20anDe5SXcz1JrkwcoeWWqltTqrFSnGS7pLJfBhakW9omGJrbPaZWk5TsqTb6qOC1R2Z0y3uKdejbblSm96LUnwf0mbDaweX+Li558UeMMPebPaff3DuLm38pUaSb3mKezmlUsONjTz6Vky5InTYpnmanEPNRtKFBfk6MIfsxSL6TXIqJPWtK19QmIUrOOZDeCW1x4lm5rwt7edWXKKyZdkryZOTx6deRvLZVHhS5SXpPVkJhUUyfAqXIplHeTTWU+ZMDUfI172vUdOLk5Sbz0LtzpN5Qgp7qmub3eODZ6dKNKKhTgoxXcsFbTMvLhj4sPoE/8Au9Sm3xjLODMotRowpzcowSlLm0XFyITEJJADIAAAAAAAAAAAAAAAAAAAh8iSHyALkRLmSuRUBRFcF4Ey5MiDzFEy5MB0RJHREgAAAAAAAAAAAAAAAAAAAAAAYAAYIJIAAkEcIY3UbyrZJSjQU4Y+FvYwYO81GrepRmoxgnlKPU2mpTjUjKMo70WuKZp1xGEbirGnlQU2kZV4YW6XrO+q2Lk6WGpc1Izmn39e8k1KgowXOafU1qKW9He5N8TcqFOFKlGFOKUFyFuCF1EkIkxZqclq5rxt6E6kuCisnm1C+nZxUlR34P5WeCMJe6nVvIRg4KEc5aXURWWMyz9hdq7t41FjPKSXeetM1Kwv52Mp7qUoy5xfeZrT9Qq3k2vI4iucs8ETNZgrPLKkEJ5JDJ4NRvK1nFThQ349ZbzWDBXupVryChNRjDOcLqbTOMZxcZRTT4NM0+6jCNzVjTTUYzcUvXgmrCyuzvatlKTpbr3ucZGb0/Ua95PDoJRXOak8GuRS3llvGeOO43G2pQpUYRpxUY4WME34hFV5cirBCJMHogkYBKUAnAAAAAAAAAAAAAAAAAAAAAAABD5EkPkBKGSOREnh8gIp/BRVLkyml8EqlyYDoiSOiJAAAAQClvC5EIVA89xeW9souvWhST4Jzlu5LD1fTv8AHW/81feTFZn0wnJWvuXvB4fwvpv+Nt/5q+8fhfTv8bb/AM1feT4W/CPj0/L3A8P4X03/ABtv/NX3j8Mab/jbf+avvHhb8Hx6fmHuB4fwxpv+Nt/5q+8j8Mab/jrf+avvHhb8Hx6fl7weD8Mad/jbf+avvH4Z07/G0P5qHhb8Hx6fl7yS3SqRqxUoSUotZUk85Lhi9Inn0AAlIAAAAAolndeMes8FrpVGhLfqflaj4uUkZEY9AYzHLH3el0LlN43Jv5UT2UYOFOMG8tJLPeXBgg4CQCWSzVhGpBxnHMXwaZqF1CELmrGnwjGbS+k3Jp4eOZjbXSKVKbqVvys228sRPDCY5a1hZXPGTc6FGnQpxhSioxSPJd6Tb3KbSVOpjnFc/E9tCEoUoxm05JYbQmeURC4kSAGa209145+k8FvpNClN1Ki8pUbbzJcuJkgQiY5eC70y3uVlx3JdJRR66EHTpQg5bzisZLgJOE4AAZAAAAAAAAAAAEEMp3uJHLHlWChy4DeQ5T5LgIQAkAEpAAAAAAh8iSHyAdCiT4lfQszfvgK6XwWVy5MtUubLsuQDoiSOiJAAACGUy5FXQpZjLGXPO1b+waf88/qOZeTidb7RNG1HWbSzhp9u60qdRuSTSwmvE5xqGzWsaVb+6L20dKllLe34vj6my70F8fw+J9uX3XHk+NNqxPDFbi7huLuQJLOK1U/lb8o3ENyPcezTdLvtWryo2NF1akY7zWUuHraMn+JG0v6ul/Mj955WyYqzxaY5e1MOa8c1iZYHcj3Ebke4z/4kbS/q6X8yP3nnvdl9b062lcXVi6dGHOW/F4+h+kxjNhmeImEzp89Y5mJYjcj3Bxi+hPgOiPWaxx6eNb259u/bPL/+Fp/7vD6kZUxez36CsP3an/SjKHL3+aXd4Pp1AAYvYAAAAAAAAAAAAAAABAJAQAAJAAAAAAAAAAAAAAAACCSHgxmRTI55tPtRqWzm0cqcVCtZ1oRqRpT4Y6PD6cjoMpJHJ+0m/srzU7alQmp17dSVXd5LOMLx4M2tFSMmTiY6Vu5ZZxYuazxLZV2kaM7F192qqq4eRcffZ8eRidntqtR2i2ptqc5eRto70/I0+WEuGX1Oc7qfQ2PYnV7TRtZVa8yoTg6e/wCZl5yyyyaGmOlprHMqbFuWXJkrF56dujy5lZ56FenXpxqU5KUJLKlHimi+nlFJ6niXUVtExzCQASzAAAAAAh8iSOgBHnn8Jno5Jnn4ZeQKqb98XnyLC4NF/mgHREkdESAAADBS+RUQQhQ02af2ktx2Zb/9aH1m5Gm9pnxXfz0PrPbTfUq1NdH/AIX/AKcfJwCeh1EOHbl2YvOv1/mH9aOucXyeDkfZh+n6/wAw/rR1yJz24T/7S67aI/8AA993ms7e5Wyt5h9I/WjaDXdtLO4vdnLmha0pVassbsY83xRrYZiL1mW5qqzOK0Q4hwRPDoZV7J7Qv+6rj+FBbKbQL+6rjH7KOjnUYuPbjo0uXn5Zdp2e/QWn/u1P+kyfUx2h0qlHR7KlVg4VIUIRlF800j3t7pzV+7S7XDzGOvKcsZMff6xp+l0/K3t1SoR6b8sN+C5mt3HaXolF4oqvW9MYYXtwZUw3v8sMcmrxY/mtw3XPpIz4Ghf9qOnZ42VwvTmP3ntte0jQa7iqs6tu2/8AiQ4L1rJnOlzR7h511+CZ6tDcQeOz1C1vqMa1rWp1qb5SpyUl7D1RllHjMTE8S2a3i0cwqIzxJLNatGjSlUqNRhBZk30RCZldyMmC/HLZ5/3pb/xj8cdn/wBaW/8AGZxiv+JeX+Vi/lDOtgwX447Pv+9Lb+Mv2W0mkajcxt7S+o1qss4jCWW8CcV49wV1GKZ4i0MuCE+AfLgYPYz3EmO1LWtO0l01fXVOh5TO5vvGcf8A6jxfjls9j9K238RlXHaY5iHlbPjrPFphnsjJgfxx2f8A1rbfxGXtrildUIVqM1OnUipQkuTT6oi1LV9wmmal54rPK+M+k815e29hbzr3NWNKlDjKUnhIxX45bPfrS2/iFaWt6gvmpSeLTwz2fSM+kwP45bPfrS2/jH45bP8A6zt/4jL4V/ww/wArF/KGdyTkx+m6xYaqpysbmnXUGlJwecZPemYTExPEvWt4tHNU5Iz6SG2kYi52o0SzuJ0K+oW9OrTeJxlLimTWJt6RfJWkc2nhmPWTkwP45bP/AK0tv4y7b7U6Jd14UaGoUKlWo8RjGXFsynFeO5hhGpxTPEWhmRkhPhkx2o65p2lOCvrulQdT4O/LGTCImeoelr1rHMsjlhswX447PfrS2/jH45bPfrS3/jM/g3/EvL/Kxfyhc2hoarcWE6OkTo068+DnVk1ur0YT4nLrns/2jg5SdKnWbeW41Vl/Tg6Y9sNnn/edv/EZe3r0rq3hVozU6dRZhKPJo9sWbJp/s1c+nw6v7vnecZU5SjJNSi91p9Hk2PS9gta1O3p3MPIUaVRZj5STTa78JMz+0+x9W52rtJ28H5C9qflnFcItcXnuys+s6G50dPs8ylGnRowy2+CjFf6G9n3CfCPD2rNLtUedvi+oYLZPZ2+0GhKlcairik+MaSg8QfobZs2cGCW2OgddUtv4x+OOz6/vS2/iK21Ml55mF1jy4MdfGtmfySY3Tdb07VnNWN3TruHwtx5wZFPJ5zEx7bFLxaOapAAZgAAAEARN4iyyV1X71It4AF6DzBFkrpPhgC70RJBIAAAAABHQ0ztM+K7+egbn0NM7TPiu/noHrp/qVaeu+hb+nIEAgdRDh259mH6fr/MP60dcjyRyPsw/T9f5h/WjrkeSOd3D60uu2f6CvoUyWSoGlC0lTgEhvgSjpS3umi7Zbb/g6UrDTt2V1ynUfFU/9TNbYa6tC0WdaDj7oqe8op976+rmcSqb1WTnOTlKTzKTfNlhoNJ8T99vSn3TXzij4dPcq7ivWu60q9zVlVqS5yk8stcO4l9e5GzbM7FXuu0/dFWo6FrnClu5cvBFxe9MFeZ6c9ixZdRbivctYwnyQSS6HT59mNi4YjfXO/3tRa+jBpW0ezV7s7XjGtLylCbxTqpcG+qfpPLFrcOSeIe+bb8+GvNo6Y+w1C70yuq9lcTpTXF4fB+KOt7I7X0tdo+QrqNO9gvfRT4S9KONYZ6LG7q6fe0rq3k41aUlJYfP0EarSVy1mY9stDrr4LxEz0+iE+R4NZ/RN78zL6idHv6Wp6Zb3lLjGrBS8O9F2/oSurK4oJ4dSDim+mUc/EeNoifs6y0/Ex81+753jH3i4BpcOBvv/ZdfKP6Rp8P/AEzSLin5C4rUW8ulUlDexzw2snR6fNjy9VcbqdNlwzzf7rUoR7kbL2fxT2stOHyZ/wBLNaZsvZ98bbT9mf8ASydVERhsnQzPx6/27XHkS+RESXyOYdtDmPaysT0v/qf5Tne6s8jovaz8PS/+p/lOeLB0OgiJxQ4/dJmNTKlx4Hetlvi1pf7pT/pRweS4HeNl/i1pf7rT/pRr7pEeMNzY55yWeHbv4qXz/wCVfWcU3FjODve0Wlz1jR7ixhUVOVVJKTWUuJzPWNgLvSdLr30r6E40Y7zioNN9Dz0GfHSvjb29N202W9/KsdQ0/C7hhE4wC58Y/DnuZdL7KP7LqPzkfqZ0ZcjnPZR/ZdR+cj9TOjLkc1rOs08Oz2zvT1Q+TOEbXRX40al899iO8PkzhG13xm1L577EbG2RE5Jam9z/AOVf7YTdXcZfZVJ7TaZw/wCPExOTL7KfGbS/n0W+esfDnpz+mmfi1/t3lcjl3amsXen/ALM/rR1FcjUNsdkrjaOrbVKVzGj5FSXvot5zgoNLetMsWt6dXr8VsuDxp7cdwuqJwu4zm0+zNbZqdtCpcRreWUmnGOMYx95g0dFjvTJXyq5HLjvit439jiuB3nZdf+HNNf8A/nj9RwfuO87L/FvTfmI/UVu6RxWFxscz8SzLY4mK2mX/AIc1P92qf0sy5idpvi5qX7tU/pZVY/mh0Gf6dnA3GKeMEJLuKnzIXQ6isRw4O0zy6F2UpeW1Hwh9p09cEcx7KPz2o+EPtOndDn9d9aeHYbX/AK8KgAaqyAAAIJIfBZAtVHl47ikhvLbJACLw8ggD0Ikog8xKwAAAAACOhpnaZ8V389A3PoaZ2mfFd/PQPbTfUq09d9C39OQAIHTw4dufZh+n6/zD+tHXI8kcj7MP0/X+Yf1o65Hkjndw+tLrtn+grJIJNKPS2QyiRWyiS4EyxlybtPvvL6vQs08woU95rPyn/okaUnwwZrbGt5fajUpPjiru58El9hhEdNo6RXFDiddfzz2mV21t6l1dUreljylaahHPe3g+gNOtadjY0baisU6UFBL1czhGj3dKy1ezu68ZSp0aim0uuDpMe0/R0vzFw/8A2r7zR3HFkyTEVjmFltGbDiiZvPEt5yzBbXabHU9n7qi0nOMPKU33SXEwj7T9J6W1xj9lfeWbntK0urb1Katrj30WuS+80MelzVtExC0za7T3pNfJy7qR1JbzOTxzZHU6SvPHbj7e+nVey+7lW0W4tpcfc9b3vg+P15N7XFHOOyl/k9SX/ND/ADHR0c1rK+OW0Oy260209ZlTNvdfgfPeo/pG9/eJ/wBTPoSfwX4Hz3qP6Svf3ip/Uzc2n5rK/ffVXmZsvZ/8brT9mf8ASzWXxMnoGrLRNVpXypeUdOMlu5xnKwWmprNscxCk0t4plrazvqawTJpI5qu1Lh+jv/t/0H/ak/1b/wDZ/oUH+Dm/Dqf1TT/lR2s/nNL/AOp/lOeLnwNg2r2nW0rtXK28j5De+VnOcfca8i80eO1MURZze4Za5c02qmXI7xsv8WtL/daf9KODy5HeNl/i1pf7rT/pRpbr8kN7Y/nsy/NGv7bNrZLUfm/tRsC5Gv7bfFLUPm/tRVYPnh0Gp+lb+nD+oAOr+zhJ9ul9lP8AZdR+cj9TOjLkc57Kf7JqPzkfqZ0Vcjmdb9aXZ7X/AK1UvkcI2t+M2pfPfYjuzfBnCdrfjNqXz32I2ds+pLT3z6df7YUy+ynxm0z59GIMvsp8ZtM+fRcZ/pS5/S/Vr/bvK5BkrkHyZysu6j05h2sPFfTP2an1xOeo6F2sfn9M/Zqf5Tny8To9v+jDj91/2bD6Hedl/i3pvzEfqODPod52X+Lem/MR+o1t1+WG3sf1JZd8jFbTfFzU/wB2qf0syr5GK2m+Lmpfu1T+llTj+aHQ5/p2cDfMEsg6qvyuDt7dD7KPzuo+EPtOnHMeyj87qPhD7Tpxz2u+tLsdq/16qgAaixAAALc3iPiXCxUeZYApRJGCQBGCQBVTlh4Lp51waPQnlZAkAAACAHQ0ztM+K7+egbmaZ2mfFf8A60D2031KtPXfQt/TkCBBKOnhw7c+zD4wV/mH9aOuR5I5H2YfGCv8w/rR1yPQ53cfrS6/Z/oK+hJBJpR6WiHyKZ8ip8iib4CUT6cG2og4bR6knz90zf0vP2mJRsu39o7bai5lh4rqNSL9WH7Ua0vSdTprROKHDauOM1v7TnPAoUU/lJFeXy5nbdFstG1PS7e7hp1o1UgpP8lHg+q+k8tVqvgcTxy9tFo51MzETw4fux84JLzj6AWg6Q/7stP5EfuJ/AGkfqy0/kR+41P1Wv8AFYfoeT+TgGV3jh5x3/8AAGkfqy0/kx+4fgDSP1ZafyY/cR+qx+Efod/5NH7KWlS1Ljn31P8AzHSVxR5bXT7Sx3laW1KgpfC8nBRz9B6ksIrM+T4t5svNJhnDjikzzwpnyfgfPeo/pG9/eKn9TPoSfwX4Hz3qP6Rvf3ip/Uyw2n5rKjffVXm6FKXXkVPkZ7Yq0t77aa1oXVGFanKM8xnHKeIvoy3y38KTZQ4cc5LxSPu1/CXyiMLrI7ytldC/VNp/KRP4q6D+qbX+Uiu/VafhcRsmT+Tg2I45lXJ8Dd+0nS7HS56d7itaVv5Tf3vJwUc43cfWzSF0N7Bm+LXyVWqwTgyTSSXI7xsv8WtL/daf9KODy5HeNl/i1pf7rT/pRX7r8kLXY/nsy65Gv7bfFLUPm/tRsC5Gv7bcdk9R+b+1FVh+eF/qfpW/pw8Bg6vnpwk+3S+yn+yah85H6mdF+Sc37Kai8lqNPqpwl9Kf3HSOhzWt+tLstrn/AOeo+Rwjaxp7Taljl5Z/UjudatClTnOcsRist9x8/wCqXPu3Uru6wvy1aU+HpZs7XE+cy0t8tHhWP+vGZfZT4zaZ8+jEGW2V+MumfPot8/0pUOm+rX+3e1yQfIiPIl8jlpdzHpzDtY/tGmfs1P8AKc+R0HtY/P6Z+zU/ynPonRbd9GHIbr/sWH0O87L/ABb035iP1HBzuuyk4z2b05xeV5CK9hrbr8sNvY/qWZp8mYjaiSjs5qX7tNf/ABZlm8dTV9vr6NpsxcxckpVsUop9W39xVYY5vEL7VXiuK0uL5CIWcJsnuOprHThZ9uh9lH53UfCH2nTuhzHsp/O6j4Q+06cmc7rp/wDaXY7V/rQqBBJqLIAIySIbwmyw+Jcqvg0W8ASAAAAAjBcpPpkoITw8gejJJSmmiQBDeCSloxmUSpqVoU8b8orPezTO0ivSqbMtRlGT8tDgn6TxdqrlGwsN2TjmrLOH6DmcnKXw5uXjJlnotJN+MnKi3LcPCbYeFOOI5EjqXkOZbj2ZVIU9erOTS/IPi36UdZ91W/8A5tP+JHztHMW3CTjnuG9PH5yX0lbqdBOW/nyuNFucafH4cPo2E4zSaaafJorNe2KWdlNPlltulzfibCuRS2r424dPiv51i35CiSyVhmMvRzvtP0mVW0t9Spxz5B7tTh8l8vacyfDB9EXltRvLadvXgp0qkXGUWuaOIbTbO3Wz9+6c4ylbTb8jV713P0oudu1FePh2c1u+jtF/i1jphXwZtuxu1n4Dm7W7zKznLKa4um+9ehmpvg+JHgWGbDXLXiVRp89sNvKr6EsNTtNQoKtbV6dWD6wlk9m8u4+c7e4rWlRTtq1SjNfKpyaMrHanXorC1a49cl9xU32q/P7ZX2Pe6cfvh3ZzSPDX1rTqF3RtalzSVetLchTzltnEa+0Os3MXCtqlzKL5rfa+ovbJ++2o01tuTdXLbfMxnbbUrNrSyjea3vFaR7d3i8lTKYoqZXLuJ6W58n4Hz3qH6Rvf3ip/Uz6En8Fnz3qH6Rvf3ip/Uy12r5rKDfflq8rNl7Pvjbafsz/pZrb5I2Ts++N1p+zU/pZZav6NlPofr1/t2tEsRD5HLcO3j05l2s/D0r/qf5Tni5I6H2s/D0r/AKn+U54jo9B9GHH7r/s2RI7zsw//AA1pf7rT/pRwfBkqG0Os21KFGjqdxCnTiowipcElyXIjW6a2ascI27WV015m0e3fFIxe0lu7rZ7UKKWXKhLHjjgWtla9a62esa9xVlUqzpJylLm2ZepBTg4yXBprxKHj4d+/s6uZ+Nj5j7w+cugMxtRpFXRtar27i1TlJzpPHBxb+zkYfjnidTivF6xaHE5sc47zWWw7G69DQdW8pW4W9ZKFRrp3P2/Q2dft9b025oKrSvKEoNZz5RHz+0ugSwvR6Gaeo0Nc1vKJb+j3K2nr4+4dM222ztXZ1dN06qqtSqt2rUi8qMeqz1bOZ5fqG7vcEbBo+y9xqWiahqOKjVGD8hGP/EkvhePd4npjpj0tOJ+7xzZMutvy1/J79FvIWGrWV3Uz5OjWjKWO7PH2HgacSF1Rs3iL1mPtLUpaaWifw+i7e5pXFGNSlJTjJJpp8/SXnndeDhWzWp31rqtjQo3taFGdaKlTU3utZxjB3VPgc3qtPOG3Eux0OrjU0549Oddq1q5Wmn3S5QqSg/8A3LP+VnNVwO6bVaT+GdEuLVL37jvU33SXI4bUpTpTlTmmpxeHF80+4tNsyxOPx+8KPeMM1zef2lRnodG2B2rtba0WlX1RUnBt0ZzfBxfHGehznnxZCSNvUYIzV4loaXU209/Kr6Cuda022oSq1rujGCWc76OSbZ7SLaC9jChn3JQf5NvnN9Xg1iUejeV6eJVGDeOGW3hLvNbBoa4Z8pnluarc76ivhEcD6LuD5Gf1zZe40bSdPu57/lK2VVjJfBfNLxxn6DAcU+JuYskZI5qrsuG2KeLN17NNRoWep3FrWmoO4gnDPVrPD2nWYzUj5xWYSUotp9MPGDonZrqV/eahdULq7rV6UKKcY1JZSeSq3DSzzOWF5tWuiOMMumrkSUoqKp0QUt4TJLdV44IlKiT3pAhEgAAAAAAjBIAqpvoXTzrg8l+L3o5Akh8CopayQhonaVp17qNnZRs7epWcKjclCLeFj0HPFs1rmeOm3X8t/cd9cc9SNxG7g1tsNfGIVWq2uufJ5zLgf4ta3+rLr+Wx+LWufqy6/ls75uIbi/2j1/U7/hr/AKHT+Tgf4ta3+rLn+Ww9mtc/Vtz/AC39x3zcQ3F3+wfql/wRslP5MJsjb17XZqwo3EJU6kKeJRksNPJnkilLHUqK61vKZldY6eFYrH2SQyRgPRRh955L/T7fUbWdtdUo1aUlhxaPaQ1kiOp5hjasWjiXKdc7NbylUnW0mqq1POfI1HiS8H19hqF5o+p2M926tK1J97h9p9Cvj1LcqUZLEknnpg38O4ZKdT2qM+z47zzTp85tNc3h+kes+gqukadW/O2VvN/81NMo/AOk/q62/lR+42o3WP4tP9Dv/JwOFGrVeKcZTb82JtWx2zGsfhmzvalpKlb0pb8pVfe5XoXNnW6VhbUF+SoU6f7MUi8oJcuB4ZtyteJrEcNjBs0Y7Ra0keRWQlgkrIXkQt1PgyOGX2zutSv7uUdNuZRlXm01TfFbzO6uOepG6vF+Bs6fUTgmZho6zRRqoiJnjhwN7N641+jLr+UzYNiNE1Wz2mtq9xZV6VKMZ5nODSXvWdcUeI3ccj3ybhfJWazHtq4dorjvF4n0mPIl8uISwSV/C44c77TNLvtRnp3uS1q1/J+U3tyOcZ3e7wZov4ua300y5/ls73KO9zG4n/8AhvYddbFXxiFTqdrrnyTeZcE/FvXP1Zc/y2Q9mtc6aZc/y2d83ENxHr+p3n7PCNjp/JhdlKFa22csaVeEqdSFJKUZcGmZzHApUWnz4FXQrrT5TMyucVPCsV/DBbSbO2+0Fk6Nb3tWOXTqJcYs5Fq2zGraPVlG4t5Spp8KtNOUX93+/E7016SidJTWJLK8DZ0+rth6juGlrNupqO/UvnLHHDePUTGlUqy3YKU33RWTv9TRdMqy3qljbyk+rpR+4u0NNsrb8xa0af7MEjendY46qrY2O3PzOTbO7B6jqdWFS+hK2tObUuE5+C+061a2dGztadtQgoUoRUYxR6FHd5fUVFdn1N808yttLosenrxDl20/Z9cqvO70hRnCTy6HJx/Z9HoNLraTqNrUdOvZ16cvTTfA+hGuJQ6afNZ8UbGLcL0jie2pqNox5LeVZ4cJ0HT7x63YSjb1cKvFt+TeMZO8xXApVOMfgrBWuB4anUTnnmYbei0f+NWY55UzWTRdsdh3qkpX+m7tO7azOD4Rqfc/rN9fEp9B5YstsVvKr2z4KZq+N4fPF3pt9p9V07u3qUprnmP2nmSXnH0XVtqVZNVYRmn0lFNHk/AWlddOtf5S+4s6bpxHcKS+xzz+2zg9rp93e1IwtaNStN8tyGTouyGwlSzq07/Vd114++p0VxUO5t9/oN9pWdCgkqNONNLpGKSL6WOp4Z9fbJHEdNvS7TTFPlfuWO1bSqOrWFSzulmnNdOcX0a9JyTWNhda0ytJ0aTuqHyZ0+LS9K6e07a+JS4nhg1V8Pps6rQ49R7fO0rC9i8St6yfc4M3nswtLqhqV3UqUakIOkknKLXHJ0504PnFfQTGCjyR75tfOWvjMNXTbV8HJF4t6VIqKUiTQXEIbRYk3JldSWXhFBKQkAAAAAAAAACCqEt1+ggjoB6FyJLVKXRl0BgYAwRwGBgYGBwIwu4kYGBwGBgkAMDABIYIJAEYGACAwMAkcCBhAABgYJJENEYKiCEGCME4GBwkGCQSIwRgkEcIQMInAHCTAwSCUIwMEghKMEYROBgcBgjBICDgRgkBJgYAAjBOCSMBBgYACTAwMAcAMAkCnBOABwGCickl6SpvCbZYlLeeWSI4viMAkAAAAAAAAAAABGCQBHLiX4S3ljqWMEptPKA9BJTGSaJQEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMDBIAAAAAAAAAjAwSAIwSAAAAAAAAAAAAAAACOgLdSa5ICipLLwuRTgcSQAAAAAAAAAAAAAAAABBJGAJjLdfoL6eVnoefBMJOMvQB6CSlNNcCoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHXALdSaisdQJqTUVjqWRz4sYAkAAAAAAAAAAAAAAAAAAAAAIwSAEZOD7y/GSa4M8+CYy3eKA9BJRCSkuBUBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAOhbnU6RAVJpcFzLXPmPEkCMEgAAAAAAAAAAAAAAAAAAAAAAAAACCSMAE2nwL0KilwfMs4AHpyC1Gpjg+RcTWAKgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjPrAZIckllsplNR8S1KTk+IFUpt8FyKPEYGAGCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARgkAR6CYyceRGBgC/GopeJUeYqjUceDYHoBQpp9SpMCQQSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAkgN464LcqiXICttLmW5VM8EUOWebGAIfF8QMEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARgkACOXIrjUfqKMAC8qil1wV5PMSpSXJgegFtVV15lUZJ9QKwRkZAkAAAAAAAAAAAAAAAAAAACAJIGQABQ5pPBS6j6cgLjaXNlDqLoW288WOACUnLmyCeAAAAAAAAAAAAAAAAAAAAAAAAAAZXeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld5HrK8LzUMLzUBRw7yM8S5heaicR81AUKbXyitVu9IYj5qKeHm+1gXFVi+pUpxfKSLOI5+CicR81AXt5d4yefKXyV9LJ8o+5e0C9knKLW++5E73oQFzPpJKMleAIyMjCKW/QBOfAnKLe96ERv+hAXN5d43l6Czv8OXtZGV5q+lgXnUiuqKfLR6cSnEfNRHB/J9rAOpnuRS5N9Srh5vtYyvNXtAo5dSfWV4j5qGF5qAoJyu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81AU5XeMrvKsLzUMLzUBTld4yu8qwvNQwvNQFOV3jK7yrC81DC81Af/Z";

// ─── DEMO DATA ────────────────────────────────────────────────────────────────
const DEMO_DATA = {
  teachers: [
    { id: 1, name: "Алина Смирнова", color: "#6c63ff", subjects: ["Математика", "ЕГЭ профильный", "Геометрия"], phone: "+7 (921) 123-45-67", email: "smirnova@genius.ru", rateType: "percent", rate: 60, bio: "Опытный педагог, 8 лет стажа", avatar: "АС" },
    { id: 2, name: "Дмитрий Волков", color: "#22c55e", subjects: ["Физика", "Математика", "ВПР"], phone: "+7 (921) 234-56-78", email: "volkov@genius.ru", rateType: "fixed", rate: 1200, bio: "КМС по математической олимпиаде", avatar: "ДВ" },
    { id: 3, name: "Ирина Кузнецова", color: "#f59e0b", subjects: ["Русский язык", "Литература", "ОГЭ"], phone: "+7 (921) 345-67-89", email: "kuznetsova@genius.ru", rateType: "percent", rate: 55, bio: "Победитель конкурса педагогов 2022", avatar: "ИК" },
    { id: 4, name: "Максим Петров", color: "#ec4899", subjects: ["Английский язык", "Онлайн занятия"], phone: "+7 (921) 456-78-90", email: "petrov@genius.ru", rateType: "fixed", rate: 1500, bio: "IELTS 8.0, Cambridge Certified", avatar: "МП" },
    { id: 5, name: "Наталья Орлова", color: "#06b6d4", subjects: ["Химия", "Биология", "ЕГЭ базовый"], phone: "+7 (921) 567-89-01", email: "orlova@genius.ru", rateType: "percent", rate: 50, bio: "Аспирант кафедры химии СПбГУ", avatar: "НО" },
  ],
  students: [
    { id: 1, name: "Иван Петров", age: 15, phone: "+7 (921) 111-11-11", parent: "Анна Петрова", parentPhone: "+7 (921) 111-11-22", school: "ГБОУ СОШ №123", grade: "9А", address: "ул. Ленина, 15, кв. 42", subjects: ["Математика", "Физика"], balance: 5400, notes: "" },
    { id: 2, name: "Мария Сидорова", age: 16, phone: "+7 (921) 222-22-22", parent: "Борис Сидоров", parentPhone: "+7 (921) 222-22-33", school: "Лицей №239", grade: "10Б", address: "пр. Невский, 88, кв. 15", subjects: ["Русский язык", "Литература"], balance: 3200, notes: "" },
    { id: 3, name: "Алексей Кузнецов", age: 14, phone: "+7 (921) 333-33-33", parent: "Светлана Кузнецова", parentPhone: "+7 (921) 333-33-44", school: "Гимназия №47", grade: "8В", address: "ул. Садовая, 22, кв. 7", subjects: ["Английский язык"], balance: 0, notes: "Аллергия на пыль" },
    { id: 4, name: "Екатерина Новикова", age: 17, phone: "+7 (921) 444-44-44", parent: "Игорь Новиков", parentPhone: "+7 (921) 444-44-55", school: "ГБОУ СОШ №456", grade: "11А", address: "ул. Пушкина, 3, кв. 101", subjects: ["ЕГЭ профильный", "Геометрия"], balance: 8100, notes: "" },
    { id: 5, name: "Дмитрий Лебедев", age: 13, phone: "+7 (921) 555-55-55", parent: "Ольга Лебедева", parentPhone: "+7 (921) 555-55-66", school: "ГБОУ СОШ №789", grade: "7Б", address: "Московский пр., 44, кв. 3", subjects: ["Математика", "Химия"], balance: 1800, notes: "" },
  ],
  courses: [
    { id: 1, name: "Подготовка к ОГЭ", category: "Экзамены", lessonsCount: 36 },
    { id: 2, name: "ЕГЭ базовый", category: "Экзамены", lessonsCount: 40 },
    { id: 3, name: "ЕГЭ профильный", category: "Экзамены", lessonsCount: 48 },
    { id: 4, name: "ВПР", category: "Экзамены", lessonsCount: 20 },
    { id: 5, name: "Математика", category: "Точные науки", lessonsCount: 32 },
    { id: 6, name: "Базовая математика", category: "Точные науки", lessonsCount: 28 },
    { id: 7, name: "Профильная математика", category: "Точные науки", lessonsCount: 40 },
    { id: 8, name: "Геометрия", category: "Точные науки", lessonsCount: 24 },
    { id: 9, name: "Информатика", category: "Точные науки", lessonsCount: 30 },
    { id: 10, name: "Программирование", category: "Точные науки", lessonsCount: 36 },
    { id: 11, name: "Физика", category: "Точные науки", lessonsCount: 32 },
    { id: 12, name: "Химия", category: "Естественные науки", lessonsCount: 32 },
    { id: 13, name: "Биология", category: "Естественные науки", lessonsCount: 28 },
    { id: 14, name: "География", category: "Естественные науки", lessonsCount: 24 },
    { id: 15, name: "Русский язык", category: "Гуманитарные", lessonsCount: 36 },
    { id: 16, name: "Английский язык", category: "Гуманитарные", lessonsCount: 40 },
    { id: 17, name: "Арабский язык", category: "Гуманитарные", lessonsCount: 36 },
    { id: 18, name: "Литература", category: "Гуманитарные", lessonsCount: 28 },
    { id: 19, name: "Литературный клуб", category: "Гуманитарные", lessonsCount: 16 },
    { id: 20, name: "История", category: "Гуманитарные", lessonsCount: 30 },
    { id: 21, name: "Обществознание", category: "Гуманитарные", lessonsCount: 30 },
    { id: 22, name: "1 класс", category: "Начальная школа", lessonsCount: 32 },
    { id: 23, name: "2 класс", category: "Начальная школа", lessonsCount: 32 },
    { id: 24, name: "3 класс", category: "Начальная школа", lessonsCount: 32 },
    { id: 25, name: "4 класс", category: "Начальная школа", lessonsCount: 32 },
    { id: 26, name: "5 класс", category: "Средняя школа", lessonsCount: 32 },
    { id: 27, name: "6 класс", category: "Средняя школа", lessonsCount: 32 },
    { id: 28, name: "7 класс", category: "Средняя школа", lessonsCount: 32 },
    { id: 29, name: "8 класс", category: "Средняя школа", lessonsCount: 32 },
    { id: 30, name: "9 класс", category: "Средняя школа", lessonsCount: 36 },
    { id: 31, name: "10 класс", category: "Старшая школа", lessonsCount: 36 },
    { id: 32, name: "11 класс", category: "Старшая школа", lessonsCount: 40 },
    { id: 33, name: "Дошкольная подготовка", category: "Дошкольники", lessonsCount: 24 },
    { id: 34, name: "Каллиграфия", category: "Развитие", lessonsCount: 16 },
    { id: 35, name: "Скорочтение", category: "Развитие", lessonsCount: 20 },
    { id: 36, name: "Логопед", category: "Специалисты", lessonsCount: 20 },
    { id: 37, name: "Психолог", category: "Специалисты", lessonsCount: 12 },
    { id: 38, name: "Живопись", category: "Творчество", lessonsCount: 24 },
    { id: 39, name: "Шахматы", category: "Творчество", lessonsCount: 28 },
    { id: 40, name: "Путешественники во времени", category: "Творчество", lessonsCount: 20 },
    { id: 41, name: "Онлайн занятия", category: "Онлайн", lessonsCount: 0 },
    { id: 42, name: "Индивидуальные занятия", category: "Индивидуальные", lessonsCount: 0 },
  ],
  lessons: [
    { id: 1, teacherId: 1, subject: "ЕГЭ профильный", type: "individual", studentId: 4, studentIds: [], date: "2025-01-13", time: "10:00", duration: 90, price: 2700, status: "completed", room: "Каб. 1", series: false },
    { id: 2, teacherId: 2, subject: "Физика", type: "individual", studentId: 1, studentIds: [], date: "2025-01-13", time: "11:30", duration: 60, price: 1800, status: "completed", room: "Каб. 2", series: false },
    { id: 3, teacherId: 3, subject: "Русский язык", type: "group", studentId: null, studentIds: [{id:2,price:1500},{id:5,price:1500}], date: "2025-01-13", time: "14:00", duration: 60, price: 3000, status: "completed", room: "Каб. 3", series: true },
    { id: 4, teacherId: 4, subject: "Английский язык", type: "individual", studentId: 3, studentIds: [], date: "2025-01-14", time: "09:00", duration: 60, price: 2000, status: "scheduled", room: "Каб. 1", series: false },
    { id: 5, teacherId: 1, subject: "Математика", type: "group", studentId: null, studentIds: [{id:1,price:1200},{id:5,price:1200}], date: "2025-01-14", time: "10:30", duration: 90, price: 2400, status: "scheduled", room: "Каб. 2", series: true },
    { id: 6, teacherId: 5, subject: "Химия", type: "individual", studentId: 5, studentIds: [], date: "2025-01-14", time: "13:00", duration: 60, price: 1600, status: "scheduled", room: "Каб. 3", series: false },
    { id: 7, teacherId: 2, subject: "Математика", type: "group", studentId: null, studentIds: [{id:1,price:1200},{id:2,price:1200},{id:4,price:1200}], date: "2025-01-15", time: "11:00", duration: 90, price: 3600, status: "scheduled", room: "Каб. 2", series: true },
    { id: 8, teacherId: 3, subject: "Литература", type: "individual", studentId: 2, studentIds: [], date: "2025-01-15", time: "15:00", duration: 60, price: 1800, status: "scheduled", room: "Каб. 1", series: false },
  ],
  payments: [
    { id: 1, studentId: 1, amount: 5400, date: "2025-01-10", type: "income", method: "Карта", note: "Оплата за январь - Математика, Физика", receiptNum: "Р-001" },
    { id: 2, studentId: 4, amount: 8100, date: "2025-01-11", type: "income", method: "Наличные", note: "Оплата 3 месяца - ЕГЭ профильный", receiptNum: "Р-002" },
    { id: 3, studentId: 2, amount: 3200, date: "2025-01-12", type: "income", method: "Карта", note: "Оплата за январь", receiptNum: "Р-003" },
    { id: 4, studentId: 3, amount: 2000, date: "2025-01-12", type: "income", method: "Наличные", note: "Пробное занятие", receiptNum: "Р-004" },
  ],
  salaries: [
    { id: 1, teacherId: 1, amount: 24000, date: "2025-01-05", period: "Декабрь 2024", paid: true },
    { id: 2, teacherId: 2, amount: 19200, date: "2025-01-05", period: "Декабрь 2024", paid: false },
  ],
  requests: [
    { id: 1, name: "Ольга Романова", phone: "+7 (921) 601-11-11", subject: "Математика", child: "Сергей, 11 лет, 5 класс", status: "new", teacherId: null, date: "2025-01-10", note: "Хочет подготовиться к олимпиаде" },
    { id: 2, name: "Павел Григорьев", phone: "+7 (921) 602-22-22", subject: "Английский язык", child: "Анна, 14 лет, 8 класс", status: "contacted", teacherId: 4, date: "2025-01-11", note: "Нужен уровень с нуля" },
    { id: 3, name: "Татьяна Козлова", phone: "+7 (921) 603-33-33", subject: "ЕГЭ профильный", child: "Максим, 17 лет, 11 класс", status: "trial", teacherId: 1, date: "2025-01-08", note: "Цель: 85+ баллов" },
    { id: 4, name: "Андрей Морозов", phone: "+7 (921) 604-44-44", subject: "Русский язык", child: "Лиза, 13 лет, 7 класс", status: "enrolled", teacherId: 3, date: "2025-01-05", note: "Зачислена в группу" },
    { id: 5, name: "Светлана Федорова", phone: "+7 (921) 605-55-55", subject: "Физика", child: "Кирилл, 16 лет, 10 класс", status: "declined", teacherId: null, date: "2025-01-09", note: "Не устроило расписание" },
  ],
  prices: [
    { id: 1, course: "Математика", min45: 1200, min60: 1500, min90: 2100, group: 900 },
    { id: 2, course: "ЕГЭ профильный", min45: 1500, min60: 1800, min90: 2700, group: 1200 },
    { id: 3, course: "ЕГЭ базовый", min45: 1200, min60: 1500, min90: 2100, group: 900 },
    { id: 4, course: "Подготовка к ОГЭ", min45: 1200, min60: 1500, min90: 2100, group: 900 },
    { id: 5, course: "Русский язык", min45: 1100, min60: 1400, min90: 2000, group: 800 },
    { id: 6, course: "Английский язык", min45: 1400, min60: 1800, min90: 2500, group: 1100 },
    { id: 7, course: "Физика", min45: 1300, min60: 1600, min90: 2300, group: 1000 },
    { id: 8, course: "Химия", min45: 1200, min60: 1500, min90: 2100, group: 900 },
    { id: 9, course: "Биология", min45: 1100, min60: 1400, min90: 2000, group: 800 },
    { id: 10, course: "История", min45: 1100, min60: 1400, min90: 2000, group: 800 },
    { id: 11, course: "Обществознание", min45: 1100, min60: 1400, min90: 2000, group: 800 },
    { id: 12, course: "Информатика", min45: 1300, min60: 1600, min90: 2300, group: 1000 },
    { id: 13, course: "Программирование", min45: 1500, min60: 1800, min90: 2700, group: 1200 },
    { id: 14, course: "Шахматы", min45: 800, min60: 1000, min90: 1500, group: 600 },
    { id: 15, course: "Живопись", min45: 900, min60: 1100, min90: 1600, group: 700 },
    { id: 16, course: "Скорочтение", min45: 1000, min60: 1200, min90: 1800, group: 800 },
    { id: 17, course: "Дошкольная подготовка", min45: 900, min60: 1100, min90: 1600, group: 700 },
    { id: 18, course: "Логопед", min45: 1500, min60: 1800, min90: 2700, group: null },
    { id: 19, course: "Психолог", min45: 1800, min60: 2200, min90: 3200, group: null },
    { id: 20, course: "Арабский язык", min45: 1400, min60: 1800, min90: 2500, group: 1100 },
    { id: 21, course: "Геометрия", min45: 1200, min60: 1500, min90: 2100, group: 900 },
    { id: 22, course: "ВПР", min45: 1000, min60: 1200, min90: 1800, group: 700 },
    { id: 23, course: "Каллиграфия", min45: 700, min60: 900, min90: 1300, group: 500 },
    { id: 24, course: "Онлайн занятия", min45: 900, min60: 1100, min90: 1600, group: 700 },
    { id: 25, course: "Путешественники во времени", min45: 800, min60: 1000, min90: 1500, group: 600 },
  ],
  rules: [
    { id: 1, section: "Расписание", text: "Занятия проводятся по предварительной записи" },
    { id: 2, section: "Расписание", text: "Отмена занятия менее чем за 24 часа оплачивается в полном объёме" },
    { id: 3, section: "Расписание", text: "Перенос занятия возможен не более 2 раз в месяц" },
    { id: 4, section: "Оплата", text: "Оплата производится не позднее 5-го числа каждого месяца" },
    { id: 5, section: "Оплата", text: "Принимается оплата наличными и банковским переводом" },
    { id: 6, section: "Оплата", text: "При оплате 3 месяцев предоставляется скидка 10%" },
    { id: 7, section: "Оплата", text: "Возврат средств осуществляется в течение 5 рабочих дней" },
    { id: 8, section: "Поведение", text: "Соблюдение тишины в учебных кабинетах обязательно" },
    { id: 9, section: "Поведение", text: "Запрещено использование мобильных телефонов во время занятий" },
    { id: 10, section: "Поведение", text: "Уважительное отношение к педагогам и другим ученикам" },
    { id: 11, section: "Посещаемость", text: "При пропуске 3 занятий подряд без уважительной причины — договор расторгается" },
    { id: 12, section: "Посещаемость", text: "Больничный лист является уважительной причиной пропуска" },
    { id: 13, section: "Материалы", text: "Учебные материалы предоставляются центром бесплатно" },
    { id: 14, section: "Материалы", text: "Ученик несёт ответственность за сохранность выданных пособий" },
    { id: 15, section: "Безопасность", text: "Дети до 12 лет передаются только в сопровождение родителям" },
    { id: 16, section: "Безопасность", text: "Центр не несёт ответственности за личные вещи учеников" },
    { id: 17, section: "Договор", text: "Договор заключается на учебный год с возможностью пролонгации" },
  ],
  broadcasts: [
    { id: 1, template: "Напоминание о занятии", audience: "Все ученики", channel: "WhatsApp", date: "2025-01-10", status: "sent", count: 5 },
    { id: 2, template: "Оплата за месяц", audience: "Задолженники", channel: "SMS", date: "2025-01-12", status: "sent", count: 2 },
  ],
};

// ─── STORAGE ──────────────────────────────────────────────────────────────────
const STORAGE_KEY = "educrmData_v1";

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return DEMO_DATA;
}

function saveData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmt = (n) => new Intl.NumberFormat("ru-RU").format(n) + " ₽";
const fmtNum = (n) => new Intl.NumberFormat("ru-RU").format(n);
const WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
const WEEKDAYS_FULL = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];

function getWeekDates(offset = 0) {
  const now = new Date();
  const day = now.getDay() || 7;
  const mon = new Date(now);
  mon.setDate(now.getDate() - day + 1 + offset * 7);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon);
    d.setDate(mon.getDate() + i);
    return d;
  });
}

function dateStr(d) {
  return d.toISOString().split("T")[0];
}

function formatDate(str) {
  if (!str) return "";
  const d = new Date(str);
  return d.toLocaleDateString("ru-RU");
}

function getTeacher(teachers, id) {
  return teachers.find((t) => t.id === id);
}
function getStudent(students, id) {
  return students.find((s) => s.id === id);
}

// ─── UI COMPONENTS ────────────────────────────────────────────────────────────
const S = {
  sidebar: { width: 220, minWidth: 220, borderRight: "none", display: "flex", flexDirection: "column", overflow: "hidden" },
  sidebarHeader: { padding: "20px 16px 16px", borderBottom: "1px solid rgba(255,255,255,0.2)", textAlign: "center" },
  logo: { fontFamily: "'DM Serif Display', serif", fontWeight: 800, fontSize: 20, color: "var(--text)", letterSpacing: "-0.5px", display: "flex", alignItems: "center", gap: 8 },
  logoIcon: { width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, var(--accent), var(--cyan))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 },
  nav: { flex: 1, overflowY: "auto", padding: "8px 8px" },
  navItem: (active) => ({ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 10, cursor: "pointer", transition: "all 0.18s", background: active ? "rgba(255,255,255,0.22)" : "transparent", color: active ? "white" : "rgba(255,255,255,0.75)", fontWeight: active ? 700 : 500, fontSize: 13, marginBottom: 1, backdropFilter: active ? "blur(8px)" : "none", boxShadow: active ? "0 2px 8px rgba(0,0,0,0.15), inset 0 1px 0 rgba(255,255,255,0.15)" : "none" }),
  sidebarFooter: { padding: "12px 16px", borderTop: "1px solid rgba(255,255,255,0.2)", fontSize: 11, color: "rgba(255,255,255,0.7)", display: "flex", alignItems: "center", gap: 6 },
  main: { flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" },
  topbar: { height: 58, borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", padding: "0 24px", gap: 12, background: "var(--bg2)", flexShrink: 0, boxShadow: "0 1px 12px rgba(29,160,212,0.08)", backdropFilter: "blur(12px)" },
  content: { flex: 1, overflowY: "auto", padding: 20, background: "var(--bg)", position: "relative" },
  card: { background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 16, padding: 20, boxShadow: "0 2px 12px rgba(29,160,212,0.07)", backdropFilter: "blur(8px)" },
  statCard: { background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 16, padding: 20, position: "relative", overflow: "hidden", boxShadow: "0 4px 16px rgba(29,160,212,0.08)", transition: "all 0.2s" },
  grid: (cols) => ({ display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 16 }),
  h1: { fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 22, color: "var(--text)", marginBottom: 4 },
  h2: { fontFamily: "'DM Serif Display', serif", fontWeight: 600, fontSize: 16, color: "var(--text)", marginBottom: 12 },
  label: { fontSize: 12, color: "var(--text3)", marginBottom: 4, display: "block", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.5px" },
  input: { width: "100%", background: "var(--bg3)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "9px 13px", color: "var(--text)", fontSize: 13, outline: "none", transition: "border-color 0.15s, box-shadow 0.15s", fontFamily: "'Plus Jakarta Sans', sans-serif" },
  select: { width: "100%", background: "var(--bg3)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "9px 13px", color: "var(--text)", fontSize: 13, outline: "none", fontFamily: "'Plus Jakarta Sans', sans-serif", transition: "border-color 0.15s, box-shadow 0.15s" },
  btn: (variant = "primary") => ({
    padding: "8px 16px", borderRadius: 8, fontSize: 13, fontWeight: 500,
    background: variant === "primary" ? "var(--accent)" : variant === "danger" ? "var(--red)" : variant === "success" ? "var(--green)" : variant === "ghost" ? "transparent" : "var(--bg3)",
    color: variant === "ghost" ? "var(--text2)" : "white",
    border: variant === "ghost" ? "1px solid var(--border)" : "none",
  }),
  badge: (color) => ({ display: "inline-flex", alignItems: "center", padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 600, background: color + "20", color }),
  tag: (color) => ({ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 8px", borderRadius: 6, fontSize: 11, background: color + "22", color: color, fontWeight: 500 }),
  table: { width: "100%", borderCollapse: "collapse" },
  th: { textAlign: "left", padding: "8px 12px", color: "var(--text3)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", borderBottom: "1px solid var(--border)", whiteSpace: "nowrap" },
  td: { padding: "11px 14px", borderBottom: "1px solid var(--border)", fontSize: 13, color: "var(--text)", transition: "background 0.12s" },
};

function Btn({ variant = "primary", onClick, children, style, disabled }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{ ...S.btn(variant), opacity: disabled ? 0.5 : hover ? 0.85 : 1, ...style }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {children}
    </button>
  );
}

function Input({ label, value, onChange, placeholder, type = "text", style }) {
  return (
    <div style={{ marginBottom: 12, ...style }}>
      {label && <label style={S.label}>{label}</label>}
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} style={S.input} />
    </div>
  );
}

function Select({ label, value, onChange, options, style }) {
  return (
    <div style={{ marginBottom: 12, ...style }}>
      {label && <label style={S.label}>{label}</label>}
      <select value={value} onChange={(e) => onChange(e.target.value)} style={S.select}>
        {options.map((o) => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
    </div>
  );
}

function Avatar({ initials, color, size = 36 }) {
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: color + "33", border: `2px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.33, fontWeight: 700, color, flexShrink: 0 }}>
      {initials}
    </div>
  );
}

function Modal({ title, onClose, children, width = 480 }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "#00000088", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 }} onClick={onClose}>
      <div style={{ background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 20, width: "100%", maxWidth: width, maxHeight: "90vh", overflowY: "auto", padding: 28, animation: "fadeIn 0.2s ease", boxShadow: "0 24px 64px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.05)" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 16 }}>{title}</div>
          <button onClick={onClose} style={{ background: "var(--bg3)", border: "none", color: "var(--text2)", width: 28, height: 28, borderRadius: 6, cursor: "pointer", fontSize: 16 }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Tabs({ tabs, active, onChange }) {
  return (
    <div style={{ display: "flex", gap: 4, padding: 4, background: "var(--bg3)", borderRadius: 10, marginBottom: 20, flexWrap: "wrap", border: "1px solid var(--border)" }}>
      {tabs.map((t) => (
        <button key={t.id} onClick={() => onChange(t.id)} style={{ padding: "6px 14px", borderRadius: 7, fontSize: 13, fontWeight: 500, background: active === t.id ? "var(--accent)" : "transparent", color: active === t.id ? "white" : "var(--text2)", borderRadius: 7, border: "none", cursor: "pointer", transition: "all 0.15s" }}>
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ data }) {
  const students = data.students || [];
  const teachers = data.teachers || [];
  const lessons = data.lessons || [];
  const payments = data.payments || [];
  const salaries = data.salaries || [];
  const totalRevenue = payments.filter(p => p.type === "income").reduce((s, p) => s + p.amount, 0);
  const pendingSalary = salaries.filter(s => !s.paid).reduce((s, p) => s + p.amount, 0);
  const upcomingLessons = lessons.filter(l => l.status === "scheduled").slice(0, 5);

  const stats = [
    { label: "Учеников", value: students.length, icon: "👨‍🎓", color: "var(--accent)", sub: "+2 этой неделе" },
    { label: "Преподавателей", value: teachers.length, icon: "👨‍🏫", color: "var(--green)", sub: "Все активны" },
    { label: "Занятий", value: lessons.length, icon: "📚", color: "var(--yellow)", sub: `${upcomingLessons.length} предстоят` },
    { label: "Выручка", value: fmt(totalRevenue), icon: "💰", color: "var(--cyan)", sub: "За этот месяц" },
  ];

  return (
    <div className="fade-in">
      <div style={{ marginBottom: 20 }}>
        <div style={S.h1}>Дашборд</div>
        <div style={{ color: "var(--text3)", fontSize: 13 }}>Образовательный центр «ГЕНИЙ»</div>
      </div>

      <div style={S.grid(4)}>
        {stats.map((s) => (
          <div key={s.label} style={{ ...S.statCard }}>
            <div style={{ position: "absolute", top: -20, right: -10, fontSize: 64, opacity: 0.08 }}>{s.icon}</div>
            <div style={{ fontSize: 11, color: "var(--text3)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 26, color: s.color, marginBottom: 4 }}>{s.value}</div>
            <div style={{ fontSize: 11, color: "var(--text3)" }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ ...S.grid(2), marginTop: 20 }}>
        <div style={S.card}>
          <div style={S.h2}>📅 Ближайшие занятия</div>
          {upcomingLessons.map((l) => {
            const t = getTeacher(teachers, l.teacherId);
            const st = l.type === "group" ? null : getStudent(data.students, l.studentId);
            return (
              <div key={l.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: (t?.color || "#666") + "22", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <div style={{ fontSize: 10, color: t?.color, fontWeight: 700 }}>{l.time}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{l.subject} {l.type === "group" && <span style={S.badge("var(--cyan)")}>ГР</span>}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{t?.name} · {formatDate(l.date)}</div>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "var(--green)" }}>{fmt(l.price)}</div>
              </div>
            );
          })}
        </div>

        <div style={S.card}>
          <div style={S.h2}>💸 Зарплаты к выплате</div>
          {salaries.filter(s => !s.paid).map((s) => {
            const t = getTeacher(teachers, s.teacherId);
            return (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
                {t && <Avatar initials={t.avatar} color={t.color} />}
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{t?.name}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{s.period}</div>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "var(--yellow)" }}>{fmt(s.amount)}</div>
              </div>
            );
          })}
          {salaries.filter(s => !s.paid).length === 0 && <div style={{ color: "var(--text3)", fontSize: 13 }}>Все выплачено ✓</div>}
          <div style={{ marginTop: 16, padding: "12px", background: "var(--yellow)11", borderRadius: 8, display: "flex", justifyContent: "space-between" }}>
            <div style={{ fontSize: 12, color: "var(--text2)" }}>К выплате итого:</div>
            <div style={{ fontWeight: 700, color: "var(--yellow)" }}>{fmt(pendingSalary)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── QUICK STATS BAR (reusable mini-chart) ────────────────────────────────────
function MiniBarChart({ data: chartData, color = "var(--accent)" }) {
  const max = Math.max(...chartData.map(d => d.value), 1);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 48 }}>
      {chartData.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
          <div title={fmt(d.value)} style={{ width: "100%", height: Math.max(4, (d.value / max) * 40), background: color, borderRadius: "3px 3px 0 0", opacity: i === chartData.length - 1 ? 1 : 0.5, transition: "height 0.3s" }} />
          <div style={{ fontSize: 9, color: "var(--text3)" }}>{d.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── TEACHERS ─────────────────────────────────────────────────────────────────
function Teachers({ data, setData }) {
  const [selected, setSelected] = useState(null);
  const [tab, setTab] = useState("overview");
  const [showAdd, setShowAdd] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ name: "", color: "#6c63ff", subjects: "", phone: "", email: "", rateType: "percent", rate: 50, bio: "", avatar: "" });

  const teachers = data.teachers || [];
  const lessons = data.lessons || [];
  const students = data.students || [];
  const salaries = data.salaries || [];

  function startEdit(t) {
    setForm({ ...t, subjects: (t.subjects || []).join(", ") });
    setEditMode(true);
    setShowAdd(true);
  }

  function saveTeacher() {
    const updated = { ...form, subjects: form.subjects.split(",").map(s => s.trim()).filter(Boolean), rate: +form.rate };
    if (editMode) {
      setData(d => ({ ...d, teachers: d.teachers.map(t => t.id === updated.id ? updated : t) }));
    } else {
      setData(d => ({ ...d, teachers: [...d.teachers, { ...updated, id: Date.now() }] }));
    }
    setShowAdd(false);
    setEditMode(false);
    setForm({ name: "", color: "#6c63ff", subjects: "", phone: "", email: "", rateType: "percent", rate: 50, bio: "", avatar: "" });
  }

  function deleteTeacher(id) {
    if (!confirm("Удалить педагога? Все его занятия останутся в системе.")) return;
    setData(d => ({ ...d, teachers: d.teachers.filter(t => t.id !== id) }));
    setSelected(null);
  }

  if (selected) {
    const t = teachers.find(t => t.id === selected);
    if (!t) { setSelected(null); return null; }
    const tLessons = lessons.filter(l => l.teacherId === t.id);
    const tStudentIds = [...new Set(tLessons.flatMap(l => l.type === "group" ? (l.studentIds||[]).map(s => s.id) : [l.studentId]).filter(Boolean))];
    const tStudents = students.filter(s => tStudentIds.includes(s.id));
    const tSalaries = salaries.filter(s => s.teacherId === t.id);
    const totalEarned = tLessons.reduce((s, l) => s + (l.type === "group" ? (l.studentIds||[]).reduce((a, si) => a + si.price, 0) : l.price), 0);
    const teacherShare = t.rateType === "percent" ? Math.round(totalEarned * t.rate / 100) : tLessons.length * t.rate;

    return (
      <div className="fade-in">
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
          <Btn variant="ghost" onClick={() => setSelected(null)}>← Назад</Btn>
          <div style={S.h1}>{t.name}</div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <Btn variant="ghost" onClick={() => startEdit(t)}>✏️ Редактировать</Btn>
            <Btn variant="danger" onClick={() => deleteTeacher(t.id)}>🗑️ Удалить</Btn>
          </div>
        </div>
        <div style={{ display: "flex", gap: 16, marginBottom: 20, alignItems: "flex-start" }}>
          <div style={{ ...S.card, width: 200, flexShrink: 0, textAlign: "center" }}>
            <Avatar initials={t.avatar} color={t.color} size={64} photo={t.photo} />
            <div style={{ fontWeight: 700, marginTop: 10, marginBottom: 4 }}>{t.name}</div>
            <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 12 }}>{(t.subjects||[]).join(", ")}</div>
            <div style={{ fontSize: 12, color: "var(--text2)" }}>{t.phone}</div>
            <div style={{ fontSize: 12, color: "var(--text2)" }}>{t.email}</div>
          </div>
          <div style={{ flex: 1 }}>
            <Tabs tabs={[{ id: "overview", label: "Обзор" }, { id: "journal", label: `📋 Журнал` }, { id: "students", label: `Ученики (${tStudents.length})` }, { id: "lessons", label: `Занятия (${tLessons.length})` }, { id: "salary", label: "Зарплата" }]} active={tab} onChange={setTab} />
            {tab === "overview" && (
              <div style={S.grid(3)}>
                {[{ label: "Занятий", val: tLessons.length, color: "var(--accent)" }, { label: "Учеников", val: tStudents.length, color: "var(--green)" }, { label: "Заработано", val: fmt(teacherShare), color: "var(--yellow)" }].map(s => (
                  <div key={s.label} style={S.statCard} className="hover-card slide-up">
                    <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6 }}>{s.label}</div>
                    <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 20, color: s.color }}>{s.val}</div>
                  </div>
                ))}
                <div style={{ ...S.card, gridColumn: "1/-1" }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: "var(--accent)", marginBottom: 10 }}>💰 Ставки оплаты</div>
                  <div style={{ fontSize: 13, marginBottom: 10 }}>
                    Базовая: <strong>{t.rateType === "percent" ? `${t.rate}% от стоимости занятия` : t.rateType === "table" ? "По таблице категорий" : `${fmt(t.rate)} за занятие`}</strong>
                  </div>
                  {t.rates && Object.keys(t.rates).filter(k => t.rates[k] > 0).length > 0 && (
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10 }}>
                      {[
                        { key: "logo_ind_30", label: "Лог.Инд·30м" }, { key: "logo_ind_40", label: "Лог.Инд·40м" }, { key: "logo_ind_60", label: "Лог.Инд·60м" },
                        { key: "logo_grp_30", label: "Лог.Груп·30м" }, { key: "logo_grp_40", label: "Лог.Груп·40м" }, { key: "logo_grp_60", label: "Лог.Груп·60м" },
                        { key: "ind_pre_40", label: "Инд.Дошк·40м" }, { key: "ind_pre_60", label: "Инд.Дошк·60м" }, { key: "ind_pre_90", label: "Инд.Дошк·90м" }, { key: "ind_pre_120", label: "Инд.Дошк·120м" },
                        { key: "grp_pre_40", label: "Груп.Дошк·40м" }, { key: "grp_pre_60", label: "Груп.Дошк·60м" }, { key: "grp_pre_90", label: "Груп.Дошк·90м" }, { key: "grp_pre_120", label: "Груп.Дошк·120м" },
                        { key: "ind_1_8_40", label: "Инд.1-8·40м" }, { key: "ind_1_8_60", label: "Инд.1-8·60м" }, { key: "ind_1_8_90", label: "Инд.1-8·90м" }, { key: "ind_1_8_120", label: "Инд.1-8·120м" },
                        { key: "ind_9_11_40", label: "Инд.9-11·40м" }, { key: "ind_9_11_60", label: "Инд.9-11·60м" }, { key: "ind_9_11_90", label: "Инд.9-11·90м" }, { key: "ind_9_11_120", label: "Инд.9-11·120м" },
                        { key: "grp_1_8_40", label: "Груп.1-8·40м" }, { key: "grp_1_8_60", label: "Груп.1-8·60м" }, { key: "grp_1_8_90", label: "Груп.1-8·90м" }, { key: "grp_1_8_120", label: "Груп.1-8·120м" },
                        { key: "grp_9_11_40", label: "Груп.9-11·40м" }, { key: "grp_9_11_60", label: "Груп.9-11·60м" }, { key: "grp_9_11_90", label: "Груп.9-11·90м" }, { key: "grp_9_11_120", label: "Груп.9-11·120м" },
                      ].filter(r => t.rates[r.key] > 0).map(r => (
                        <div key={r.key} style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 6, padding: "4px 10px", fontSize: 12 }}>
                          <span style={{ color: "var(--text3)" }}>{r.label}: </span>
                          <span style={{ fontWeight: 700, color: "var(--accent)" }}>{fmt(t.rates[r.key])}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <div style={{ fontSize: 13, color: "var(--text2)", borderTop: "1px solid var(--border)", paddingTop: 10, marginTop: 4 }}>{t.bio}</div>
                </div>
              </div>
            )}
            {tab === "journal" && (() => {
              // Build journal: students x days of current month
              const now = new Date();
              const year = now.getFullYear();
              const month = now.getMonth();
              const daysInMonth = new Date(year, month + 1, 0).getDate();
              const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
              const monthName = now.toLocaleDateString("ru-RU", { month: "long", year: "numeric" });

              // Get lesson days per student for this teacher this month
              function getStudentLessons(studentId) {
                return tLessons.filter(l => {
                  if (!l.date) return false;
                  const d = new Date(l.date);
                  if (d.getFullYear() !== year || d.getMonth() !== month) return false;
                  if (l.type === "individual") return l.studentId === studentId;
                  return (l.studentIds || []).some(si => si.id === studentId);
                });
              }

              function getLessonOnDay(studentId, day) {
                const dateStr = `${year}-${String(month+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
                return tLessons.find(l => {
                  if (l.date !== dateStr) return false;
                  if (l.type === "individual") return l.studentId === studentId;
                  return (l.studentIds || []).some(si => si.id === studentId);
                });
              }

              function getLessonMark(l) {
                if (!l) return "";
                if (l.status === "cancelled") return "Н";
                if (l.status === "cancelled_excused") return "УП";
                if (l.status === "completed") return "✓";
                return "1";
              }

              function getLessonMarkColor(l) {
                if (!l) return "transparent";
                if (l.status === "cancelled") return "#e5393520";
                if (l.status === "cancelled_excused") return "#f5a62320";
                if (l.status === "completed") return "#4caf5020";
                return "#1da0d420";
              }

              // Calculate total payment per student
              function getStudentPayment(s) {
                const sLessons = getStudentLessons(s.id);
                return sLessons.reduce((sum, l) => {
                  if (l.type === "group") {
                    const si = (l.studentIds || []).find(x => x.id === s.id);
                    return sum + (si?.price || 0);
                  }
                  return sum + (l.price || 0);
                }, 0);
              }

              return (
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <div style={{ fontWeight: 700, fontSize: 15, fontFamily: "'DM Serif Display', serif" }}>
                      📋 Журнал — {t.name}
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <div style={{ fontSize: 12, color: "var(--text3)" }}>{monthName}</div>
                      <Btn variant="ghost" onClick={() => {
                        // Print journal
                        const rows = tStudents.map(s => {
                          const payment = getStudentPayment(s);
                          const lessons = getStudentLessons(s.id);
                          const dayMarks = days.map(d => {
                            const l = getLessonOnDay(s.id, d);
                            return getLessonMark(l) || "";
                          });
                          return { s, payment, lessons, dayMarks };
                        });
                        const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
                        <title>Журнал — ${t.name}</title>
                        <style>
                          body{font-family:Arial;font-size:10px;margin:20px;}
                          h2{color:#1da0d4;margin-bottom:8px;}
                          table{border-collapse:collapse;width:100%;}
                          th,td{border:1px solid #ccc;padding:3px 4px;text-align:center;}
                          th{background:#1da0d4;color:white;font-size:9px;}
                          .name{text-align:left;min-width:120px;}
                          .completed{background:#4caf5022;}
                          .cancelled{background:#e5393522;color:#e53935;}
                          .excused{background:#f5a62322;color:#f5a623;}
                          @media print{body{margin:10px;}}
                        </style></head><body>
                        <h2>📋 Журнал: ${t.name}</h2>
                        <p style="color:#666;margin-bottom:8px">${monthName} · Предметы: ${(t.subjects||[]).join(", ")}</p>
                        <table>
                          <tr>
                            <th class="name">ФИО ученика</th>
                            <th>Класс</th>
                            <th>Контакт родителя</th>
                            <th>Кол-во<br>занятий</th>
                            ${days.map(d => `<th>${d}</th>`).join("")}
                            <th>Оплата</th>
                            <th>Долг</th>
                          </tr>
                          ${rows.map(({s, payment, lessons, dayMarks}) => `
                          <tr>
                            <td class="name">${s.name}</td>
                            <td>${s.grade || ""}</td>
                            <td>${s.parentPhone || s.phone || ""}</td>
                            <td>${lessons.length}</td>
                            ${dayMarks.map((mark, di) => {
                              const l = getLessonOnDay(s.id, di+1);
                              const cls = !l ? "" : l.status === "completed" ? "completed" : l.status === "cancelled" ? "cancelled" : l.status === "cancelled_excused" ? "excused" : "completed";
                              return `<td class="${cls}">${mark}</td>`;
                            }).join("")}
                            <td style="color:#4caf50;font-weight:bold">${payment.toLocaleString("ru-RU")} ₽</td>
                            <td style="color:${(students.find(x=>x.id===s.id)?.balance||0) < 0 ? "#e53935" : "#4caf50"}">${(students.find(x=>x.id===s.id)?.balance||0).toLocaleString("ru-RU")} ₽</td>
                          </tr>`).join("")}
                        </table>
                        <div style="margin-top:12px;font-size:9px;color:#999">Образовательный центр «ГЕНИЙ» · ${new Date().toLocaleDateString("ru-RU")}</div>
                        <div style="margin-top:6px;font-size:9px;color:#bbb">Обозначения: ✓ — проведён · Н — неявка · УП — уважит. причина</div>
                        </body></html>`;
                        const w = window.open("","_blank"); w.document.write(html); w.document.close(); w.print();
                      }}>🖨️ Печать журнала</Btn>
                    </div>
                  </div>

                  {/* Legend */}
                  <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
                    {[["✓", "#4caf50", "Проведён"], ["Н", "#e53935", "Неявка"], ["УП", "#f5a623", "Ув. причина"], ["1", "#1da0d4", "Запланирован"]].map(([mark, color, label]) => (
                      <div key={mark} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11 }}>
                        <div style={{ width: 22, height: 22, borderRadius: 4, background: color + "22", border: `1px solid ${color}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color }}>{mark}</div>
                        <span style={{ color: "var(--text3)" }}>{label}</span>
                      </div>
                    ))}
                  </div>

                  {/* Journal table */}
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ borderCollapse: "collapse", minWidth: tStudents.length > 0 ? (120 + daysInMonth * 26 + 200) : "auto", width: "100%" }}>
                      <thead>
                        <tr style={{ background: "linear-gradient(135deg, #1da0d4, #0d8ab8)" }}>
                          <th style={{ ...S.th, color: "white", background: "transparent", textAlign: "left", minWidth: 140, position: "sticky", left: 0, zIndex: 2 }}>ФИО ученика</th>
                          <th style={{ ...S.th, color: "white", background: "transparent", minWidth: 50 }}>Класс</th>
                          <th style={{ ...S.th, color: "white", background: "transparent", minWidth: 110 }}>Контакт</th>
                          <th style={{ ...S.th, color: "white", background: "transparent", minWidth: 40 }}>Зан.</th>
                          {days.map(d => (
                            <th key={d} style={{ ...S.th, color: "white", background: "transparent", width: 26, padding: "6px 2px", fontSize: 10 }}>{d}</th>
                          ))}
                          <th style={{ ...S.th, color: "white", background: "transparent", minWidth: 80 }}>Оплата</th>
                          <th style={{ ...S.th, color: "white", background: "transparent", minWidth: 80 }}>Баланс</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tStudents.length === 0 && (
                          <tr><td colSpan={5 + daysInMonth + 2} style={{ ...S.td, textAlign: "center", color: "var(--text3)" }}>У педагога нет учеников в этом месяце</td></tr>
                        )}
                        {tStudents.map((s, si) => {
                          const sLessons = getStudentLessons(s.id);
                          const payment = getStudentPayment(s);
                          const balance = s.balance || 0;
                          return (
                            <tr key={s.id} style={{ background: si % 2 === 0 ? "white" : "var(--bg3)33" }}>
                              <td style={{ ...S.td, fontWeight: 600, position: "sticky", left: 0, background: si % 2 === 0 ? "white" : "#f0f7ff", zIndex: 1 }}>
                                <div>{s.name}</div>
                                {s.phone && <div style={{ fontSize: 10, color: "var(--accent)" }}><a href={"tel:"+s.phone} style={{ color: "var(--accent)", textDecoration: "none" }}>{s.phone}</a></div>}
                              </td>
                              <td style={{ ...S.td, textAlign: "center", fontSize: 12 }}>{s.grade}</td>
                              <td style={{ ...S.td, fontSize: 11 }}>
                                <div>{s.parent}</div>
                                {s.parentPhone && <a href={"tel:"+s.parentPhone} style={{ color: "var(--accent)", fontSize: 10, textDecoration: "none" }}>{s.parentPhone}</a>}
                              </td>
                              <td style={{ ...S.td, textAlign: "center", fontWeight: 700, color: "var(--accent)" }}>{sLessons.length}</td>
                              {days.map(d => {
                                const l = getLessonOnDay(s.id, d);
                                const mark = getLessonMark(l);
                                const bg = getLessonMarkColor(l);
                                const markColor = !l ? "" : l.status === "cancelled" ? "#e53935" : l.status === "cancelled_excused" ? "#f5a623" : "#4caf50";
                                return (
                                  <td key={d} style={{ ...S.td, textAlign: "center", padding: "2px", background: bg, cursor: l ? "pointer" : "default" }}
                                    title={l ? `${l.subject} ${l.time} — ${l.status || "запланирован"}` : ""}
                                    onClick={() => l && (setEditLesson(l), setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId || ""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds || [], status: l.status || "scheduled" }), setShowModal && setShowModal(true))}>
                                    <span style={{ fontSize: 10, fontWeight: 700, color: markColor }}>{mark}</span>
                                  </td>
                                );
                              })}
                              <td style={{ ...S.td, textAlign: "right", fontWeight: 700, color: "var(--green)", fontSize: 12 }}>{payment.toLocaleString("ru-RU")} ₽</td>
                              <td style={{ ...S.td, textAlign: "right", fontWeight: 700, fontSize: 12, color: balance < 0 ? "var(--red)" : "var(--green)" }}>{balance.toLocaleString("ru-RU")} ₽</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })()}

            {tab === "students" && (
              <div>
                {tStudents.map(s => (
                  <div key={s.id} style={{ ...S.card, marginBottom: 8, display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600 }}>{s.name}</div>
                      <div style={{ fontSize: 12, color: "var(--text3)" }}>{s.school}, {s.grade}</div>
                    </div>
                    <div style={{ fontSize: 13, color: "var(--accent)" }}>{s.subjects.join(", ")}</div>
                  </div>
                ))}
              </div>
            )}
            {tab === "lessons" && (
              <table style={S.table}>
                <thead><tr>{["Дата", "Время", "Предмет", "Тип", "Стоимость", "Статус", ""].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {tLessons.length === 0 && <tr><td colSpan={7} style={{ ...S.td, textAlign: "center", color: "var(--text3)" }}>Занятий нет</td></tr>}
                  {tLessons.map(l => (
                    <tr key={l.id}>
                      <td style={S.td}>{formatDate(l.date)}</td>
                      <td style={S.td}>{l.time}</td>
                      <td style={S.td}>{l.subject}</td>
                      <td style={S.td}>{l.type === "group" ? <span style={S.badge("var(--cyan)")}>Групп.</span> : <span style={S.badge("var(--accent)")}>Инд.</span>}</td>
                      <td style={S.td}>{fmt(l.price)}</td>
                      <td style={S.td}>
                        <span style={S.badge(l.status === "completed" ? "var(--green)" : l.status === "cancelled" ? "var(--red)" : l.status === "cancelled_excused" ? "var(--yellow)" : "var(--text3)")}>
                          {l.status === "completed" ? "✓ Проведён" : l.status === "cancelled" ? "✗ Отменён" : l.status === "cancelled_excused" ? "⚠ Ув." : "📅 Запланирован"}
                        </span>
                      </td>
                      <td style={S.td}>
                        <div style={{ display: "flex", gap: 4 }}>
                          <button onClick={() => { setEditLesson && setEditLesson(l); setLessonForm && setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId || ""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds || [], status: l.status || "scheduled" }); setShowModal && setShowModal(true); }}
                            style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 5, padding: "3px 7px", cursor: "pointer", fontSize: 11, color: "var(--accent)" }}>✏️</button>
                          <button onClick={() => { if(confirm("Удалить занятие?")) setData(d => ({ ...d, lessons: d.lessons.filter(x => x.id !== l.id) })); }}
                            style={{ background: "#e5393511", border: "1px solid var(--red)33", borderRadius: 5, padding: "3px 7px", cursor: "pointer", fontSize: 11, color: "var(--red)" }}>🗑️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {tab === "salary" && (
              <div>
                <div style={{ ...S.card, marginBottom: 12, display: "flex", justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontSize: 12, color: "var(--text3)" }}>Начислено (расчётное)</div>
                    <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 22, color: "var(--yellow)" }}>{fmt(teacherShare)}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 12, color: "var(--text3)" }}>Тип ставки</div>
                    <div style={{ fontWeight: 600 }}>{t.rateType === "percent" ? `${t.rate}%` : `${fmt(t.rate)}/занятие`}</div>
                  </div>
                </div>
                {tSalaries.map(s => (
                  <div key={s.id} style={{ ...S.card, marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontWeight: 600 }}>{s.period}</div>
                      <div style={{ fontSize: 12, color: "var(--text3)" }}>{formatDate(s.date)}</div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ fontWeight: 700 }}>{fmt(s.amount)}</div>
                      <span style={S.badge(s.paid ? "var(--green)" : "var(--yellow)")}>{s.paid ? "Выплачено" : "Ожидает"}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={S.h1}>Преподаватели</div>
        <Btn onClick={() => setShowAdd(true)}>+ Добавить</Btn>
      </div>
      <div style={S.grid(3)}>
        {data.teachers.map((t) => {
          const tLessons = data.lessons.filter(l => l.teacherId === t.id);
          return (
            <div key={t.id} style={{ ...S.card }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12, cursor: "pointer" }} onClick={() => setSelected(t.id)}>
                <Avatar initials={t.avatar} color={t.color} size={48} photo={t.photo} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{t.name}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{t.rateType === "percent" ? `${t.rate}%` : t.rateType === "table" ? "По таблице" : `${fmt(t.rate)}/занятие`}</div>
                </div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 12 }} onClick={() => setSelected(t.id)}>
                {(t.subjects||[]).slice(0, 3).map(s => <span key={s} style={S.tag(t.color)}>{s}</span>)}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12 }}>
                <span style={{ color: "var(--text3)" }}>📚 {tLessons.length} занятий</span>
                <div style={{ display: "flex", gap: 4 }}>
                  <button onClick={e => { e.stopPropagation(); startEdit(t); }} style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 6, padding: "3px 8px", cursor: "pointer", fontSize: 12, color: "var(--accent)" }}>✏️</button>
                  <button onClick={e => { e.stopPropagation(); deleteTeacher(t.id); }} style={{ background: "#e5393511", border: "1px solid var(--red)33", borderRadius: 6, padding: "3px 8px", cursor: "pointer", fontSize: 12, color: "var(--red)" }}>🗑️</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showAdd && (
        <Modal title={editMode ? "Редактировать педагога" : "Новый преподаватель"} onClose={() => { setShowAdd(false); setEditMode(false); }}>
          <Input label="ФИО" value={form.name} onChange={v => setForm(f => ({ ...f, name: v }))} />
          <Input label="Инициалы (2 буквы)" value={form.avatar} onChange={v => setForm(f => ({ ...f, avatar: v }))} />
          <Input label="Цвет" type="color" value={form.color} onChange={v => setForm(f => ({ ...f, color: v }))} />
          <div style={{ marginBottom: 12 }}>
            <label style={S.label}>Фото педагога (необязательно)</label>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              {form.photo && <img src={form.photo} style={{ width: 48, height: 48, borderRadius: "50%", objectFit: "cover" }} />}
              <input type="file" accept="image/*" onChange={e => {
                const file = e.target.files[0]; if (!file) return;
                const reader = new FileReader();
                reader.onload = ev => setForm(f => ({ ...f, photo: ev.target.result }));
                reader.readAsDataURL(file);
              }} style={{ fontSize: 12 }} />
            </div>
          </div>
          <Input label="Предметы (через запятую)" value={form.subjects} onChange={v => setForm(f => ({ ...f, subjects: v }))} />
          <Input label="Телефон" value={form.phone} onChange={v => setForm(f => ({ ...f, phone: v }))} />
          <Input label="Email" value={form.email} onChange={v => setForm(f => ({ ...f, email: v }))} />
          {/* СТАВКИ ПЕДАГОГА */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "var(--accent)", marginBottom: 10, borderBottom: "2px solid var(--border)", paddingBottom: 6 }}>
              💰 Ставки оплаты педагога
            </div>

            {/* Тип основной ставки */}
            <Select label="Тип основной ставки" value={form.rateType} onChange={v => setForm(f => ({ ...f, rateType: v }))}
              options={[{ value: "percent", label: "Процент от урока %" }, { value: "fixed", label: "Фиксированная ₽/занятие" }, { value: "table", label: "По таблице категорий" }]} />

            {form.rateType !== "table" && (
              <Input label={form.rateType === "percent" ? "Процент (%)" : "Базовая ставка (₽/занятие)"} type="number" value={form.rate} onChange={v => setForm(f => ({ ...f, rate: +v }))} />
            )}

            {/* Таблица ставок */}
            <div style={{ marginTop: 10 }}>
              <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8, fontWeight: 600 }}>
                Ставки по категориям (₽ за занятие):
              </div>

              {[
                { title: "🗣️ Логопед — Инд.", color: "#9c27b0", keys: [
                  { key: "logo_ind_30", label: "30 мин" },
                  { key: "logo_ind_40", label: "40 мин" },
                  { key: "logo_ind_60", label: "60 мин" },
                ]},
                { title: "🗣️ Логопед — Группа", color: "#7b1fa2", keys: [
                  { key: "logo_grp_30", label: "30 мин" },
                  { key: "logo_grp_40", label: "40 мин" },
                  { key: "logo_grp_60", label: "60 мин" },
                ]},
                { title: "👶 Инд. — Дошкольники", color: "var(--pink)", keys: [
                  { key: "ind_pre_40", label: "40 мин" },
                  { key: "ind_pre_60", label: "60 мин" },
                  { key: "ind_pre_90", label: "90 мин" },
                  { key: "ind_pre_120", label: "120 мин" },
                ]},
                { title: "👶 Групп. — Дошкольники", color: "var(--orange)", keys: [
                  { key: "grp_pre_40", label: "40 мин" },
                  { key: "grp_pre_60", label: "60 мин" },
                  { key: "grp_pre_90", label: "90 мин" },
                  { key: "grp_pre_120", label: "120 мин" },
                ]},
                { title: "👤 Инд. — 1–8 класс", color: "var(--accent)", keys: [
                  { key: "ind_1_8_40", label: "40 мин" },
                  { key: "ind_1_8_60", label: "60 мин" },
                  { key: "ind_1_8_90", label: "90 мин" },
                  { key: "ind_1_8_120", label: "120 мин" },
                ]},
                { title: "👤 Инд. — 9–11 класс", color: "var(--accent3)", keys: [
                  { key: "ind_9_11_40", label: "40 мин" },
                  { key: "ind_9_11_60", label: "60 мин" },
                  { key: "ind_9_11_90", label: "90 мин" },
                  { key: "ind_9_11_120", label: "120 мин" },
                ]},
                { title: "👥 Групп. — 1–8 класс", color: "var(--green)", keys: [
                  { key: "grp_1_8_40", label: "40 мин" },
                  { key: "grp_1_8_60", label: "60 мин" },
                  { key: "grp_1_8_90", label: "90 мин" },
                  { key: "grp_1_8_120", label: "120 мин" },
                ]},
                { title: "👥 Групп. — 9–11 класс", color: "var(--cyan)", keys: [
                  { key: "grp_9_11_40", label: "40 мин" },
                  { key: "grp_9_11_60", label: "60 мин" },
                  { key: "grp_9_11_90", label: "90 мин" },
                  { key: "grp_9_11_120", label: "120 мин" },
                ]},
              ].map(({ title, color, keys }) => (
                <div key={title} style={{ background: "var(--bg3)", borderRadius: 10, padding: 10, marginBottom: 8, border: `1px solid var(--border)` }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color, marginBottom: 8 }}>{title}</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 6 }}>
                    {keys.map(({ key, label }) => (
                      <div key={key}>
                        <div style={{ fontSize: 10, color: "var(--text3)", marginBottom: 3 }}>{label}</div>
                        <input type="number" placeholder="₽" value={(form.rates || {})[key] || ""}
                          onChange={e => setForm(f => ({ ...f, rates: { ...(f.rates||{}), [key]: +e.target.value } }))}
                          style={{ ...S.input, padding: "5px 8px", fontSize: 12 }} />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <Input label="О преподавателе" value={form.bio} onChange={v => setForm(f => ({ ...f, bio: v }))} />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
            <Btn variant="ghost" onClick={() => { setShowAdd(false); setEditMode(false); }}>Отмена</Btn>
            <Btn onClick={saveTeacher}>{editMode ? "Сохранить изменения" : "Добавить"}</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}


// ─── STUDENT FORM (memoized to prevent re-renders) ────────────────────────────
const StudentForm = React.memo(function StudentForm({ form, setForm, teachers, onSave, onCancel, editMode }) {
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 12px" }}>
        <Input label="ФИО" value={form.name} onChange={v => setForm(f => ({ ...f, name: v }))} />
        <Input label="Класс/группа" value={form.grade} onChange={v => setForm(f => ({ ...f, grade: v }))} />
        <Input label="Дата рождения" type="date" value={form.birthday || ""} onChange={v => setForm(f => ({ ...f, birthday: v }))} />
        <Input label="Возраст" type="number" value={form.age} onChange={v => setForm(f => ({ ...f, age: v }))} />
        <Input label="Телефон ученика" value={form.phone || ""} onChange={v => setForm(f => ({ ...f, phone: v }))} />
        <Input label="Телефон родителя" value={form.parentPhone || ""} onChange={v => setForm(f => ({ ...f, parentPhone: v }))} />
        <Input label="Имя родителя" value={form.parent || ""} onChange={v => setForm(f => ({ ...f, parent: v }))} />
        <Input label="Школа" value={form.school || ""} onChange={v => setForm(f => ({ ...f, school: v }))} />
        <Input label="Адрес" value={form.address || ""} onChange={v => setForm(f => ({ ...f, address: v }))} />
        <Input label="Баланс (₽)" type="number" value={form.balance} onChange={v => setForm(f => ({ ...f, balance: v }))} />
      </div>
      <Input label="Предметы (через запятую)" value={form.subjects} onChange={v => setForm(f => ({ ...f, subjects: v }))} />
      
      {/* Teacher selector - optimized */}
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", fontSize: 10, fontWeight: 800, color: "var(--text3)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.08em" }}>Педагог</label>
        <select value={(form.teacherIds || "").split(",")[0] || ""} 
          onChange={e => setForm(f => ({ ...f, teacherIds: e.target.value }))}
          style={{ width: "100%", background: "var(--bg3)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "9px 13px", color: "var(--text)", fontSize: 13, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          <option value="">Не выбран</option>
          {(teachers || []).map(t => (
            <option key={t.id} value={String(t.id)}>
              {t.name}{(t.subjects||[]).length > 0 ? " — " + (t.subjects||[]).join(", ") : ""}
            </option>
          ))}
        </select>
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", fontSize: 10, fontWeight: 800, color: "var(--text3)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.08em" }}>Статус</label>
        <select value={form.status || "active"} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
          style={{ width: "100%", background: "var(--bg3)", border: "1.5px solid var(--border)", borderRadius: 10, padding: "9px 13px", color: "var(--text)", fontSize: 13, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          <option value="active">✅ Активный</option>
          <option value="new">🟢 Новый</option>
          <option value="trial">🟡 Пробный урок</option>
          <option value="paused">⏸️ На паузе</option>
          <option value="inactive">❌ Неактивный</option>
        </select>
      </div>

      <Input label="Примечания" value={form.notes || ""} onChange={v => setForm(f => ({ ...f, notes: v }))} />

      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 12 }}>
        <button onClick={onCancel} style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 10, padding: "9px 20px", cursor: "pointer", fontSize: 13, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Отмена</button>
        <button onClick={onSave} style={{ background: "linear-gradient(135deg,#1da0d4,#0d8ab8)", color: "white", border: "none", borderRadius: 10, padding: "9px 24px", cursor: "pointer", fontSize: 13, fontWeight: 700, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          {editMode ? "Сохранить изменения" : "Добавить"}
        </button>
      </div>
    </div>
  );
});

// ─── STUDENTS ─────────────────────────────────────────────────────────────────
function Students({ data, setData }) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState("");
  const [importError, setImportError] = useState("");
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 30;
  const [form, setForm] = useState({ name: "", age: "", birthday: "", phone: "", parent: "", parentPhone: "", school: "", grade: "", address: "", subjects: "", teacherIds: "", balance: 0, notes: "", status: "active" });

  function startEditStudent(s) {
    setForm({ 
      ...s, 
      subjects: Array.isArray(s.subjects) ? s.subjects.join(", ") : (s.subjects || ""),
      phone: s.phone || "",
      parent: s.parent || "",
      parentPhone: s.parentPhone || "",
      birthday: s.birthday || "",
      notes: s.notes || "",
      teacherIds: s.teacherIds || ""
    });
    setEditMode(true);
    setShowAdd(true);
  }

  function deleteStudent(id) {
    if (!confirm("Удалить ученика?")) return;
    setData(d => ({ ...d, students: d.students.filter(s => s.id !== id) }));
    setSelected(null);
  }

  function saveStudent() {
    const updated = { ...form, age: +form.age, balance: +form.balance, subjects: form.subjects.split(",").map(s => s.trim()).filter(Boolean) };
    if (editMode) {
      setData(d => ({ ...d, students: d.students.map(s => s.id === updated.id ? updated : s) }));
    } else {
      setData(d => ({ ...d, students: [...d.students, { ...updated, id: Date.now() }] }));
    }
    setShowAdd(false);
    setEditMode(false);
    setForm({ name: "", age: "", phone: "", parent: "", parentPhone: "", school: "", grade: "", address: "", subjects: "", balance: 0, notes: "" });
  }

  // Export students to CSV
  function exportCSV() {
    const headers = ["ФИО","Возраст","Телефон","Родитель","Тел.родителя","Школа","Класс","Адрес","Предметы","Баланс","Примечания"];
    const rows = (data.students || []).map(s => [
      s.name, s.age, s.phone, s.parent, s.parentPhone,
      s.school, s.grade, s.address,
      (s.subjects || []).join("; "), s.balance, s.notes || ""
    ]);
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v||"").replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "ученики_гений.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  // Export one student as form/anketa
  function exportAnketa(s) {
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Анкета — ${s.name}</title>
    <style>body{font-family:Arial,sans-serif;max-width:600px;margin:40px auto;padding:20px;}
    h1{color:#1da0d4;border-bottom:3px solid #1da0d4;padding-bottom:10px;}
    h2{color:#5cb85c;font-size:14px;margin-top:20px;}
    .row{display:flex;gap:20px;margin-bottom:8px;}
    .label{font-weight:bold;color:#666;min-width:160px;font-size:13px;}
    .val{font-size:13px;}
    .badge{background:#1da0d422;color:#1da0d4;padding:2px 8px;border-radius:4px;font-size:12px;margin-right:4px;}
    .footer{margin-top:30px;border-top:1px solid #ddd;padding-top:10px;font-size:11px;color:#999;}
    </style></head><body>
    <h1>🎓 Анкета ученика</h1>
    <h2>ЛИЧНЫЕ ДАННЫЕ</h2>
    <div class="row"><div class="label">ФИО:</div><div class="val"><b>${s.name}</b></div></div>
    <div class="row"><div class="label">Возраст:</div><div class="val">${s.age} лет</div></div>
    <div class="row"><div class="label">Телефон:</div><div class="val">${s.phone}</div></div>
    <h2>РОДИТЕЛЬ / ОПЕКУН</h2>
    <div class="row"><div class="label">ФИО родителя:</div><div class="val">${s.parent}</div></div>
    <div class="row"><div class="label">Телефон:</div><div class="val">${s.parentPhone}</div></div>
    <h2>УЧЁБА</h2>
    <div class="row"><div class="label">Школа:</div><div class="val">${s.school}</div></div>
    <div class="row"><div class="label">Класс:</div><div class="val">${s.grade}</div></div>
    <div class="row"><div class="label">Адрес:</div><div class="val">${s.address}</div></div>
    <div class="row"><div class="label">Предметы:</div><div class="val">${(s.subjects||[]).map(sub=>`<span class="badge">${sub}</span>`).join("")}</div></div>
    <div class="row"><div class="label">Баланс:</div><div class="val"><b style="color:#4caf50">${s.balance} ₽</b></div></div>
    ${s.notes ? `<div class="row"><div class="label">Примечания:</div><div class="val">${s.notes}</div></div>` : ""}
    <div class="footer">Образовательный центр «ГЕНИЙ» · Дата выгрузки: ${new Date().toLocaleDateString("ru-RU")}</div>
    </body></html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `анкета_${s.name.replace(/ /g,"_")}.html`; a.click();
    URL.revokeObjectURL(url);
  }

  // Parse CSV line handling quotes
  function parseCSVLine(line) {
    const result = [];
    let cur = "", inQ = false;
    for (let i = 0; i < line.length; i++) {
      if (line[i] === '"') { if (inQ && line[i+1] === '"') { cur += '"'; i++; } else inQ = !inQ; }
      else if (line[i] === ',' && !inQ) { result.push(cur.trim()); cur = ""; }
      else cur += line[i];
    }
    result.push(cur.trim());
    return result;
  }

  // Import from Excel/CSV - flexible column detection
  function importCSV() {
    try {
      const lines = importText.trim().split(/\r?\n/).filter(l => l.trim());
      if (lines.length < 2) { setImportError("Файл пустой или неверный формат"); return; }
      const delim = lines[0].split(";").length > lines[0].split(",").length ? ";" : ",";

      function parseLine(line) {
        const result = []; let cur = "", inQ = false;
        for (let i = 0; i < line.length; i++) {
          if (line[i] === '"') { if (inQ && line[i+1] === '"') { cur += '"'; i++; } else inQ = !inQ; }
          else if (line[i] === delim && !inQ) { result.push(cur.trim()); cur = ""; }
          else cur += line[i];
        }
        result.push(cur.trim()); return result;
      }

      // Detect header row - find row with ФИО or similar
      const headerLine = lines[0];
      const headers = parseLine(headerLine).map(h => h.toLowerCase().trim());

      // Map column indexes by header names
      function findCol(...names) {
        for (const n of names) {
          const idx = headers.findIndex(h => h.includes(n));
          if (idx >= 0) return idx;
        }
        return -1;
      }

      const colName = findCol("фио", "имя", "ученик", "name");
      const colBirthday = findCol("дата рожд", "birthday", "дата_рожд");
      const colAge = findCol("возраст", "age");
      const colPhone = findCol("телефон уч", "тел уч", "phone");
      const colParent = findCol("родитель", "parent", "контакт");
      const colParentPhone = findCol("тел.родит", "тел родит", "тел.роди", "контакт");
      const colSchool = findCol("школа", "school");
      const colGrade = findCol("класс", "grade");
      const colAddress = findCol("адрес", "address");
      const colSubjects = findCol("предмет", "subject");
      const colBalance = findCol("баланс", "balance", "долг");
      const colNotes = findCol("примеч", "notes", "заметк");

      const hasHeaders = colName >= 0 || colGrade >= 0;
      const dataLines = hasHeaders ? lines.slice(1) : lines;

      const newStudents = dataLines.map((line, idx) => {
        const c = parseLine(line);
        if (!c[0] && !c[1]) return null; // skip empty rows
        const name = colName >= 0 ? (c[colName] || "") : (c[0] || "");
        if (!name || name.length < 2) return null;
        const grade = colGrade >= 0 ? (c[colGrade] || "") : (c[7] || "");
        const birthday = colBirthday >= 0 ? (c[colBirthday] || "") : (c[1] || "");
        const age = colAge >= 0 ? (+c[colAge] || 0) : (birthday ? Math.floor((new Date() - new Date(birthday)) / (365.25*24*3600*1000)) : 0);
        return {
          id: Date.now() + idx,
          name,
          birthday,
          age: age || 0,
          phone: colPhone >= 0 ? (c[colPhone] || "") : (c[3] || ""),
          parent: colParent >= 0 ? (c[colParent] || "") : (c[4] || ""),
          parentPhone: colParentPhone >= 0 ? (c[colParentPhone] || "") : (c[5] || ""),
          school: colSchool >= 0 ? (c[colSchool] || "") : (c[6] || ""),
          grade,
          address: colAddress >= 0 ? (c[colAddress] || "") : (c[8] || ""),
          subjects: colSubjects >= 0 ? ((c[colSubjects] || "").split(/[;,]/).map(s=>s.trim()).filter(Boolean)) : [],
          balance: colBalance >= 0 ? (+c[colBalance] || 0) : 0,
          notes: colNotes >= 0 ? (c[colNotes] || "") : "",
          status: "active",
          teacherIds: ""
        };
      }).filter(Boolean);

      if (newStudents.length === 0) { setImportError("Не найдено учеников. Проверьте формат файла."); return; }
      setData(d => ({ ...d, students: [...(d.students||[]), ...newStudents] }));
      setShowImport(false); setImportText(""); setImportError("");
      alert("✅ Импортировано " + newStudents.length + " учеников!");
    } catch(e) { setImportError("Ошибка: " + e.message); }
  }

  // Import from Excel file using SheetJS
  function handleFileImport(file) {
    if (!file) return;
    const ext = file.name.split(".").pop().toLowerCase();
    if (ext === "xlsx" || ext === "xls") {
      // Load SheetJS dynamically
      const script = document.createElement("script");
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
      script.onload = () => {
        const reader = new FileReader();
        reader.onload = ev => {
          try {
            const data = new Uint8Array(ev.target.result);
            const workbook = XLSX.read(data, { type: "array" });
            // Get first sheet
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            // Convert to CSV
            const csv = XLSX.utils.sheet_to_csv(sheet, { FS: ";", RS: "\n" });
            setImportText(csv);
            setImportError("✅ Excel файл прочитан. Проверьте данные и нажмите «Импортировать».");
          } catch(e) { setImportError("Ошибка чтения Excel: " + e.message); }
        };
        reader.readAsArrayBuffer(file);
      };
      script.onerror = () => setImportError("Ошибка загрузки библиотеки Excel. Проверьте интернет.");
      if (!window.XLSX) {
        document.head.appendChild(script);
      } else {
        // Already loaded
        const reader = new FileReader();
        reader.onload = ev => {
          try {
            const data = new Uint8Array(ev.target.result);
            const workbook = window.XLSX.read(data, { type: "array" });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const csv = window.XLSX.utils.sheet_to_csv(sheet, { FS: ";", RS: "\n" });
            setImportText(csv);
            setImportError("✅ Excel файл прочитан. Проверьте данные и нажмите «Импортировать».");
          } catch(e) { setImportError("Ошибка чтения Excel: " + e.message); }
        };
        reader.readAsArrayBuffer(file);
      }
    } else {
      // CSV or TXT file
      const reader = new FileReader();
      reader.onload = ev => {
        setImportText(ev.target.result);
        setImportError("✅ Файл загружен. Нажмите «Импортировать».");
      };
      // Try UTF-8 first, then windows-1251
      reader.readAsText(file, "utf-8");
    }
  }

  const allStudents = data.students || [];
  const filtered = allStudents.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    (s.school || "").toLowerCase().includes(search.toLowerCase()) ||
    (s.grade || "").toLowerCase().includes(search.toLowerCase()) ||
    (s.phone || "").includes(search) ||
    (s.parentPhone || "").includes(search) ||
    (s.parent || "").toLowerCase().includes(search.toLowerCase())
  );

  if (selected) {
    const s = data.students.find(s => s.id === selected);
    if (!s) { setSelected(null); return null; }
    const sPayments = data.payments.filter(p => p.studentId === s.id);
    const sLessons = data.lessons.filter(l => l.studentId === s.id || l.studentIds?.some(si => si.id === s.id));
    const attendanceRate = sLessons.length > 0 ? Math.round((sLessons.filter(l => l.attended !== false).length / sLessons.length) * 100) : 100;
    const sTeacherIds = (s.teacherIds || "").split(",").map(x => x.trim()).filter(Boolean).map(Number);
    const sTeachers = (data.teachers || []).filter(t => sTeacherIds.includes(t.id));
    const age = s.birthday ? Math.floor((new Date() - new Date(s.birthday)) / (365.25 * 24 * 3600 * 1000)) : s.age;
    return (
      <div className="fade-in">
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
          <Btn variant="ghost" onClick={() => setSelected(null)}>← Назад</Btn>
          <div style={S.h1}>{s.name}</div>
          <span style={{ ...S.badge(s.balance > 0 ? "var(--green)" : s.balance < 0 ? "var(--red)" : "var(--text3)"), fontSize: 13 }}>Баланс: {fmt(s.balance)}</span>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <Btn variant="ghost" onClick={() => exportAnketa(s)}>📄 Анкета</Btn>
            <Btn variant="success" onClick={() => {
              const amount = prompt("Сумма оплаты (₽):");
              if (!amount || isNaN(+amount)) return;
              const payment = { id: Date.now(), studentId: s.id, type: "income", amount: +amount, date: new Date().toISOString().split("T")[0], description: "Оплата — " + s.name, method: "cash" };
              setData(d => ({ ...d, payments: [...d.payments, payment], students: d.students.map(st => st.id === s.id ? { ...st, balance: st.balance + +amount } : st) }));
            }}>💳 Принять оплату</Btn>
            <Btn variant="ghost" onClick={() => startEditStudent(s)}>✏️ Редактировать</Btn>
            <Btn variant="danger" onClick={() => deleteStudent(s.id)}>🗑️ Удалить</Btn>
          </div>
        </div>
        <div style={S.grid(3)}>
          <div style={{ ...S.card, gridColumn: "1" }}>
            <div style={S.h2}>Данные ученика</div>
            {[["Возраст", s.age + " лет"], ["Телефон", s.phone], ["Родитель", s.parent], ["Тел. родителя", s.parentPhone], ["Школа", s.school], ["Класс", s.grade], ["Адрес", s.address]].map(([k, v]) => (
              <div key={k} style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: "var(--text3)" }}>{k}</div>
                <div style={{ fontSize: 13 }}>{v}</div>
              </div>
            ))}
            {s.notes && <div style={{ marginTop: 8, padding: 8, background: "var(--yellow)11", borderRadius: 6, fontSize: 12 }}>📝 {s.notes}</div>}
          </div>
          <div style={{ gridColumn: "2/-1" }}>
            <div style={S.card}>
              <div style={S.h2}>Предметы</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
                {s.subjects.map(sub => <span key={sub} style={S.tag("var(--accent)")}>{sub}</span>)}
              </div>
              <div style={S.h2}>История платежей</div>
              <table style={S.table}>
                <thead><tr>{["Дата", "Сумма", "Метод", "Примечание"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {sPayments.map(p => (
                    <tr key={p.id}>
                      <td style={S.td}>{formatDate(p.date)}</td>
                      <td style={S.td}><span style={{ color: "var(--green)", fontWeight: 600 }}>+{fmt(p.amount)}</span></td>
                      <td style={S.td}>{p.method}</td>
                      <td style={S.td}>{p.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
        <div style={S.h1}>Ученики</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} placeholder="🔍 Поиск..." style={{ ...S.input, width: 200 }} />
          <Btn variant="ghost" onClick={exportCSV}>📥 Экспорт CSV</Btn>
          <Btn variant="ghost" onClick={() => setShowImport(true)}>📤 Импорт CSV</Btn>
          <Btn onClick={() => setShowAdd(true)}>+ Добавить</Btn>
        </div>
      </div>
      <div style={S.card}>
        <table style={S.table}>
          <thead>
            <tr>{["Ученик", "Класс", "Школа", "Родитель", "Предметы", "Баланс", ""].map(h => <th key={h} style={S.th}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map(s => (
              <tr key={s.id} style={{ cursor: "pointer" }} onClick={() => setSelected(s.id)}>
                <td style={S.td}>
                  <div style={{ fontWeight: 600 }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{s.age} лет · {s.phone}</div>
                </td>
                <td style={S.td}>{s.grade}</td>
                <td style={S.td}>{s.school}</td>
                <td style={S.td}><div>{s.parent}</div><div style={{ fontSize: 11, color: "var(--text3)" }}>{s.parentPhone}</div></td>
                <td style={S.td}><div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>{s.subjects.map(sub => <span key={sub} style={S.tag("var(--accent)")}>{sub}</span>)}</div></td>
                <td style={S.td}><span style={{ color: s.balance > 0 ? "var(--green)" : s.balance < 0 ? "var(--red)" : "var(--text3)", fontWeight: 600 }}>{fmt(s.balance)}</span></td>
                <td style={S.td}><span style={{ color: "var(--accent)", fontSize: 16 }}>→</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAdd && (
        <Modal title={editMode ? "Редактировать ученика" : "Новый ученик"} onClose={() => { setShowAdd(false); setEditMode(false); }} width={560}>
          <StudentForm
            form={form}
            setForm={setForm}
            teachers={data.teachers || []}
            editMode={editMode}
            onSave={saveStudent}
            onCancel={() => { setShowAdd(false); setEditMode(false); }}
          />
        </Modal>
      )}

            {showImport && (
        <Modal title="📤 Импорт учеников из CSV" onClose={() => setShowImport(false)} width={560}>
          <div style={{ padding: 12, background: "var(--bg3)", borderRadius: 8, marginBottom: 16, fontSize: 12, color: "var(--text2)" }}>
            <div style={{ fontWeight: 700, marginBottom: 6 }}>📋 Формат файла (первая строка — заголовки):</div>
            <div style={{ fontFamily: "monospace", fontSize: 10, background: "var(--bg4)", padding: 8, borderRadius: 6, lineHeight: 1.8 }}>
              ФИО; Дата рождения; Возраст; Телефон; Родитель; Тел.родителя; Школа; Класс; Адрес; Предметы; Баланс; Примечания
            </div>
            <div style={{ marginTop: 6 }}>• Разделитель: точка с запятой (;) или запятая (,)</div>
            <div>• Дата рождения: формат ДД.ММ.ГГГГ или ГГГГ-ММ-ДД</div>
            <div>• Предметы разделяй точкой с запятой внутри ячейки</div>
            <div>• Excel: сохрани как CSV (UTF-8) перед импортом</div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={S.label}>Вставь содержимое CSV файла:</label>
            <textarea value={importText} onChange={e => setImportText(e.target.value)} placeholder={"ФИО,Возраст,Телефон,...\nИван Иванов,15,+7 999..."}
              style={{ ...S.input, minHeight: 150, resize: "vertical", fontFamily: "monospace", fontSize: 12 }} />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={S.label}>Или загрузи файл:</label>
            <input type="file" accept=".csv,.txt,.xlsx,.xls" onChange={e => handleFileImport(e.target.files[0])} style={{ ...S.input }} />
            <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 4 }}>Поддерживаются: CSV, TXT, XLSX (Excel)</div>
          </div>
          {importError && <div style={{ color: "var(--red)", fontSize: 12, marginBottom: 12 }}>⚠️ {importError}</div>}
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <Btn variant="ghost" onClick={() => setShowImport(false)}>Отмена</Btn>
            <Btn onClick={importCSV}>📤 Импортировать</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── COURSES ──────────────────────────────────────────────────────────────────
function Courses({ data }) {
  const categories = [...new Set(data.courses.map(c => c.category))];
  const [search, setSearch] = useState("");
  const filtered = data.courses.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  const CAT_COLORS = { "Экзамены": "var(--red)", "Точные науки": "var(--accent)", "Естественные науки": "var(--green)", "Гуманитарные": "var(--yellow)", "Начальная школа": "var(--cyan)", "Средняя школа": "var(--pink)", "Старшая школа": "var(--orange)", "Дошкольники": "var(--green)", "Развитие": "var(--cyan)", "Специалисты": "var(--pink)", "Творчество": "var(--yellow)", "Онлайн": "var(--accent)", "Индивидуальные": "var(--text3)" };

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={S.h1}>Каталог курсов</div>
          <div style={{ color: "var(--text3)", fontSize: 13 }}>{data.courses.length} курсов</div>
        </div>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Поиск..." style={{ ...S.input, width: 220 }} />
      </div>
      {categories.map(cat => {
        const catCourses = filtered.filter(c => c.category === cat);
        if (catCourses.length === 0) return null;
        const color = CAT_COLORS[cat] || "var(--accent)";
        return (
          <div key={cat} style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div style={{ width: 4, height: 20, background: color, borderRadius: 2 }} />
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 600, fontSize: 14, color }}>{cat}</div>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>({catCourses.length})</div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 8 }}>
              {catCourses.map(c => (
                <div key={c.id} style={{ ...S.card, padding: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{c.name}</div>
                    {c.lessonsCount > 0 && <div style={{ fontSize: 11, color: "var(--text3)" }}>{c.lessonsCount} занятий</div>}
                  </div>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0 }} />
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── SCHEDULE ─────────────────────────────────────────────────────────────────
const TIME_SLOTS = ["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00","18:30","19:00","19:30","20:00"];
const DAY_NAMES = ["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"];
const DAY_SHORT = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"];

function Schedule({ data, setData }) {
  const [activeDay, setActiveDay] = useState(0); // 0=Пн..6=Вс, 7=Вся неделя
  const [weekOffset, setWeekOffset] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [editLesson, setEditLesson] = useState(null);
  const [scheduleSearch, setScheduleSearch] = useState("");
  const [lessonForm, setLessonForm] = useState({
    teacherId: "", subject: "", type: "individual", studentId: "",
    date: "", time: "10:00", duration: 60, price: 0, room: "Каб. 1",
    series: false, studentIds: []
  });

  const teachers = data.teachers || [];
  const lessons = data.lessons || [];
  const students = data.students || [];

  const weekDates = getWeekDates(weekOffset);
  const weekStr = weekDates.map(d => dateStr(d));

  // Get lessons for a specific day and time and teacher
  function getLessonsAt(dayIdx, time, teacherId) {
    const date = weekStr[dayIdx];
    return lessons.filter(l => l.date === date && l.time === time && l.teacherId === teacherId);
  }

  // Get all lessons for a day
  function getDayLessons(dayIdx) {
    const date = weekStr[dayIdx];
    return lessons.filter(l => l.date === date);
  }

  function openNew(date, time, teacherId) {
    setEditLesson(null);
    setLessonForm({ teacherId: teacherId || "", subject: "", type: "individual", studentId: "", date: date || "", time: time || "10:00", duration: 60, price: 0, room: "Каб. 1", series: false, studentIds: [] });
    setShowModal(true);
  }

  function saveLesson() {
    const baseLesson = {
      ...lessonForm,
      teacherId: +lessonForm.teacherId,
      studentId: lessonForm.type === "individual" ? +lessonForm.studentId : null,
      price: lessonForm.type === "group"
        ? (lessonForm.studentIds || []).reduce((s, si) => s + (si.price || 0), 0)
        : +lessonForm.price,
      duration: +lessonForm.duration,
      status: lessonForm.status || "scheduled"
    };

    if (editLesson) {
      // Just update existing
      setData(d => ({ ...d, lessons: d.lessons.map(l => l.id === editLesson.id ? { ...baseLesson, id: editLesson.id } : l) }));
      setShowModal(false);
      return;
    }

    // Create recurring lessons
    if (lessonForm.series && (lessonForm.repeatDays || []).length > 0) {
      const repeatDays = lessonForm.repeatDays; // 0=Mon..6=Sun
      const weeks = lessonForm.repeatWeeks || 4;
      const startDate = new Date(lessonForm.date);
      const untilDate = lessonForm.repeatUntil ? new Date(lessonForm.repeatUntil) : null;

      const newLessons = [];
      for (let w = 0; w < weeks; w++) {
        for (const dayIdx of repeatDays) {
          // Calculate date for this day in this week
          const d = new Date(startDate);
          // Find the next occurrence of dayIdx from startDate
          const startDayOfWeek = (startDate.getDay() + 6) % 7; // Mon=0
          let diff = dayIdx - startDayOfWeek + (w * 7);
          if (w === 0 && diff < 0) diff += 7;
          d.setDate(startDate.getDate() + diff);
          
          if (untilDate && d > untilDate) continue;
          
          const dateStr2 = d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
          newLessons.push({
            ...baseLesson,
            id: Date.now() + newLessons.length + Math.random(),
            date: dateStr2,
            series: true,
            seriesId: Date.now()
          });
        }
      }

      // Remove duplicates same date+time+teacher
      const unique = newLessons.filter((l, i, arr) =>
        arr.findIndex(x => x.date === l.date && x.time === l.time && x.teacherId === l.teacherId) === i
      );

      setData(d => ({ ...d, lessons: [...d.lessons, ...unique] }));
      setShowModal(false);
      alert("✅ Создано " + unique.length + " занятий!");
      return;
    }

    // Single lesson
    setData(d => ({ ...d, lessons: [...d.lessons, { ...baseLesson, id: Date.now() }] }));
    setShowModal(false);
  }

  const LessonCell = ({ l }) => {
    const t = getTeacher(teachers, l.teacherId);
    const st = l.type === "individual" ? getStudent(students, l.studentId) : null;
    const statusColors = { completed: "#4caf50", cancelled: "#e53935", cancelled_excused: "#f5a623", scheduled: t?.color || "#1da0d4" };
    const statusIcons = { completed: "✅", cancelled: "❌", cancelled_excused: "⚠️", scheduled: "" };
    const cellColor = statusColors[l.status] || t?.color || "#1da0d4";
    const isCancelled = l.status === "cancelled" || l.status === "cancelled_excused";
    return (
      <div
        onClick={e => { e.stopPropagation(); setEditLesson(l); setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId || ""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds || [], status: l.status || "scheduled" }); setShowModal(true); }}
        title={st ? `${st.name}${st.phone ? " · " + st.phone : ""}` : ""}
        style={{ background: cellColor + (isCancelled ? "10" : "18"), border: `1.5px solid ${cellColor}55`, borderRadius: 6, padding: "3px 6px", marginBottom: 2, cursor: "pointer", fontSize: 11, lineHeight: 1.3, opacity: isCancelled ? 0.6 : 1, textDecoration: isCancelled ? "line-through" : "none" }}
      >
        <div style={{ fontWeight: 700, color: cellColor, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 130, display: "flex", alignItems: "center", gap: 3 }}>
          {l.type === "group" && <span style={{ background: "#00bcd4", color: "white", borderRadius: 3, padding: "0 3px", fontSize: 9 }}>ГР</span>}
          {statusIcons[l.status] && <span style={{ fontSize: 9 }}>{statusIcons[l.status]}</span>}
          <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{l.subject}</span>
        </div>
        {st && (
          <div style={{ fontSize: 10 }}>
            <div style={{ color: "var(--text2)", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 130 }}>{st.name}</div>
            {st.phone && (
              <a href={"tel:" + st.phone} onClick={e => e.stopPropagation()}
                style={{ color: "var(--accent)", fontSize: 10, textDecoration: "none", fontWeight: 600, display: "flex", alignItems: "center", gap: 2 }}>
                📞 {st.phone}
              </a>
            )}
            {!st.phone && st.parentPhone && (
              <a href={"tel:" + st.parentPhone} onClick={e => e.stopPropagation()}
                style={{ color: "var(--text3)", fontSize: 10, textDecoration: "none", display: "flex", alignItems: "center", gap: 2 }}>
                📞 {st.parentPhone}
              </a>
            )}
          </div>
        )}
        {l.type === "group" && <div style={{ color: "var(--text2)", fontSize: 10 }}>{(l.studentIds || []).length} уч.</div>}
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ color: "var(--text3)", fontSize: 10 }}>{l.duration} мин · {fmt(l.price)}</span>
          {l.paid ? <span style={{ color: "var(--green)", fontSize: 10 }}>✅</span> : <span style={{ color: "#e5393555", fontSize: 10 }}>○</span>}
        </div>
      </div>
    );
  };

  // Compact week overview: days as tabs, teachers as columns
  const renderDayTable = (dayIdx) => {
    const date = weekStr[dayIdx];
    const isToday = date === dateStr(new Date());
    const now = new Date();
    const currentTime = now.getHours().toString().padStart(2,"0") + ":" + (now.getMinutes() < 30 ? "00" : "30");
    const isCurrentDay = date === dateStr(now);

    return (
      <div style={{ overflowX: "auto", position: "relative" }}>
        <table style={{ ...S.table, tableLayout: "fixed", minWidth: teachers.length * 160 + 64, borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={{ ...S.th, width: 64, background: isToday ? "#1da0d430" : "var(--bg3)", position: "sticky", left: 0, zIndex: 3, borderRight: "2px solid var(--border)" }}>
                Время
              </th>
              {teachers.map(t => (
                <th key={t.id} style={{ ...S.th, minWidth: 160, background: isToday ? t.color + "15" : "var(--bg3)", borderLeft: "3px solid " + t.color + "60", borderRight: "1px solid var(--border)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: t.color, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                      {(t.avatar || t.name.slice(0,2)).toUpperCase()}
                    </div>
                    <div style={{ overflow: "hidden" }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: t.color, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.name.split(" ")[0]}</div>
                      <div style={{ fontSize: 10, color: "var(--text3)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.name.split(" ").slice(1).join(" ")}</div>
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {TIME_SLOTS.map((time, ti) => {
              const isHour = time.endsWith(":00");
              const isCurrentSlot = isCurrentDay && time === currentTime;
              return (
                <tr key={time} style={{ background: isCurrentSlot ? "#1da0d408" : isHour ? "white" : "#f8fbff" }}>
                  <td style={{
                    padding: "0 8px", fontSize: isHour ? 12 : 10,
                    color: isCurrentSlot ? "var(--accent)" : isHour ? "var(--text2)" : "var(--text3)",
                    fontWeight: isHour ? 700 : 400,
                    height: isHour ? 40 : 32,
                    borderRight: "2px solid var(--border)",
                    borderTop: isHour ? "1px solid var(--border)" : "none",
                    background: isCurrentSlot ? "#1da0d415" : "var(--bg2)",
                    position: "sticky", left: 0, zIndex: 2,
                    verticalAlign: "middle"
                  }}>
                    {isCurrentSlot ? "▶ " + time : time}
                  </td>
                  {teachers.map(t => {
                    const cellLessons = getLessonsAt(dayIdx, time, t.id);
                    return (
                      <td key={t.id} style={{
                        padding: cellLessons.length > 0 ? 3 : 0,
                        verticalAlign: "top",
                        minHeight: isHour ? 40 : 32,
                        height: isHour ? 40 : 32,
                        cursor: "pointer",
                        borderLeft: "3px solid " + t.color + "25",
                        borderRight: "1px solid var(--border)",
                        borderTop: isHour ? "1px solid var(--border)" : "1px solid var(--border)22",
                        background: isCurrentSlot ? t.color + "08" : "transparent",
                        transition: "background 0.1s"
                      }}
                        onClick={() => cellLessons.length === 0 && openNew(date, time, String(t.id))}
                        onMouseEnter={e => { if(cellLessons.length === 0) e.currentTarget.style.background = t.color + "12"; }}
                        onMouseLeave={e => { if(cellLessons.length === 0) e.currentTarget.style.background = isCurrentSlot ? t.color + "08" : "transparent"; }}>
                        {cellLessons.map(l => <LessonCell key={l.id} l={l} />)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  // Full week overview: grouped by day
  const renderFullWeek = () => (
    <div>
      {weekDates.map((d, di) => {
        const dayLessons = getDayLessons(di);
        const isToday = dateStr(d) === dateStr(new Date());
        return (
          <div key={di} style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8, padding: "8px 12px", background: isToday ? "linear-gradient(135deg, #1da0d4, #0d8ab8)" : "var(--bg3)", borderRadius: 10, border: isToday ? "none" : "1px solid var(--border)" }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 14, color: isToday ? "white" : "var(--text)" }}>{DAY_NAMES[di]}</div>
              <div style={{ fontSize: 12, color: isToday ? "rgba(255,255,255,0.8)" : "var(--text3)" }}>{d.toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}</div>
              <div style={{ fontSize: 12, color: isToday ? "rgba(255,255,255,0.8)" : "var(--text3)" }}>{dayLessons.length} занятий</div>
              {isToday && <span style={{ background: "rgba(255,255,255,0.25)", color: "white", borderRadius: 6, padding: "1px 8px", fontSize: 11 }}>Сегодня</span>}
              <button onClick={() => openNew(dateStr(d), "10:00", "")}
                style={{ marginLeft: "auto", background: isToday ? "rgba(255,255,255,0.25)" : "var(--accent)", color: "white", border: "none", borderRadius: 6, padding: "3px 10px", cursor: "pointer", fontSize: 11, fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 600 }}>
                + Занятие
              </button>
            </div>
            {dayLessons.length > 0 ? (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, paddingLeft: 12 }}>
                {dayLessons.sort((a,b) => a.time > b.time ? 1 : -1).map(l => {
                  const t = getTeacher(teachers, l.teacherId);
                  const st = l.type === "individual" ? getStudent(students, l.studentId) : null;
                  return (
                    <div key={l.id}
                      style={{ background: "white", border: `2px solid ${t?.color || "#1da0d4"}44`, borderLeft: `4px solid ${t?.color || "#1da0d4"}`, borderRadius: 8, padding: "8px 12px", minWidth: 180, maxWidth: 220, boxShadow: "0 2px 6px rgba(0,0,0,0.06)", position: "relative" }}>
                      <div onClick={() => { setEditLesson(l); setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId || ""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds || [], status: l.status || "scheduled" }); setShowModal(true); }} style={{ cursor: "pointer" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: t?.color }}>{l.time}</div>
                        {l.type === "group" && <span style={{ background: "#00bcd4", color: "white", borderRadius: 4, padding: "1px 6px", fontSize: 10 }}>ГР</span>}
                      </div>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{l.subject}</div>
                      <div style={{ fontSize: 11, color: "var(--text2)" }}>{t?.name}</div>
                      {st && <div style={{ fontSize: 11, color: "var(--text3)" }}>{st.name}</div>}
                      {l.type === "group" && <div style={{ fontSize: 11, color: "var(--text3)" }}>{(l.studentIds || []).length} учеников</div>}
                      <div style={{ fontSize: 11, color: "var(--green)", fontWeight: 600, marginTop: 4 }}>{fmt(l.price)} · {l.duration} мин</div>
                      </div>
                      <div style={{ display: "flex", gap: 4, marginTop: 6, borderTop: "1px solid var(--border)", paddingTop: 5 }}>
                        <button onClick={e => { e.stopPropagation(); setEditLesson(l); setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId || ""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds || [], status: l.status || "scheduled" }); setShowModal(true); }}
                          style={{ flex: 1, background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 5, padding: "3px 0", cursor: "pointer", fontSize: 11, color: "var(--accent)" }}>✏️ Изменить</button>
                        <button onClick={e => { e.stopPropagation(); if(confirm("Удалить занятие?")) setData(d => ({ ...d, lessons: d.lessons.filter(x => x.id !== l.id) })); }}
                          style={{ background: "#e5393511", border: "1px solid var(--red)33", borderRadius: 5, padding: "3px 8px", cursor: "pointer", fontSize: 11, color: "var(--red)" }}>🗑️</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ paddingLeft: 12, fontSize: 12, color: "var(--text3)" }}>Нет занятий</div>
            )}
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div style={S.h1}>Расписание</div>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="ghost" onClick={() => window.print()}>🖨️ Печать</Btn>
          <Btn onClick={() => openNew("", "", "")}>+ Занятие</Btn>
        </div>
      </div>

      {/* Search bar */}
      <div style={{ marginBottom: 12, position: "relative" }}>
        <input
          value={scheduleSearch}
          onChange={e => setScheduleSearch(e.target.value)}
          placeholder="🔍 Поиск ученика по имени или номеру телефона..."
          style={{ ...S.input, width: "100%", fontSize: 13 }}
        />
        {scheduleSearch && (() => {
          const q = scheduleSearch.toLowerCase();
          const found = students.filter(s =>
            s.name.toLowerCase().includes(q) ||
            (s.phone || "").includes(scheduleSearch) ||
            (s.parentPhone || "").includes(scheduleSearch) ||
            (s.parent || "").toLowerCase().includes(q)
          );
          const foundLessons = lessons.filter(l => {
            if (l.type === "individual") {
              const s = found.find(x => x.id === l.studentId);
              return !!s;
            }
            return (l.studentIds || []).some(si => found.find(x => x.id === si.id));
          });
          return (
            <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 12, boxShadow: "0 8px 24px rgba(0,0,0,0.12)", zIndex: 100, maxHeight: 360, overflowY: "auto", marginTop: 4 }}>
              {found.length === 0 ? (
                <div style={{ padding: 16, color: "var(--text3)", fontSize: 13 }}>Ученик не найден</div>
              ) : (
                <>
                  <div style={{ padding: "10px 16px 6px", fontSize: 11, color: "var(--text3)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                    Найдено учеников: {found.length} · Занятий: {foundLessons.length}
                  </div>
                  {found.map(s => {
                    const sLessons = foundLessons.filter(l =>
                      l.type === "individual" ? l.studentId === s.id : (l.studentIds||[]).some(si => si.id === s.id)
                    );
                    return (
                      <div key={s.id} style={{ padding: "10px 16px", borderTop: "1px solid var(--border)", display: "flex", gap: 12, alignItems: "flex-start" }}>
                        <div style={{ width: 36, height: 36, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
                          {s.name.slice(0,2)}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 700, fontSize: 13 }}>{s.name}</div>
                          <div style={{ display: "flex", gap: 12, marginTop: 3, flexWrap: "wrap" }}>
                            {s.phone && <a href={"tel:"+s.phone} style={{ color: "var(--accent)", fontSize: 12, textDecoration: "none", fontWeight: 600 }}>📞 {s.phone}</a>}
                            {s.parentPhone && <a href={"tel:"+s.parentPhone} style={{ color: "var(--text2)", fontSize: 12, textDecoration: "none" }}>👨‍👩‍👧 {s.parentPhone}</a>}
                            {s.grade && <span style={{ color: "var(--text3)", fontSize: 12 }}>{s.grade} кл.</span>}
                          </div>
                          {sLessons.length > 0 && (
                            <div style={{ marginTop: 6, display: "flex", flexWrap: "wrap", gap: 4 }}>
                              {sLessons.slice(0,5).map(l => {
                                const t = teachers.find(x => x.id === l.teacherId);
                                return (
                                  <div key={l.id} onClick={() => { setEditLesson(l); setLessonForm({ ...l, teacherId: String(l.teacherId), studentId: String(l.studentId||""), price: String(l.price), duration: String(l.duration), studentIds: l.studentIds||[], status: l.status||"scheduled" }); setShowModal(true); setScheduleSearch(""); }}
                                    style={{ background: (t?.color||"var(--accent)")+"18", border: "1px solid "+(t?.color||"var(--accent)")+"44", borderRadius: 6, padding: "3px 8px", cursor: "pointer", fontSize: 11 }}>
                                    <span style={{ color: t?.color||"var(--accent)", fontWeight: 600 }}>{l.date}</span>
                                    <span style={{ color: "var(--text2)" }}> {l.time} · {l.subject}</span>
                                    {t && <span style={{ color: "var(--text3)" }}> · {t.name.split(" ")[0]}</span>}
                                  </div>
                                );
                              })}
                              {sLessons.length > 5 && <span style={{ fontSize: 11, color: "var(--text3)", padding: "3px 8px" }}>+{sLessons.length-5} ещё</span>}
                            </div>
                          )}
                          {sLessons.length === 0 && <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 4 }}>Нет занятий в расписании</div>}
                        </div>
                      </div>
                    );
                  })}
                </>
              )}
            </div>
          );
        })()}
      </div>

      {/* Week navigation */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
        <Btn variant="ghost" onClick={() => setWeekOffset(w => w - 1)}>‹ Пред. неделя</Btn>
        <div style={{ fontWeight: 700, color: "var(--accent)", fontSize: 14 }}>
          {weekDates[0].toLocaleDateString("ru-RU", { day: "numeric", month: "long" })} — {weekDates[6].toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}
        </div>
        <Btn variant="ghost" onClick={() => setWeekOffset(w => w + 1)}>След. неделя ›</Btn>
        <Btn variant="ghost" onClick={() => setWeekOffset(0)}>Сегодня</Btn>
      </div>

      {/* Day tabs */}
      <div style={{ display: "flex", gap: 4, marginBottom: 16, flexWrap: "wrap" }}>
        <button
          onClick={() => setActiveDay(7)}
          style={{ padding: "8px 16px", borderRadius: 8, border: `2px solid ${activeDay === 7 ? "#1da0d4" : "var(--border)"}`, background: activeDay === 7 ? "#1da0d4" : "white", color: activeDay === 7 ? "white" : "var(--text2)", fontWeight: activeDay === 7 ? 700 : 400, cursor: "pointer", fontSize: 13, fontFamily: "Nunito, sans-serif" }}>
          📅 Вся неделя
        </button>
        {weekDates.map((d, i) => {
          const dayLessons = getDayLessons(i);
          const isToday = dateStr(d) === dateStr(new Date());
          return (
            <button key={i}
              onClick={() => setActiveDay(i)}
              style={{ padding: "8px 14px", borderRadius: 8, border: `2px solid ${activeDay === i ? "#1da0d4" : isToday ? "#5cb85c" : "var(--border)"}`, background: activeDay === i ? "#1da0d4" : isToday ? "#5cb85c22" : "white", color: activeDay === i ? "white" : isToday ? "#5cb85c" : "var(--text2)", fontWeight: activeDay === i || isToday ? 700 : 400, cursor: "pointer", fontSize: 12, fontFamily: "Nunito, sans-serif", position: "relative" }}>
              <div>{DAY_SHORT[i]}</div>
              <div style={{ fontSize: 11 }}>{d.getDate()}</div>
              {dayLessons.length > 0 && (
                <div style={{ position: "absolute", top: -4, right: -4, width: 16, height: 16, borderRadius: "50%", background: activeDay === i ? "rgba(255,255,255,0.4)" : "#f5a623", color: "white", fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>
                  {dayLessons.length}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Hint */}
      <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8 }}>
        💡 Нажмите на ячейку — добавить занятие · Нажмите на занятие — редактировать или удалить
      </div>

      {/* Content */}
      <div style={S.card}>
        {activeDay === 7 ? renderFullWeek() : renderDayTable(activeDay)}
      </div>

      {/* Lesson Modal */}
      {showModal && (
        <Modal title={editLesson ? "Редактировать занятие" : "Новое занятие"} onClose={() => setShowModal(false)} width={520}>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {[{ type: "individual", icon: "👤", label: "Индивидуальное" }, { type: "group", icon: "👥", label: "Групповое" }].map(opt => (
              <button key={opt.type} onClick={() => setLessonForm(f => ({ ...f, type: opt.type }))}
                style={{ flex: 1, padding: "10px", borderRadius: 8, border: `2px solid ${lessonForm.type === opt.type ? "var(--accent)" : "var(--border)"}`, background: lessonForm.type === opt.type ? "var(--accent)22" : "var(--bg3)", color: lessonForm.type === opt.type ? "var(--accent)" : "var(--text2)", cursor: "pointer", fontFamily: "Nunito, sans-serif", fontWeight: 600 }}>
                {opt.icon} {opt.label}
              </button>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 12px" }}>
            <Select label="Преподаватель" value={lessonForm.teacherId} onChange={v => setLessonForm(f => ({ ...f, teacherId: v }))} options={[{ value: "", label: "Выбрать..." }, ...teachers.map(t => ({ value: String(t.id), label: t.name }))]} />
            <Input label="Предмет" value={lessonForm.subject} onChange={v => setLessonForm(f => ({ ...f, subject: v }))} />
            <Input label="Дата" type="date" value={lessonForm.date} onChange={v => setLessonForm(f => ({ ...f, date: v }))} />
            <Select label="Время" value={lessonForm.time} onChange={v => setLessonForm(f => ({ ...f, time: v }))} options={TIME_SLOTS.map(t => ({ value: t, label: t }))} />
            <Select label="Длительность" value={lessonForm.duration} onChange={v => setLessonForm(f => ({ ...f, duration: v }))} options={[{ value: 30, label: "30 мин" }, { value: 40, label: "40 мин" }, { value: 45, label: "45 мин" }, { value: 60, label: "60 мин" }, { value: 90, label: "90 мин" }, { value: 120, label: "120 мин" }]} />
            <Input label="Кабинет" value={lessonForm.room} onChange={v => setLessonForm(f => ({ ...f, room: v }))} />
          </div>
          {lessonForm.type === "individual" ? (
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 12px" }}>
                <div style={{ marginBottom: 12 }}>
                  <label style={S.label}>Ученик</label>
                  <select value={lessonForm.studentId} onChange={e => setLessonForm(f => ({ ...f, studentId: e.target.value }))} style={S.select}>
                    <option value="">Выбрать...</option>
                    {students.map(s => <option key={s.id} value={String(s.id)}>{s.name}{s.grade ? " (" + s.grade + ")" : ""}</option>)}
                  </select>
                  {/* Phone display under student name */}
                  {lessonForm.studentId && (() => {
                    const st = students.find(s => String(s.id) === String(lessonForm.studentId));
                    if (!st) return null;
                    const phone = st.phone || st.parentPhone;
                    return (
                      <div style={{ marginTop: 6, padding: "6px 10px", background: "var(--bg3)", borderRadius: 8, border: "1px solid var(--border)" }}>
                        <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 2 }}>Контакты</div>
                        {st.phone && <a href={"tel:" + st.phone} style={{ display: "flex", alignItems: "center", gap: 5, color: "var(--accent)", fontWeight: 700, fontSize: 13, textDecoration: "none" }}>📞 {st.phone}</a>}
                        {st.parentPhone && <a href={"tel:" + st.parentPhone} style={{ display: "flex", alignItems: "center", gap: 5, color: "var(--text2)", fontSize: 12, textDecoration: "none", marginTop: 2 }}>👨‍👩‍👧 {st.parent || "Родитель"}: {st.parentPhone}</a>}
                        {st.grade && <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 2 }}>Класс: {st.grade} · {st.school}</div>}
                      </div>
                    );
                  })()}
                </div>
                <Input label="Стоимость (₽)" type="number" value={lessonForm.price} onChange={v => setLessonForm(f => ({ ...f, price: v }))} />
              </div>
            </div>
          ) : (
            <div style={{ marginBottom: 12 }}>
              <div style={S.h2}>Ученики группы</div>
              {(lessonForm.studentIds || []).map((si, idx) => {
                const st = students.find(s => s.id === si.id);
                return (
                  <div key={idx} style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <select value={si.id} onChange={e => setLessonForm(f => { const arr = [...f.studentIds]; arr[idx] = { ...arr[idx], id: +e.target.value }; return { ...f, studentIds: arr }; })} style={{ ...S.select, flex: 1 }}>
                        <option value="">Выбрать...</option>
                        {students.map(s => <option key={s.id} value={s.id}>{s.name}{s.grade ? " (" + s.grade + ")" : ""}</option>)}
                      </select>
                      <input type="number" value={si.price} onChange={e => setLessonForm(f => { const arr = [...f.studentIds]; arr[idx] = { ...arr[idx], price: +e.target.value }; return { ...f, studentIds: arr }; })} placeholder="₽" style={{ ...S.input, width: 80 }} />
                      <button onClick={() => setLessonForm(f => ({ ...f, studentIds: f.studentIds.filter((_, i) => i !== idx) }))} style={{ background: "#e5393522", color: "var(--red)", border: "none", borderRadius: 6, padding: "6px 10px", cursor: "pointer" }}>✕</button>
                    </div>

                  </div>
                );
              })}
              <Btn variant="ghost" onClick={() => setLessonForm(f => ({ ...f, studentIds: [...(f.studentIds || []), { id: 0, price: 0 }] }))}>+ Добавить ученика</Btn>
              <div style={{ marginTop: 8, fontWeight: 600, color: "var(--green)" }}>Итого: {fmt((lessonForm.studentIds || []).reduce((s, si) => s + (si.price || 0), 0))}</div>
            </div>
          )}
          {/* Lesson status */}
          <div style={{ marginBottom: 12 }}>
            <label style={S.label}>Статус урока</label>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {[
                { val: "scheduled", label: "📅 Запланирован", color: "var(--accent)" },
                { val: "completed", label: "✅ Проведён", color: "var(--green)" },
                { val: "cancelled", label: "❌ Отменён", color: "var(--red)" },
                { val: "cancelled_excused", label: "⚠️ Отменён (ув. причина)", color: "var(--yellow)" },
              ].map(opt => (
                <button key={opt.val} onClick={() => setLessonForm(f => ({ ...f, status: opt.val }))}
                  style={{ padding: "6px 12px", borderRadius: 8, border: `2px solid ${lessonForm.status === opt.val ? opt.color : "var(--border)"}`, background: lessonForm.status === opt.val ? opt.color + "22" : "var(--bg3)", color: lessonForm.status === opt.val ? opt.color : "var(--text2)", cursor: "pointer", fontSize: 12, fontWeight: lessonForm.status === opt.val ? 700 : 400, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 8 }}>
            <label style={S.label}>📝 Заметка после урока</label>
            <textarea value={lessonForm.notes || ""} onChange={e => setLessonForm(f => ({ ...f, notes: e.target.value }))}
              placeholder="Что прошли, домашнее задание, замечания..."
              style={{ ...S.input, minHeight: 60, resize: "vertical", fontSize: 12 }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <input type="checkbox" id="paid" checked={lessonForm.paid || false} onChange={e => setLessonForm(f => ({ ...f, paid: e.target.checked }))} />
            <label htmlFor="paid" style={{ fontSize: 13, cursor: "pointer" }}>✅ Урок оплачен</label>
          </div>

          {/* Recurring lesson block */}
          <div style={{ background: "var(--bg3)", borderRadius: 10, padding: 12, border: "1px solid var(--border)", marginBottom: 8 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: lessonForm.series ? 12 : 0 }}>
              <input type="checkbox" id="series" checked={lessonForm.series || false} onChange={e => setLessonForm(f => ({ ...f, series: e.target.checked }))} />
              <label htmlFor="series" style={{ fontSize: 13, cursor: "pointer", fontWeight: 600, color: "var(--accent)" }}>🔁 Повторяющееся занятие (серия)</label>
            </div>

            {lessonForm.series && (
              <div>
                <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 8, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  Дни повторения
                </div>
                <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
                  {["Пн","Вт","Ср","Чт","Пт","Сб","Вс"].map((day, i) => {
                    const days = lessonForm.repeatDays || [];
                    const active = days.includes(i);
                    return (
                      <button key={i} type="button"
                        onClick={() => {
                          const cur = lessonForm.repeatDays || [];
                          const next = active ? cur.filter(d => d !== i) : [...cur, i];
                          setLessonForm(f => ({ ...f, repeatDays: next }));
                        }}
                        style={{ width: 36, height: 36, borderRadius: "50%", border: active ? "2px solid var(--accent)" : "2px solid var(--border)", background: active ? "var(--accent)" : "white", color: active ? "white" : "var(--text2)", fontWeight: active ? 700 : 400, cursor: "pointer", fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                        {day}
                      </button>
                    );
                  })}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 12px" }}>
                  <div style={{ marginBottom: 8 }}>
                    <label style={S.label}>Повторять до</label>
                    <input type="date" value={lessonForm.repeatUntil || ""} onChange={e => setLessonForm(f => ({ ...f, repeatUntil: e.target.value }))} style={{ ...S.input }} />
                  </div>
                  <div style={{ marginBottom: 8 }}>
                    <label style={S.label}>Количество недель</label>
                    <select value={lessonForm.repeatWeeks || 4} onChange={e => setLessonForm(f => ({ ...f, repeatWeeks: +e.target.value }))} style={S.select}>
                      {[1,2,3,4,6,8,12,16,20,24].map(w => <option key={w} value={w}>{w} {w===1?"неделя":w<5?"недели":"недель"}</option>)}
                    </select>
                  </div>
                </div>
                {(lessonForm.repeatDays||[]).length > 0 && (() => {
                  const days = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"];
                  const selectedDays = (lessonForm.repeatDays||[]).map(d => days[d]).join(", ");
                  const weeks = lessonForm.repeatWeeks || 4;
                  const total = (lessonForm.repeatDays||[]).length * weeks;
                  return (
                    <div style={{ background: "var(--accent)18", borderRadius: 8, padding: "8px 12px", fontSize: 12, color: "var(--accent)", fontWeight: 600 }}>
                      ✓ Будет создано {total} занятий · {selectedDays} · {weeks} нед.
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
            {editLesson && <Btn variant="danger" onClick={() => { setData(d => ({ ...d, lessons: d.lessons.filter(l => l.id !== editLesson.id) })); setShowModal(false); }}>Удалить</Btn>}
            <Btn variant="ghost" onClick={() => setShowModal(false)}>Отмена</Btn>
            <Btn onClick={saveLesson}>Сохранить</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── PRICES & RULES ───────────────────────────────────────────────────────────
function PricesRules({ data, setData }) {
  const [tab, setTab] = useState("prices");
  const [editPriceId, setEditPriceId] = useState(null);
  const [editRuleId, setEditRuleId] = useState(null);

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={S.h1}>Цены и правила</div>
        <Btn variant="ghost" onClick={() => window.print()}>🖨️ Печать памятки</Btn>
      </div>
      <Tabs tabs={[{ id: "prices", label: "Прайс-лист" }, { id: "rules", label: "Правила центра" }]} active={tab} onChange={setTab} />

      {tab === "prices" && (
        <div style={S.card}>
          <table style={S.table}>
            <thead>
              <tr>{["Курс", "45 мин", "60 мин", "90 мин", "Группа", ""].map(h => <th key={h} style={S.th}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {data.prices.map(p => (
                <tr key={p.id}>
                  {editPriceId === p.id ? (
                    <>
                      <td style={S.td}><input defaultValue={p.course} id={`pc-${p.id}`} style={{ ...S.input, width: "100%" }} /></td>
                      {["min45","min60","min90","group"].map(f => (
                        <td key={f} style={S.td}><input type="number" defaultValue={p[f] || ""} id={`p${f}-${p.id}`} style={{ ...S.input, width: 80 }} /></td>
                      ))}
                      <td style={S.td}>
                        <div style={{ display: "flex", gap: 4 }}>
                          <Btn onClick={() => {
                            setData(d => ({ ...d, prices: d.prices.map(pr => pr.id === p.id ? { ...pr, course: document.getElementById(`pc-${p.id}`).value, min45: +document.getElementById(`pmin45-${p.id}`).value, min60: +document.getElementById(`pmin60-${p.id}`).value, min90: +document.getElementById(`pmin90-${p.id}`).value, group: +document.getElementById(`pgroup-${p.id}`).value || null } : pr) }));
                            setEditPriceId(null);
                          }}>✓</Btn>
                          <Btn variant="ghost" onClick={() => setEditPriceId(null)}>✕</Btn>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td style={S.td}>{p.course}</td>
                      <td style={S.td}>{p.min45 ? fmt(p.min45) : "—"}</td>
                      <td style={S.td}>{p.min60 ? fmt(p.min60) : "—"}</td>
                      <td style={S.td}>{p.min90 ? fmt(p.min90) : "—"}</td>
                      <td style={S.td}>{p.group ? fmt(p.group) : "—"}</td>
                      <td style={S.td}><button onClick={() => setEditPriceId(p.id)} style={{ background: "var(--bg3)", border: "none", color: "var(--text2)", padding: "4px 8px", borderRadius: 6, cursor: "pointer" }}>✏️</button></td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 12 }}>
            <Btn variant="ghost" onClick={() => setData(d => ({ ...d, prices: [...d.prices, { id: Date.now(), course: "Новый курс", min45: 0, min60: 0, min90: 0, group: null }] }))}>+ Добавить курс</Btn>
          </div>
        </div>
      )}

      {tab === "rules" && (
        <div>
          {[...new Set(data.rules.map(r => r.section))].map(sec => (
            <div key={sec} style={{ ...S.card, marginBottom: 12 }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 600, fontSize: 14, marginBottom: 12, color: "var(--accent)" }}>{sec}</div>
              {data.rules.filter(r => r.section === sec).map((r, i) => (
                <div key={r.id} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
                  <div style={{ color: "var(--accent)", fontWeight: 700, fontSize: 12, marginTop: 2, flexShrink: 0 }}>{i + 1}.</div>
                  {editRuleId === r.id ? (
                    <>
                      <input defaultValue={r.text} id={`r-${r.id}`} style={{ ...S.input, flex: 1 }} />
                      <Btn onClick={() => { setData(d => ({ ...d, rules: d.rules.map(ru => ru.id === r.id ? { ...ru, text: document.getElementById(`r-${r.id}`).value } : ru) })); setEditRuleId(null); }}>✓</Btn>
                      <Btn variant="ghost" onClick={() => setEditRuleId(null)}>✕</Btn>
                    </>
                  ) : (
                    <>
                      <div style={{ flex: 1, fontSize: 13 }}>{r.text}</div>
                      <button onClick={() => setEditRuleId(r.id)} style={{ background: "none", border: "none", color: "var(--text3)", cursor: "pointer" }}>✏️</button>
                    </>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── FINANCES ─────────────────────────────────────────────────────────────────
function Finances({ data, setData }) {
  const [showAdd, setShowAdd] = useState(false);
  const [showReceipt, setShowReceipt] = useState(null);
  const [form, setForm] = useState({ studentId: "", amount: "", date: new Date().toISOString().split("T")[0], type: "income", method: "Карта", note: "" });

  const income = data.payments.filter(p => p.type === "income").reduce((s, p) => s + p.amount, 0);
  const expenses = data.payments.filter(p => p.type === "expense").reduce((s, p) => s + p.amount, 0);
  const salaryTotal = data.salaries.reduce((s, p) => s + p.amount, 0);
  const profit = income - expenses - salaryTotal;

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={S.h1}>Финансы</div>
        <Btn onClick={() => setShowAdd(true)}>+ Платёж</Btn>
      </div>

      <div style={{ ...S.grid(4), marginBottom: 20 }}>
        {[{ label: "Доходы", val: fmt(income), color: "var(--green)" }, { label: "Расходы", val: fmt(expenses), color: "var(--red)" }, { label: "Зарплаты", val: fmt(salaryTotal), color: "var(--yellow)" }, { label: "Прибыль", val: fmt(profit), color: profit >= 0 ? "var(--cyan)" : "var(--red)" }].map(s => (
          <div key={s.label} style={S.statCard} className="hover-card slide-up">
            <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 22, color: s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

      <div style={S.card}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={S.h2}>Таблица платежей</div>
        </div>
        <table style={S.table}>
          <thead><tr>{["№", "Дата", "Ученик", "Сумма", "Метод", "Примечание", ""].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {[...data.payments].reverse().map(p => {
              const st = getStudent(data.students, p.studentId);
              return (
                <tr key={p.id}>
                  <td style={S.td}>{p.receiptNum}</td>
                  <td style={S.td}>{formatDate(p.date)}</td>
                  <td style={S.td}>{st?.name || "—"}</td>
                  <td style={S.td}><span style={{ color: p.type === "income" ? "var(--green)" : "var(--red)", fontWeight: 600 }}>{p.type === "income" ? "+" : "-"}{fmt(p.amount)}</span></td>
                  <td style={S.td}>{p.method}</td>
                  <td style={S.td}>{p.note}</td>
                  <td style={S.td}><button onClick={() => setShowReceipt(p)} style={{ background: "var(--bg3)", border: "none", color: "var(--text2)", padding: "4px 8px", borderRadius: 6, cursor: "pointer" }}>🖨️</button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showAdd && (
        <Modal title="Новый платёж" onClose={() => setShowAdd(false)}>
          <Select label="Ученик" value={form.studentId} onChange={v => setForm(f => ({ ...f, studentId: v }))} options={[{ value: "", label: "Не указан" }, ...data.students.map(s => ({ value: String(s.id), label: s.name }))]} />
          <Input label="Сумма (₽)" type="number" value={form.amount} onChange={v => setForm(f => ({ ...f, amount: v }))} />
          <Input label="Дата" type="date" value={form.date} onChange={v => setForm(f => ({ ...f, date: v }))} />
          <Select label="Тип" value={form.type} onChange={v => setForm(f => ({ ...f, type: v }))} options={[{ value: "income", label: "Доход" }, { value: "expense", label: "Расход" }]} />
          <Select label="Метод" value={form.method} onChange={v => setForm(f => ({ ...f, method: v }))} options={["Карта", "Наличные", "Перевод"]} />
          <Input label="Примечание" value={form.note} onChange={v => setForm(f => ({ ...f, note: v }))} />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <Btn variant="ghost" onClick={() => setShowAdd(false)}>Отмена</Btn>
            <Btn onClick={() => {
              const num = "Р-" + String(data.payments.length + 1).padStart(3, "0");
              const p = { ...form, id: Date.now(), studentId: +form.studentId, amount: +form.amount, receiptNum: num };
              setData(d => ({ ...d, payments: [...d.payments, p] }));
              setShowAdd(false);
            }}>Сохранить</Btn>
          </div>
        </Modal>
      )}

      {showReceipt && (
        <Modal title="Квитанция" onClose={() => setShowReceipt(null)}>
          <div style={{ background: "white", color: "black", padding: 24, borderRadius: 8, fontFamily: "serif" }}>
            <div style={{ textAlign: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 20, fontWeight: 700 }}>Образовательный центр «ГЕНИЙ»</div>
              <div style={{ fontSize: 14 }}>КВИТАНЦИЯ {showReceipt.receiptNum}</div>
            </div>
            <div style={{ marginBottom: 8 }}>Дата: {formatDate(showReceipt.date)}</div>
            <div style={{ marginBottom: 8 }}>Ученик: {getStudent(data.students, showReceipt.studentId)?.name || "—"}</div>
            <div style={{ marginBottom: 8 }}>Сумма: {fmt(showReceipt.amount)}</div>
            <div style={{ marginBottom: 8 }}>Метод: {showReceipt.method}</div>
            <div style={{ marginBottom: 8 }}>Примечание: {showReceipt.note}</div>
            <div style={{ marginTop: 20, borderTop: "1px solid black", paddingTop: 8, fontSize: 12 }}>Подпись: ___________________</div>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 12 }}>
            <Btn onClick={() => window.print()}>🖨️ Печать</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── REPORTS ──────────────────────────────────────────────────────────────────
function Reports({ data }) {
  const [tab, setTab] = useState("salary");
  const [printTeacher, setPrintTeacher] = useState("");
  const [printStudent, setPrintStudent] = useState("");

  const teachers = data.teachers || [];
  const students = data.students || [];
  const lessons = data.lessons || [];
  const payments = data.payments || [];
  const salaries = data.salaries || [];
  const advances = data.advances || [];

  const income = payments.filter(p => p.type === "income").reduce((s, p) => s + p.amount, 0);
  const expenses = payments.filter(p => p.type === "expense").reduce((s, p) => s + p.amount, 0);
  const salaryTotal = salaries.reduce((s, p) => s + p.amount, 0);

  // Salary breakdown per teacher with individual/group/duration split
  const teacherSalaryStats = teachers.map(t => {
    const tLessons = lessons.filter(l => l.teacherId === t.id);
    const indLessons = tLessons.filter(l => l.type === "individual");
    const grpLessons = tLessons.filter(l => l.type === "group");
    const byDuration = {};
    tLessons.forEach(l => {
      const key = l.type === "group" ? `Группа ${l.duration}мин` : `Инд. ${l.duration}мин`;
      if (!byDuration[key]) byDuration[key] = { count: 0, revenue: 0 };
      byDuration[key].count++;
      byDuration[key].revenue += l.type === "group" ? (l.studentIds||[]).reduce((a,si)=>a+si.price,0) : l.price;
    });
    const totalRevenue = tLessons.reduce((s, l) => s + (l.type === "group" ? (l.studentIds||[]).reduce((a,si)=>a+si.price,0) : l.price), 0);
    const share = (() => {
      if (t.rateType === "percent") return Math.round(totalRevenue * t.rate / 100);
      if (t.rateType === "table" || (t.rates && Object.keys(t.rates).length > 0)) {
        return tLessons.reduce((sum, l) => {
          const r = t.rates || {};
          const durKey = l.type === "group" ? `grp_${l.duration}` : `ind_${l.duration}`;
          const price = r[durKey] || t.rate || 0;
          return sum + price;
        }, 0);
      }
      return tLessons.length * t.rate;
    })();
    const tAdvances = advances.filter(a => a.teacherId === t.id && !a.returned).reduce((s,a)=>s+a.amount,0);
    return { ...t, indCount: indLessons.length, grpCount: grpLessons.length, totalRevenue, share, toPay: Math.max(0, share - tAdvances), tAdvances, byDuration };
  }).sort((a, b) => b.share - a.share);

  // Print schedule for selected teacher
  function printTeacherSchedule() {
    const t = teachers.find(x => x.id === +printTeacher);
    if (!t) return;
    const tLessons = [...lessons].filter(l => l.teacherId === t.id).sort((a,b) => a.date > b.date ? 1 : -1);
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Расписание — ${t.name}</title>
    <style>body{font-family:Arial;max-width:800px;margin:30px auto;padding:20px;}
    h1{color:#1da0d4;border-bottom:3px solid #1da0d4;padding-bottom:8px;}
    table{width:100%;border-collapse:collapse;margin-top:16px;}
    th{background:#1da0d4;color:white;padding:8px;text-align:left;font-size:12px;}
    td{padding:8px;border-bottom:1px solid #eee;font-size:12px;}
    tr:nth-child(even){background:#f5fbff;}
    .gr{background:#00bcd422;color:#00838f;border-radius:3px;padding:1px 5px;font-size:11px;}
    </style></head><body>
    <h1>📅 Расписание: ${t.name}</h1>
    <p>Предметы: ${t.subjects.join(", ")} | Ставка: ${t.rateType==="percent"?t.rate+"%":fmt(t.rate)+"/занятие"}</p>
    <table><tr><th>Дата</th><th>Время</th><th>Предмет</th><th>Тип</th><th>Ученик(и)</th><th>Длит.</th><th>Сумма</th></tr>
    ${tLessons.map(l => {
      const st = l.type==="individual" ? students.find(s=>s.id===l.studentId) : null;
      return `<tr><td>${new Date(l.date).toLocaleDateString("ru-RU")}</td><td>${l.time}</td><td>${l.subject}</td>
      <td>${l.type==="group"?"<span class=gr>Группа</span>":"Инд."}</td>
      <td>${l.type==="group"?(l.studentIds||[]).length+" уч.":st?.name||"—"}</td>
      <td>${l.duration} мин</td><td>${l.price.toLocaleString("ru-RU")} ₽</td></tr>`;
    }).join("")}
    </table>
    <p style="margin-top:20px;font-size:11px;color:#999">Образовательный центр «ГЕНИЙ» · ${new Date().toLocaleDateString("ru-RU")}</p>
    </body></html>`;
    const w = window.open("","_blank"); w.document.write(html); w.document.close(); w.print();
  }

  // Print schedule for selected student
  function printStudentSchedule() {
    const s = students.find(x => x.id === +printStudent);
    if (!s) return;
    const sLessons = [...lessons].filter(l => l.studentId === s.id || (l.studentIds||[]).some(si=>si.id===s.id)).sort((a,b)=>a.date>b.date?1:-1);
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Расписание — ${s.name}</title>
    <style>body{font-family:Arial;max-width:800px;margin:30px auto;padding:20px;}
    h1{color:#1da0d4;border-bottom:3px solid #1da0d4;padding-bottom:8px;}
    table{width:100%;border-collapse:collapse;margin-top:16px;}
    th{background:#5cb85c;color:white;padding:8px;text-align:left;font-size:12px;}
    td{padding:8px;border-bottom:1px solid #eee;font-size:12px;}
    tr:nth-child(even){background:#f5fff5;}
    </style></head><body>
    <h1>📅 Расписание: ${s.name}</h1>
    <p>Класс: ${s.grade} | Школа: ${s.school} | Предметы: ${(s.subjects||[]).join(", ")}</p>
    <table><tr><th>Дата</th><th>Время</th><th>Предмет</th><th>Педагог</th><th>Тип</th><th>Длит.</th><th>Стоимость</th></tr>
    ${sLessons.map(l => {
      const t = teachers.find(x=>x.id===l.teacherId);
      const price = l.type==="group" ? ((l.studentIds||[]).find(si=>si.id===s.id)||{price:0}).price : l.price;
      return `<tr><td>${new Date(l.date).toLocaleDateString("ru-RU")}</td><td>${l.time}</td><td>${l.subject}</td>
      <td>${t?.name||"—"}</td><td>${l.type==="group"?"Группа":"Инд."}</td>
      <td>${l.duration} мин</td><td>${price.toLocaleString("ru-RU")} ₽</td></tr>`;
    }).join("")}
    </table>
    <p style="margin-top:20px;font-size:11px;color:#999">Образовательный центр «ГЕНИЙ» · ${new Date().toLocaleDateString("ru-RU")}</p>
    </body></html>`;
    const w = window.open("","_blank"); w.document.write(html); w.document.close(); w.print();
  }

  const months = ["Авг", "Сен", "Окт", "Ноя", "Дек", "Янв"];
  const dynamics = months.map((m) => ({ month: m, income: Math.round(15000 + Math.random() * 25000) }));

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={S.h1}>Отчёты</div>
        <Btn variant="ghost" onClick={() => window.print()}>🖨️ Общая печать</Btn>
      </div>

      {/* Print by teacher/student */}
      <div style={{ ...S.card, marginBottom: 16, display: "flex", gap: 16, flexWrap: "wrap", alignItems: "flex-end" }}>
        <div style={{ flex: 1, minWidth: 200 }}>
          <label style={S.label}>🖨️ Расписание педагога</label>
          <div style={{ display: "flex", gap: 8 }}>
            <select value={printTeacher} onChange={e => setPrintTeacher(e.target.value)} style={{ ...S.select, flex: 1 }}>
              <option value="">Выбрать педагога...</option>
              {teachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <Btn onClick={printTeacherSchedule} disabled={!printTeacher}>Печать</Btn>
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <label style={S.label}>🖨️ Расписание ученика</label>
          <div style={{ display: "flex", gap: 8 }}>
            <select value={printStudent} onChange={e => setPrintStudent(e.target.value)} style={{ ...S.select, flex: 1 }}>
              <option value="">Выбрать ученика...</option>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <Btn onClick={printStudentSchedule} disabled={!printStudent}>Печать</Btn>
          </div>
        </div>
      </div>

      <Tabs tabs={[{ id: "salary", label: "💰 Зарплаты" }, { id: "finance", label: "Финансы" }, { id: "teachers", label: "Педагоги" }, { id: "subjects", label: "Предметы" }, { id: "dynamics", label: "Динамика" }]} active={tab} onChange={setTab} />

      {tab === "salary" && (
        <div>
          {teacherSalaryStats.map(t => (
            <div key={t.id} style={{ ...S.card, marginBottom: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                <Avatar initials={t.avatar} color={t.color} size={40} photo={t.photo} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: "var(--text3)" }}>{t.rateType === "percent" ? `${t.rate}% от выручки` : `${fmt(t.rate)} за занятие`}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>К выплате</div>
                  <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 800, fontSize: 22, color: "var(--green)" }}>{fmt(t.toPay)}</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 8, marginBottom: 12 }}>
                {[
                  { label: "Инд. уроков", val: t.indCount, color: "var(--accent)" },
                  { label: "Групп. уроков", val: t.grpCount, color: "var(--cyan)" },
                  { label: "Выручка", val: fmt(t.totalRevenue), color: "var(--text)" },
                  { label: "Начислено", val: fmt(t.share), color: "var(--yellow)" },
                  { label: "Аванс (-)", val: fmt(t.tAdvances), color: "var(--red)" },
                ].map(s => (
                  <div key={s.label} style={{ background: "var(--bg3)", borderRadius: 8, padding: "8px 12px" }}>
                    <div style={{ fontSize: 10, color: "var(--text3)" }}>{s.label}</div>
                    <div style={{ fontWeight: 700, color: s.color }}>{s.val}</div>
                  </div>
                ))}
              </div>
              {Object.keys(t.byDuration).length > 0 && (
                <div>
                  <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6, fontWeight: 600 }}>По категориям:</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {Object.entries(t.byDuration).map(([key, val]) => (
                      <div key={key} style={{ background: "white", border: "1px solid var(--border)", borderRadius: 6, padding: "4px 10px", fontSize: 12 }}>
                        <span style={{ fontWeight: 600 }}>{key}</span>: {val.count} шт · {fmt(val.revenue)}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === "finance" && (
        <div style={S.grid(2)}>
          {[{ label: "Выручка", val: fmt(income), color: "var(--green)" }, { label: "Расходы", val: fmt(expenses), color: "var(--red)" }, { label: "Фонд ЗП", val: fmt(salaryTotal), color: "var(--yellow)" }, { label: "Чистая прибыль", val: fmt(income - expenses - salaryTotal), color: "var(--cyan)" }].map(s => (
            <div key={s.label} style={S.statCard} className="hover-card slide-up">
              <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8 }}>{s.label}</div>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 24, color: s.color }}>{s.val}</div>
            </div>
          ))}
        </div>
      )}

      {tab === "teachers" && (
        <div style={S.card}>
          <table style={S.table}>
            <thead><tr>{["#", "Педагог", "Инд.", "Группа", "Итого зан.", "Выручка"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
            <tbody>
              {teacherSalaryStats.map((t, i) => (
                <tr key={t.id}>
                  <td style={S.td}><span style={{ fontWeight: 700, color: i===0?"var(--yellow)":i===1?"#aaa":"var(--text3)" }}>#{i+1}</span></td>
                  <td style={S.td}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar initials={t.avatar} color={t.color} size={28} photo={t.photo} />{t.name}</div></td>
                  <td style={S.td}><span style={S.badge("var(--accent)")}>{t.indCount}</span></td>
                  <td style={S.td}><span style={S.badge("var(--cyan)")}>{t.grpCount}</span></td>
                  <td style={S.td}>{t.indCount + t.grpCount}</td>
                  <td style={S.td}><span style={{ color: "var(--green)", fontWeight: 600 }}>{fmt(t.totalRevenue)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0 0", borderTop: "1px solid var(--border)", marginTop: 8 }}>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>
                Показано {(page-1)*PAGE_SIZE+1}–{Math.min(page*PAGE_SIZE, filtered.length)} из {filtered.length}
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page===1}
                  style={{ padding: "5px 12px", borderRadius: 7, border: "1px solid var(--border)", background: page===1?"var(--bg3)":"white", cursor: page===1?"default":"pointer", fontSize: 12 }}>‹</button>
                {Array.from({length: Math.min(totalPages, 7)}, (_, i) => {
                  let p = i + 1;
                  if (totalPages > 7) {
                    if (page <= 4) p = i + 1;
                    else if (page >= totalPages - 3) p = totalPages - 6 + i;
                    else p = page - 3 + i;
                  }
                  return (
                    <button key={p} onClick={() => setPage(p)}
                      style={{ padding: "5px 10px", borderRadius: 7, border: "1px solid " + (page===p?"var(--accent)":"var(--border)"), background: page===p?"var(--accent)":"white", color: page===p?"white":"var(--text2)", cursor: "pointer", fontSize: 12, fontWeight: page===p?700:400 }}>{p}</button>
                  );
                })}
                <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page===totalPages}
                  style={{ padding: "5px 12px", borderRadius: 7, border: "1px solid var(--border)", background: page===totalPages?"var(--bg3)":"white", cursor: page===totalPages?"default":"pointer", fontSize: 12 }}>›</button>
              </div>
            </div>
          )}
        </div>
      )}

      {tab === "subjects" && (
        <div style={S.card}>
          <table style={S.table}>
            <thead><tr>{["Предмет", "Инд.", "Группа", "Всего", "Выручка"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
            <tbody>
              {(() => {
                const stats = {};
                lessons.forEach(l => {
                  if (!stats[l.subject]) stats[l.subject] = { ind: 0, grp: 0, revenue: 0 };
                  if (l.type === "group") stats[l.subject].grp++;
                  else stats[l.subject].ind++;
                  stats[l.subject].revenue += l.type === "group" ? (l.studentIds||[]).reduce((a,si)=>a+si.price,0) : l.price;
                });
                return Object.entries(stats).sort((a,b)=>b[1].revenue-a[1].revenue).map(([subj, s]) => (
                  <tr key={subj}>
                    <td style={S.td}>{subj}</td>
                    <td style={S.td}><span style={S.badge("var(--accent)")}>{s.ind}</span></td>
                    <td style={S.td}><span style={S.badge("var(--cyan)")}>{s.grp}</span></td>
                    <td style={S.td}>{s.ind + s.grp}</td>
                    <td style={S.td}><span style={{ color: "var(--green)", fontWeight: 600 }}>{fmt(s.revenue)}</span></td>
                  </tr>
                ));
              })()}
            </tbody>
          </table>
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0 0", borderTop: "1px solid var(--border)", marginTop: 8 }}>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>
                Показано {(page-1)*PAGE_SIZE+1}–{Math.min(page*PAGE_SIZE, filtered.length)} из {filtered.length}
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page===1}
                  style={{ padding: "5px 12px", borderRadius: 7, border: "1px solid var(--border)", background: page===1?"var(--bg3)":"white", cursor: page===1?"default":"pointer", fontSize: 12 }}>‹</button>
                {Array.from({length: Math.min(totalPages, 7)}, (_, i) => {
                  let p = i + 1;
                  if (totalPages > 7) {
                    if (page <= 4) p = i + 1;
                    else if (page >= totalPages - 3) p = totalPages - 6 + i;
                    else p = page - 3 + i;
                  }
                  return (
                    <button key={p} onClick={() => setPage(p)}
                      style={{ padding: "5px 10px", borderRadius: 7, border: "1px solid " + (page===p?"var(--accent)":"var(--border)"), background: page===p?"var(--accent)":"white", color: page===p?"white":"var(--text2)", cursor: "pointer", fontSize: 12, fontWeight: page===p?700:400 }}>{p}</button>
                  );
                })}
                <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page===totalPages}
                  style={{ padding: "5px 12px", borderRadius: 7, border: "1px solid var(--border)", background: page===totalPages?"var(--bg3)":"white", cursor: page===totalPages?"default":"pointer", fontSize: 12 }}>›</button>
              </div>
            </div>
          )}
        </div>
      )}

      {tab === "dynamics" && (
        <div style={S.card}>
          <div style={S.h2}>Динамика за 6 месяцев</div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 160, padding: "12px 0" }}>
            {dynamics.map((m, i) => {
              const maxIncome = Math.max(...dynamics.map(d => d.income));
              const h = (m.income / maxIncome) * 120;
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                  <div style={{ fontSize: 11, color: "var(--text3)" }}>{fmt(m.income)}</div>
                  <div style={{ width: "100%", height: h, background: "linear-gradient(to top, #1da0d4, #5cb85c)", borderRadius: "4px 4px 0 0", minHeight: 4 }} />
                  <div style={{ fontSize: 12, color: "var(--text2)" }}>{m.month}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── REQUESTS ─────────────────────────────────────────────────────────────────
const REQUEST_STATUSES = [
  { id: "new", label: "Новый", color: "var(--accent)" },
  { id: "contacted", label: "Связались", color: "var(--yellow)" },
  { id: "trial", label: "Пробное", color: "var(--cyan)" },
  { id: "enrolled", label: "Записан", color: "var(--green)" },
  { id: "declined", label: "Отказался", color: "var(--red)" },
];

function Requests({ data, setData }) {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", subject: "", child: "", status: "new", teacherId: "", date: new Date().toISOString().split("T")[0], note: "" });

  const filtered = data.requests.filter(r =>
    (filterStatus === "all" || r.status === filterStatus) &&
    (r.name.toLowerCase().includes(search.toLowerCase()) || r.subject.toLowerCase().includes(search.toLowerCase()))
  );

  const req = selected ? data.requests.find(r => r.id === selected) : null;

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div style={S.h1}>Запросы от родителей</div>
        <Btn onClick={() => setShowAdd(true)}>+ Запрос</Btn>
      </div>

      {/* Воронка */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, overflow: "auto" }}>
        {REQUEST_STATUSES.map(s => {
          const cnt = data.requests.filter(r => r.status === s.id).length;
          return (
            <div key={s.id} style={{ flex: 1, minWidth: 100, ...S.card, padding: 12, textAlign: "center", cursor: "pointer", border: filterStatus === s.id ? `2px solid ${s.color}` : "1px solid var(--border)" }} onClick={() => setFilterStatus(filterStatus === s.id ? "all" : s.id)}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 20, color: s.color }}>{cnt}</div>
              <div style={{ fontSize: 11, color: "var(--text3)" }}>{s.label}</div>
            </div>
          );
        })}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Поиск..." style={{ ...S.input, width: 220 }} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 360px" : "1fr", gap: 12 }}>
        <div style={S.card}>
          <table style={S.table}>
            <thead><tr>{["Дата", "Родитель", "Ребёнок", "Предмет", "Статус", "Педагог", ""].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
            <tbody>
              {filtered.map(r => {
                const st = REQUEST_STATUSES.find(s => s.id === r.status);
                const t = getTeacher(data.teachers, r.teacherId);
                return (
                  <tr key={r.id} style={{ cursor: "pointer", background: selected === r.id ? "var(--accent)11" : "" }} onClick={() => setSelected(selected === r.id ? null : r.id)}>
                    <td style={S.td}>{formatDate(r.date)}</td>
                    <td style={S.td}><div style={{ fontWeight: 600 }}>{r.name}</div><div style={{ fontSize: 11, color: "var(--text3)" }}>{r.phone}</div></td>
                    <td style={S.td}>{r.child}</td>
                    <td style={S.td}>{r.subject}</td>
                    <td style={S.td}><span style={S.badge(st?.color || "var(--text3)")}>{st?.label}</span></td>
                    <td style={S.td}>{t ? <span style={{ color: t.color }}>{t.name.split(" ")[0]}</span> : "—"}</td>
                    <td style={S.td}><span style={{ color: "var(--accent)" }}>→</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {req && (
          <div style={S.card}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700 }}>{req.name}</div>
              <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", color: "var(--text3)", cursor: "pointer" }}>✕</button>
            </div>
            {[["Телефон", req.phone], ["Ребёнок", req.child], ["Предмет", req.subject], ["Дата", formatDate(req.date)]].map(([k, v]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 11, color: "var(--text3)" }}>{k}</div>
                <div>{v}</div>
              </div>
            ))}
            {req.note && <div style={{ padding: 8, background: "var(--bg3)", borderRadius: 6, fontSize: 13, marginBottom: 12 }}>📝 {req.note}</div>}
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 4 }}>Статус</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {REQUEST_STATUSES.map(s => (
                  <button key={s.id} onClick={() => setData(d => ({ ...d, requests: d.requests.map(r => r.id === req.id ? { ...r, status: s.id } : r) }))} style={{ padding: "6px 10px", borderRadius: 6, border: `1px solid ${req.status === s.id ? s.color : "var(--border)"}`, background: req.status === s.id ? s.color + "22" : "transparent", color: req.status === s.id ? s.color : "var(--text2)", cursor: "pointer", textAlign: "left", fontSize: 12 }}>
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 4 }}>Назначить педагога</div>
              <select value={req.teacherId || ""} onChange={e => setData(d => ({ ...d, requests: d.requests.map(r => r.id === req.id ? { ...r, teacherId: +e.target.value || null } : r) }))} style={S.select}>
                <option value="">Не назначен</option>
                {data.teachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
            <Btn style={{ width: "100%" }} onClick={() => {
              setData(d => ({ ...d, requests: d.requests.map(r => r.id === req.id ? { ...r, status: "trial" } : r) }));
            }}>📅 Записать на пробное</Btn>
          </div>
        )}
      </div>

      {showAdd && (
        <Modal title="Новый запрос" onClose={() => setShowAdd(false)}>
          <Input label="ФИО родителя" value={form.name} onChange={v => setForm(f => ({ ...f, name: v }))} />
          <Input label="Телефон" value={form.phone} onChange={v => setForm(f => ({ ...f, phone: v }))} />
          <Input label="Ребёнок (имя, возраст, класс)" value={form.child} onChange={v => setForm(f => ({ ...f, child: v }))} />
          <Input label="Предмет" value={form.subject} onChange={v => setForm(f => ({ ...f, subject: v }))} />
          <Input label="Примечание" value={form.note} onChange={v => setForm(f => ({ ...f, note: v }))} />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <Btn variant="ghost" onClick={() => setShowAdd(false)}>Отмена</Btn>
            <Btn onClick={() => {
              setData(d => ({ ...d, requests: [...d.requests, { ...form, id: Date.now(), teacherId: null }] }));
              setShowAdd(false);
            }}>Сохранить</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── BROADCASTS ───────────────────────────────────────────────────────────────
const TEMPLATES = [
  { id: 1, name: "Напоминание о занятии", text: "Уважаемые родители! Напоминаем, что завтра {дата} в {время} состоится занятие по {предмет}. Педагог: {педагог}. Ждём вас!" },
  { id: 2, name: "Оплата за месяц", text: "Уважаемые родители! Просим оплатить занятия за {месяц}. Сумма: {сумма} ₽. Спасибо!" },
  { id: 3, name: "Изменение расписания", text: "Уважаемые родители! Сообщаем об изменении расписания. {детали}. По вопросам: {телефон}." },
  { id: 4, name: "Поздравление", text: "Дорогой {имя}! Поздравляем с {событие}! Желаем успехов в учёбе! Команда центра «ГЕНИЙ»." },
];

function Broadcasts({ data, setData }) {
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [msgText, setMsgText] = useState("");
  const [audience, setAudience] = useState("Все ученики");
  const [channel, setChannel] = useState("WhatsApp");

  return (
    <div className="fade-in">
      <div style={S.h1}>Рассылки</div>
      <div style={{ ...S.grid(2), marginTop: 20 }}>
        <div>
          <div style={S.h2}>Шаблоны сообщений</div>
          {TEMPLATES.map(t => (
            <div key={t.id} style={{ ...S.card, marginBottom: 8, cursor: "pointer", border: selectedTemplate?.id === t.id ? "1px solid var(--accent)" : "1px solid var(--border)" }} onClick={() => { setSelectedTemplate(t); setMsgText(t.text); }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{t.name}</div>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>{t.text.substring(0, 80)}...</div>
            </div>
          ))}

          <div style={{ ...S.card, marginTop: 20 }}>
            <div style={S.h2}>Создать рассылку</div>
            <Select label="Аудитория" value={audience} onChange={setAudience} options={["Все ученики", "Задолженники", "Группа Математика", "Группа Английский", "Все родители"]} />
            <Select label="Канал" value={channel} onChange={setChannel} options={["WhatsApp", "SMS", "Telegram", "Email"]} />
            <div style={{ marginBottom: 12 }}>
              <label style={S.label}>Текст сообщения</label>
              <textarea value={msgText} onChange={e => setMsgText(e.target.value)} style={{ ...S.input, minHeight: 100, resize: "vertical" }} />
            </div>
            <Btn onClick={() => {
              setData(d => ({ ...d, broadcasts: [...d.broadcasts, { id: Date.now(), template: selectedTemplate?.name || "Свободный текст", audience, channel, date: new Date().toISOString().split("T")[0], status: "sent", count: data.students.length }] }));
              setMsgText("");
              setSelectedTemplate(null);
            }}>📤 Отправить</Btn>
          </div>
        </div>

        <div>
          <div style={S.h2}>История рассылок</div>
          {[...data.broadcasts].reverse().map(b => (
            <div key={b.id} style={{ ...S.card, marginBottom: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <div style={{ fontWeight: 600 }}>{b.template}</div>
                <span style={S.badge("var(--green)")}>Отправлено</span>
              </div>
              <div style={{ fontSize: 12, color: "var(--text3)" }}>{b.audience} · {b.channel} · {formatDate(b.date)} · {b.count} получателей</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


// ─── ADVANCES ─────────────────────────────────────────────────────────────────
function Advances({ data, setData }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ teacherId: "", amount: "", date: new Date().toISOString().split("T")[0], note: "", returned: false });

  const advances = data.advances || [];
  const totalPending = advances.filter(a => !a.returned).reduce((s, a) => s + a.amount, 0);

  return (
    <div className="fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={S.h1}>Авансы педагогов</div>
          <div style={{ color: "var(--text3)", fontSize: 13 }}>Невозвращённых: {fmt(totalPending)}</div>
        </div>
        <Btn onClick={() => setShowAdd(true)}>+ Аванс</Btn>
      </div>

      <div style={{ ...S.grid(3), marginBottom: 20 }}>
        {[
          { label: "Выдано авансов", val: fmt(advances.reduce((s,a)=>s+a.amount,0)), color: "var(--yellow)" },
          { label: "Возвращено", val: fmt(advances.filter(a=>a.returned).reduce((s,a)=>s+a.amount,0)), color: "var(--green)" },
          { label: "Не возвращено", val: fmt(totalPending), color: "var(--red)" },
        ].map(s => (
          <div key={s.label} style={S.statCard} className="hover-card slide-up">
            <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 700, fontSize: 22, color: s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

      <div style={S.card}>
        <table style={S.table}>
          <thead>
            <tr>{["Дата","Педагог","Сумма","Примечание","Статус",""].map(h=><th key={h} style={S.th}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {advances.length === 0 && <tr><td colSpan={6} style={{ ...S.td, textAlign: "center", color: "var(--text3)" }}>Авансов нет</td></tr>}
            {advances.map(a => {
              const t = getTeacher(data.teachers || [], a.teacherId);
              return (
                <tr key={a.id}>
                  <td style={S.td}>{formatDate(a.date)}</td>
                  <td style={S.td}>{t ? <span style={{ color: t.color, fontWeight: 600 }}>{t.name}</span> : "—"}</td>
                  <td style={S.td}><span style={{ color: "var(--yellow)", fontWeight: 700 }}>{fmt(a.amount)}</span></td>
                  <td style={S.td}>{a.note}</td>
                  <td style={S.td}>
                    <span style={S.badge(a.returned ? "var(--green)" : "var(--red)")}>
                      {a.returned ? "Возвращён" : "Не возвращён"}
                    </span>
                  </td>
                  <td style={S.td}>
                    <div style={{ display: "flex", gap: 6 }}>
                      {!a.returned && (
                        <Btn variant="success" onClick={() => setData(d => ({ ...d, advances: (d.advances||[]).map(x => x.id === a.id ? { ...x, returned: true } : x) }))}>
                          ✓ Возвращён
                        </Btn>
                      )}
                      <Btn variant="danger" onClick={() => setData(d => ({ ...d, advances: (d.advances||[]).filter(x => x.id !== a.id) }))}>✕</Btn>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showAdd && (
        <Modal title="Новый аванс" onClose={() => setShowAdd(false)}>
          <Select label="Педагог" value={form.teacherId} onChange={v => setForm(f => ({ ...f, teacherId: v }))}
            options={[{ value: "", label: "Выбрать..." }, ...(data.teachers||[]).map(t => ({ value: String(t.id), label: t.name }))]} />
          <Input label="Сумма (₽)" type="number" value={form.amount} onChange={v => setForm(f => ({ ...f, amount: v }))} />
          <Input label="Дата" type="date" value={form.date} onChange={v => setForm(f => ({ ...f, date: v }))} />
          <Input label="Примечание" value={form.note} onChange={v => setForm(f => ({ ...f, note: v }))} />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <Btn variant="ghost" onClick={() => setShowAdd(false)}>Отмена</Btn>
            <Btn onClick={() => {
              setData(d => ({ ...d, advances: [...(d.advances||[]), { ...form, id: Date.now(), teacherId: +form.teacherId, amount: +form.amount, returned: false }] }));
              setShowAdd(false);
              setForm({ teacherId: "", amount: "", date: new Date().toISOString().split("T")[0], note: "", returned: false });
            }}>Сохранить</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}


// ─── AI ASSISTANT ─────────────────────────────────────────────────────────────
function AIAssistant({ data }) {
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Привет! Я ИИ-помощник центра «Гений». Выберите модель вверху и задайте любой вопрос о работе центра!" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiModel, setAiModel] = useState("deepseek");
  const messagesEnd = useRef(null);
  
  const DEEPSEEK_KEY = "sk-cdc48f4ee55b4f2e9ef48238642c9e09";
  const CLAUDE_KEY = ""; // добавьте ключ Claude если нужно

  const teachers = data.teachers || [];
  const students = data.students || [];
  const lessons = data.lessons || [];
  const payments = data.payments || [];
  const advances = data.advances || [];

  function buildContext() {
    const totalRevenue = payments.filter(p => p.type === "income").reduce((s, p) => s + p.amount, 0);
    const totalExpenses = payments.filter(p => p.type === "expense").reduce((s, p) => s + p.amount, 0);
    const debtors = students.filter(s => s.balance < 0);
    const todayLessons = lessons.filter(l => l.date === new Date().toISOString().split("T")[0]);
    const unpaidAdvances = advances.filter(a => !a.returned).reduce((s, a) => s + a.amount, 0);
    const teachersList = teachers.map(function(t) {
      return t.name + " (предметы: " + (t.subjects||[]).join(", ") + ", ставка: " + (t.rateType === "percent" ? t.rate + "%" : t.rate + " руб/зан") + ")";
    }).join("; ");
    const studentsList = students.map(function(s) {
      return s.name + ", " + (s.grade || "") + " кл, тел: " + (s.phone || "нет") + ", баланс: " + s.balance + " руб";
    }).join("; ");
    const todayList = todayLessons.map(function(l) {
      var t = teachers.find(function(x) { return x.id === l.teacherId; });
      return l.time + " " + l.subject + " (" + (t ? t.name : "?") + ")";
    }).join(", ");

    return `Ты — ИИ-помощник образовательного центра «ГЕНИЙ». Отвечай на русском языке, подробно и по делу.

ПЕДАГОГИ (${teachers.length}):
${teachersList}

УЧЕНИКИ (${students.length}):
${studentsList}

ФИНАНСЫ:
- Выручка: ${totalRevenue.toLocaleString("ru-RU")} ₽
- Расходы: ${totalExpenses.toLocaleString("ru-RU")} ₽
- Прибыль: ${(totalRevenue - totalExpenses).toLocaleString("ru-RU")} ₽
- Должники: ${debtors.map(s => s.name + " (" + s.balance + "₽)").join(", ") || "нет"}
- Авансы не возвращены: ${unpaidAdvances.toLocaleString("ru-RU")} ₽

ЗАНЯТИЯ СЕГОДНЯ (${todayLessons.length}): ${todayList || "нет"}
ВСЕГО ЗАНЯТИЙ: ${lessons.length}

Ты можешь давать советы, анализировать данные, предлагать улучшения расписания, напоминать о должниках и зарплатах. Будь конкретным и полезным.`;
  }

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(m => [...m, { role: "user", text: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: buildContext(),
          messages: [
            ...messages.filter(m => m.role !== "assistant" || messages.indexOf(m) > 0).map(m => ({ role: m.role, content: m.text })),
            { role: "user", content: userMsg }
          ]
        })
      });
      const result = await response.json();
      const reply = result.content?.[0]?.text || "Извините, не удалось получить ответ.";
      setMessages(m => [...m, { role: "assistant", text: reply }]);
    } catch (e) {
      setMessages(m => [...m, { role: "assistant", text: "⚠️ Ошибка подключения к ИИ. Проверьте интернет." }]);
    }
    setLoading(false);
    setTimeout(() => messagesEnd.current?.scrollIntoView({ behavior: "smooth" }), 100);
  }

  const quickQuestions = [
    "Кто из учеников должен оплатить?",
    "Сколько занятий сегодня?",
    "Список всех педагогов",
    "Кому выплатить зарплату?",
    "Анализ доходов центра",
    "Какие ученики на паузе?",
    "Советы по расписанию",
  ];

  return (
    <div className="fade-in" style={{ height: "calc(100vh - 120px)", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: 10 }}>
        <div>
          <div style={S.h1}>ИИ-Помощник</div>
          <div style={{ fontSize: 12, color: "var(--text3)" }}>Анализ данных центра</div>
        </div>
        {/* Model switcher */}
        <div style={{ display: "flex", gap: 6, background: "var(--bg3)", padding: 4, borderRadius: 12, border: "1px solid var(--border)" }}>
          {[
            { id: "deepseek", label: "🤖 DeepSeek", color: "#4a90e2" },
            { id: "claude", label: "✨ Claude", color: "#1da0d4" },
          ].map(m => (
            <button key={m.id} onClick={() => setAiModel(m.id)}
              style={{ padding: "6px 16px", borderRadius: 9, border: "none", cursor: "pointer", fontSize: 12, fontWeight: aiModel === m.id ? 700 : 400, fontFamily: "'Plus Jakarta Sans', sans-serif",
                background: aiModel === m.id ? m.color : "transparent",
                color: aiModel === m.id ? "white" : "var(--text2)",
                boxShadow: aiModel === m.id ? "0 2px 8px " + m.color + "44" : "none",
                transition: "all 0.18s" }}>
              {m.label}
            </button>
          ))}
        </div>
      </div>
      {/* Quick questions */}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
        {quickQuestions.map((q, i) => (
          <button key={i} onClick={() => setInput(q)}
            style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: 20, padding: "4px 12px", cursor: "pointer", fontSize: 11, color: "var(--text2)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            {q}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div style={{ ...S.card, flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 12, marginBottom: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", gap: 10, justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            {m.role === "assistant" && (
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #1da0d4, #5cb85c)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>✨</div>
            )}
            <div style={{
              maxWidth: "75%", padding: "10px 14px", borderRadius: m.role === "user" ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
              background: m.role === "user" ? "linear-gradient(135deg, #1da0d4, #0d8ab8)" : "var(--bg3)",
              color: m.role === "user" ? "white" : "var(--text)",
              fontSize: 13, lineHeight: 1.6,
              border: m.role === "assistant" ? "1px solid var(--border)" : "none",
              whiteSpace: "pre-wrap"
            }}>
              {m.text}
            </div>
            {m.role === "user" && (
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0, color: "white" }}>Я</div>
            )}
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #1da0d4, #5cb85c)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>✨</div>
            <div style={{ background: "var(--bg3)", border: "1px solid var(--border)", borderRadius: "4px 16px 16px 16px", padding: "10px 16px", fontSize: 13 }}>
              <span style={{ animation: "pulse 1s infinite" }}>Думаю...</span>
            </div>
          </div>
        )}
        <div ref={messagesEnd} />
      </div>

      {/* Input */}
      <div style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendMessage()}
          placeholder="Задайте вопрос о работе центра..."
          style={{ ...S.input, flex: 1, fontSize: 13 }} />
        <Btn onClick={sendMessage} disabled={loading || !input.trim()}>
          {loading ? "..." : "Отправить →"}
        </Btn>
      </div>
    </div>
  );
}

// ─── SIDEBAR NAV ──────────────────────────────────────────────────────────────
const NAV_ITEMS = [
  { id: "dashboard",  icon: "▦",  label: "Дашборд" },
  { id: "teachers",   icon: "⊕",  label: "Преподаватели" },
  { id: "students",   icon: "◎",  label: "Ученики" },
  { id: "courses",    icon: "⊞",  label: "Курсы" },
  { id: "schedule",   icon: "⊡",  label: "Расписание" },
  { id: "prices",     icon: "◈",  label: "Цены и правила" },
  { id: "finances",   icon: "◉",  label: "Финансы" },
  { id: "advances",   icon: "⊟",  label: "Авансы" },
  { id: "reports",    icon: "▲",  label: "Отчёты" },
  { id: "requests",   icon: "◫",  label: "Запросы" },
  { id: "broadcasts", icon: "◬",  label: "Рассылки" },
  { id: "ai",         icon: "✨",  label: "ИИ-Помощник" },
];

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("dashboard");
  const [data, setDataRaw] = useState(() => loadData());
  const [saved, setSaved] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [globalSearch, setGlobalSearch] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [showImportExcel, setShowImportExcel] = useState(false);
  const [dbConnected, setDbConnected] = useState(false);
  const [dbLoading, setDbLoading] = useState(true);
  const saveTimer = useRef(null);

  // Load from Supabase on mount
  useEffect(() => {
    dbLoad().then(cloudData => {
      if (cloudData) {
        setDataRaw(cloudData);
        setDbConnected(true);
      }
      setDbLoading(false);
    });
  }, []);

  // Import from Excel data - load from backup file
  const EXCEL_TEACHERS = [];
  const EXCEL_STUDENTS = [];

    function importFromExcel() {
    // Load from backup JSON file
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        try {
          const parsed = JSON.parse(ev.target.result);
          const importT = parsed.teachers || [];
          const importS = parsed.students || [];
          const existTNames = (data.teachers || []).map(t => t.name.toLowerCase().trim());
          const existSNames = (data.students || []).map(s => s.name.toLowerCase().trim());
          const newTeachers = importT.filter(t => !existTNames.includes(t.name.toLowerCase().trim()));
          const newStudents = importS.filter(s => !existSNames.includes(s.name.toLowerCase().trim()));
          setData(d => ({
            ...d,
            teachers: [...(d.teachers || []), ...newTeachers],
            students: [...(d.students || []), ...newStudents]
          }));
          alert("✅ Загружено: " + newTeachers.length + " педагогов и " + newStudents.length + " учеников!");
          setShowImportExcel(false);
        } catch(err) { alert("Ошибка чтения файла: " + err.message); }
      };
      reader.readAsText(file, "utf-8");
    };
    input.click();
  }

  const setData = useCallback((updater) => {
    setDataRaw(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      setSaved(false);
      clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        saveData(next);
        setSaved(true);
      }, 800);
      return next;
    });
  }, []);

  const resetToDemo = () => {
    if (confirm("Сбросить все данные к демо-версии?")) {
      setDataRaw(DEMO_DATA);
      saveData(DEMO_DATA);
      setSaved(true);
    }
  };

  // Auto-generate notifications
  const notifications = (() => {
    const notifs = [];
    const today = new Date();
    // Unpaid students
    (data.students || []).filter(s => s.balance < 0).forEach(s => {
      notifs.push({ id: "debt_" + s.id, icon: "💸", text: `${s.name} — долг ${Math.abs(s.balance).toLocaleString("ru-RU")} ₽`, time: "Финансы", read: false });
    });
    // Today's lessons
    const todayStr = today.toISOString().split("T")[0];
    const todayLessons = (data.lessons || []).filter(l => l.date === todayStr);
    if (todayLessons.length > 0) {
      notifs.push({ id: "today_lessons", icon: "📅", text: `Сегодня ${todayLessons.length} занятий`, time: "Расписание", read: false });
    }
    // Unpaid salaries
    const unpaid = (data.salaries || []).filter(s => !s.paid);
    if (unpaid.length > 0) {
      notifs.push({ id: "salaries", icon: "💰", text: `Не выплачено зарплат: ${unpaid.length} педагогам`, time: "Финансы", read: false });
    }
    // Pending requests
    const pending = (data.requests || []).filter(r => r.status === "new");
    if (pending.length > 0) {
      notifs.push({ id: "requests", icon: "📨", text: `Новых запросов: ${pending.length}`, time: "Запросы", read: false });
    }
    return notifs;
  })();

  // Global search
  const globalSearchResults = (() => {
    if (!globalSearch || globalSearch.length < 2) return [];
    const q = globalSearch.toLowerCase();
    const results = [];
    (data.teachers || []).filter(t => t.name.toLowerCase().includes(q)).forEach(t => {
      results.push({ icon: "👨‍🏫", title: t.name, subtitle: (t.subjects||[]).join(", "), action: () => setPage("teachers") });
    });
    (data.students || []).filter(s => s.name.toLowerCase().includes(q) || s.phone.includes(q)).forEach(s => {
      results.push({ icon: "👨‍🎓", title: s.name, subtitle: `${s.school}, ${s.grade} · ${s.phone}`, action: () => setPage("students") });
    });
    (data.lessons || []).filter(l => l.subject.toLowerCase().includes(q)).slice(0, 5).forEach(l => {
      results.push({ icon: "📚", title: l.subject, subtitle: `${l.date} · ${l.time}`, action: () => setPage("schedule") });
    });
    return results.slice(0, 10);
  })();

  const props = { data, setData, notifications };

  const PAGES = {
    dashboard: <Dashboard {...props} />,
    teachers: <Teachers {...props} />,
    students: <Students {...props} />,
    courses: <Courses {...props} />,
    schedule: <Schedule {...props} />,
    prices: <PricesRules {...props} />,
    finances: <Finances {...props} />,
    advances: <Advances {...props} />,
    reports: <Reports {...props} />,
    requests: <Requests {...props} />,
    broadcasts: <Broadcasts {...props} />,
    ai: <AIAssistant {...props} />,
  };

  return (
    <div id="root" style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      {/* Sidebar */}
      <div style={S.sidebar} className="no-print sidebar-pattern">
        <div style={S.sidebarHeader}>
          <div style={{ position: "relative" }}>
            <div style={{ position: "absolute", top: -30, right: -20, width: 90, height: 90, borderRadius: "50%", background: "rgba(92,184,92,0.35)", zIndex: 0 }} />
            <div style={{ position: "absolute", top: 5, right: 5, width: 50, height: 50, borderRadius: "50%", background: "rgba(245,166,35,0.4)", zIndex: 0 }} />
            <div style={{ position: "absolute", top: -10, left: -15, width: 60, height: 60, borderRadius: "50%", background: "rgba(255,255,255,0.1)", zIndex: 0 }} />
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, position: "relative" }}>
              <div style={{ position: "relative", display: "inline-block" }}>
                <img src={LOGO_IMG} alt="Гений" style={{ width: 80, height: 80, borderRadius: "50%", objectFit: "cover", border: "3px solid rgba(255,255,255,0.6)", boxShadow: "0 6px 20px rgba(0,0,0,0.25), 0 0 0 6px rgba(255,255,255,0.08)" }} />
                <div style={{ position: "absolute", bottom: 2, right: 2, width: 16, height: 16, borderRadius: "50%", background: "#5cb85c", border: "2px solid white", boxShadow: "0 2px 4px rgba(0,0,0,0.2)" }} />
              </div>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 22, color: "white", letterSpacing: "0.5px", textShadow: "0 2px 8px rgba(0,0,0,0.25)", lineHeight: 1.1 }}>Гений</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.65)", letterSpacing: "2px", textTransform: "uppercase", fontWeight: 600 }}>образовательный центр</div>
            </div>
          </div>
        </div>
        <nav style={S.nav}>
          {NAV_ITEMS.map(item => (
            <div key={item.id} style={S.navItem(page === item.id)} onClick={() => setPage(item.id)}>
              <span style={{ fontSize: 15 }}>{item.icon}</span>
              <span>{item.label}</span>
              {item.id === "requests" && data.requests.filter(r => r.status === "new").length > 0 && (
                <span style={{ marginLeft: "auto", background: "var(--accent)", color: "white", borderRadius: 10, fontSize: 10, fontWeight: 700, padding: "1px 6px" }}>{data.requests.filter(r => r.status === "new").length}</span>
              )}
            </div>
          ))}
        </nav>
        <div style={{ padding: "6px 16px", display: "flex", gap: 3 }}>
          {["#1da0d4","#1db8d4","#5cb85c","#7dd45c","#f5a623","#f5c023"].map((c,i) => (
            <div key={i} style={{ flex: 1, height: 3, borderRadius: 3, background: c, opacity: 0.85 }} />
          ))}
        </div>
        <div style={S.sidebarFooter}>
          <div style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, color: saved ? "#7dffb0" : "#ffe07d", fontSize: 11 }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: saved ? "var(--green)" : "var(--yellow)", animation: saved ? "none" : "pulse 1s infinite" }} />
              {saved ? "Сохранено ✓" : "Сохранение..."}
            </div>
            <button onClick={resetToDemo} style={{ background: "rgba(255,255,255,0.15)", border: "none", color: "rgba(255,255,255,0.8)", padding: "4px 8px", borderRadius: 6, cursor: "pointer", fontSize: 11, textAlign: "left" }}>↺ Сброс к демо</button>
          </div>
        </div>
      </div>

      {/* Main */}
      <div style={S.main}>
        <div className="corner-tl no-print" />
        <div className="corner-tr no-print" />
        <div className="corner-br no-print" />
        <div className="corner-bl no-print" />
        <div className="geo-pattern no-print" />
        <div style={S.topbar} className="no-print">
          <div style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 600, fontSize: 15 }}>{NAV_ITEMS.find(n => n.id === page)?.label}</div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ fontSize: 12, color: "var(--text3)" }}>{new Date().toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" })}</div>
          </div>
        </div>
        <div style={S.content}>
          {PAGES[page]}
        </div>
      </div>
    </div>
  );
}
